import { pgTable, text, serial, integer, boolean, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// สร้าง enum ของสถานะการอัพโหลดเพลง
export const trackStatusEnum = pgEnum('track_status', [
  'pending', // รอการตรวจสอบ
  'processing', // กำลังประมวลผล
  'distributing', // กำลังกระจายไปยังแพลตฟอร์ม
  'live', // ออนไลน์แล้ว
  'rejected', // ถูกปฏิเสธ
  'deleted' // ลบแล้ว
]);

// สร้าง enum ของประเภทผู้ใช้
export const userRoleEnum = pgEnum('user_role', [
  'artist', // ศิลปิน
  'admin', // ผู้ดูแลระบบ
]);

// สร้าง enum ของแพคเกจ
export const packageTypeEnum = pgEnum('package_type', [
  'free', // ฟรี
  'basic', // พื้นฐาน
  'pro' // โปร
]);

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  artistName: text("artist_name").notNull(),
  fullName: text("full_name").notNull(),
  profilePicture: text("profile_picture"),
  bio: text("bio"),
  website: text("website"),
  phone: text("phone"),
  location: text("location"),
  instagram: text("instagram"),
  facebook: text("facebook"),
  twitter: text("twitter"),
  role: userRoleEnum("role").notNull().default('artist'),
  packageType: packageTypeEnum("package_type").notNull().default('free'),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// ตารางสำหรับเก็บข้อมูลอัลบั้ม
export const albums = pgTable("albums", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  title: text("title").notNull(),
  releaseDate: timestamp("release_date").notNull(),
  coverArt: text("cover_art").notNull(),
  genre: text("genre").notNull(),
  description: text("description"),
  upc: text("upc"), // Universal Product Code
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// ตารางสำหรับเก็บข้อมูลเพลง
export const tracks = pgTable("tracks", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  albumId: integer("album_id").references(() => albums.id),
  title: text("title").notNull(),
  audioFile: text("audio_file").notNull(),
  duration: integer("duration").notNull(), // ความยาวเป็นวินาที
  genre: text("genre").notNull(),
  isrc: text("isrc"), // International Standard Recording Code
  lyrics: text("lyrics"),
  explicit: boolean("explicit").notNull().default(false),
  status: trackStatusEnum("status").notNull().default('pending'),
  releaseDate: timestamp("release_date").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// ตารางสำหรับเก็บข้อมูลผู้ร่วมงานเพลง
export const trackContributors = pgTable("track_contributors", {
  id: serial("id").primaryKey(),
  trackId: integer("track_id").notNull().references(() => tracks.id),
  name: text("name").notNull(),
  role: text("role").notNull(), // เช่น ศิลปิน, โปรดิวเซอร์, นักแต่งเพลง
});

// ตารางสำหรับเก็บข้อมูลการกระจายเพลงไปยังแพลตฟอร์ม
export const trackDistributions = pgTable("track_distributions", {
  id: serial("id").primaryKey(),
  trackId: integer("track_id").notNull().references(() => tracks.id),
  platform: text("platform").notNull(), // เช่น Spotify, Apple Music
  status: text("status").notNull(), // เช่น pending, live, rejected
  url: text("url"), // URL ของเพลงบนแพลตฟอร์ม
  distributedAt: timestamp("distributed_at"), // เวลาที่เพลงถูกกระจาย
});

// ตารางสำหรับเก็บข้อมูลสถิติการฟังเพลง
export const trackStats = pgTable("track_stats", {
  id: serial("id").primaryKey(),
  trackId: integer("track_id").notNull().references(() => tracks.id),
  platform: text("platform").notNull(), // เช่น Spotify, Apple Music
  streams: integer("streams").notNull().default(0), // จำนวนการสตรีม
  revenue: integer("revenue").notNull().default(0), // รายได้ (สตางค์)
  date: timestamp("date").notNull(), // วันที่บันทึกสถิติ
});

// ตารางสำหรับเก็บศิลปินที่ถูกจัดการโดยผู้ใช้
export const managedArtists = pgTable("managed_artists", {
  id: serial("id").primaryKey(),
  managerId: integer("manager_id").notNull().references(() => users.id), // อ้างอิงถึงผู้ใช้ที่เป็นผู้จัดการศิลปิน
  artistName: text("artist_name").notNull(), // ชื่อศิลปิน
  fullName: text("full_name").notNull(), // ชื่อจริงของศิลปิน
  profilePicture: text("profile_picture"), // รูปโปรไฟล์ศิลปิน
  bio: text("bio"), // ประวัติศิลปิน
  spotifyUrl: text("spotify_url"), // ลิงก์โปรไฟล์ Spotify
  appleMusicUrl: text("apple_music_url"), // ลิงก์โปรไฟล์ Apple Music
  isPrimary: boolean("is_primary").notNull().default(true), // ระบุว่าเป็นศิลปินหลักหรือไม่
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// สร้าง enum ของประเภทการแจ้งเตือน
export const notificationTypeEnum = pgEnum('notification_type', [
  'system', // การแจ้งเตือนจากระบบ
  'track', // การแจ้งเตือนเกี่ยวกับเพลง
  'payment', // การแจ้งเตือนเกี่ยวกับการชำระเงิน
  'distribution' // การแจ้งเตือนเกี่ยวกับการกระจายเพลง
]);

// ตารางสำหรับเก็บข้อมูลการแจ้งเตือน
export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  type: notificationTypeEnum("type").notNull(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  isRead: boolean("is_read").notNull().default(false),
  linkUrl: text("link_url"),
  relatedId: integer("related_id"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const waitlistEntries = pgTable("waitlist_entries", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  artistName: text("artist_name").notNull(),
});

// เพิ่มสคีมาสำหรับการสมัครสมาชิก
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  artistName: true,
  fullName: true,
  profilePicture: true,
  bio: true,
  website: true,
  phone: true,
  location: true,
  instagram: true,
  facebook: true,
  twitter: true,
  role: true,
  packageType: true,
});

// สคีมาสำหรับการเข้าสู่ระบบ
export const loginSchema = z.object({
  username: z.string().min(3, "ชื่อผู้ใช้ต้องมีอย่างน้อย 3 ตัวอักษร"),
  password: z.string().min(6, "รหัสผ่านต้องมีอย่างน้อย 6 ตัวอักษร"),
});

// สคีมาสำหรับการสมัครสมาชิก
export const signupSchema = insertUserSchema.extend({
  username: z.string().min(3, "ชื่อผู้ใช้ต้องมีอย่างน้อย 3 ตัวอักษร"),
  password: z.string().min(6, "รหัสผ่านต้องมีอย่างน้อย 6 ตัวอักษร"),
  email: z.string().email("กรุณากรอกอีเมลที่ถูกต้อง"),
  artistName: z.string().min(2, "ชื่อศิลปินต้องมีอย่างน้อย 2 ตัวอักษร"),
  fullName: z.string().min(2, "ชื่อเต็มต้องมีอย่างน้อย 2 ตัวอักษร"),
  confirmPassword: z.string().min(6, "รหัสผ่านยืนยันต้องมีอย่างน้อย 6 ตัวอักษร"),
  acceptTerms: z.boolean().refine(val => val === true, {
    message: "คุณต้องยอมรับข้อกำหนดและเงื่อนไขการใช้งาน"
  }),
}).refine(data => data.password === data.confirmPassword, {
  message: "รหัสผ่านและรหัสผ่านยืนยันไม่ตรงกัน",
  path: ["confirmPassword"],
});

// สคีมาสำหรับการอัพโหลดเพลง
export const insertTrackSchema = createInsertSchema(tracks).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// สคีมาสำหรับการสร้างอัลบั้ม
export const insertAlbumSchema = createInsertSchema(albums).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// สคีมาสำหรับการอัปเดตโปรไฟล์
export const profileFormSchema = z.object({
  username: z.string().min(3, "ชื่อผู้ใช้ต้องมีอย่างน้อย 3 ตัวอักษร"),
  artistName: z.string().min(2, "ชื่อศิลปินต้องมีอย่างน้อย 2 ตัวอักษร"),
  email: z.string().email("กรุณากรอกอีเมลที่ถูกต้อง"),
  bio: z.string().optional().nullable(),
  website: z.string().optional().nullable(),
  phone: z.string().optional().nullable(),
  location: z.string().optional().nullable(),
  instagram: z.string().optional().nullable(),
  facebook: z.string().optional().nullable(),
  twitter: z.string().optional().nullable(),
  profilePicture: z.string().optional().nullable(),
});

// สคีมาสำหรับการเปลี่ยนรหัสผ่าน
export const passwordFormSchema = z.object({
  currentPassword: z.string().min(6, "รหัสผ่านปัจจุบันต้องมีอย่างน้อย 6 ตัวอักษร"),
  newPassword: z.string().min(6, "รหัสผ่านใหม่ต้องมีอย่างน้อย 6 ตัวอักษร"),
  confirmPassword: z.string().min(6, "รหัสผ่านยืนยันต้องมีอย่างน้อย 6 ตัวอักษร"),
}).refine(data => data.newPassword === data.confirmPassword, {
  message: "รหัสผ่านใหม่และรหัสผ่านยืนยันไม่ตรงกัน",
  path: ["confirmPassword"],
});

// สคีมาสำหรับการอัพโหลดเพลงแบบมีการตรวจสอบ
export const uploadTrackSchema = insertTrackSchema.extend({
  title: z.string().min(1, "ชื่อเพลงห้ามเว้นว่าง"),
  audioFile: z.string().min(1, "ต้องอัพโหลดไฟล์เพลง"),
  genre: z.string().min(1, "กรุณาเลือกแนวเพลง"),
  releaseDate: z.string().refine(date => {
    const parsedDate = new Date(date);
    return !isNaN(parsedDate.getTime()) && parsedDate >= new Date();
  }, "วันที่เผยแพร่ต้องไม่เป็นวันที่ผ่านมาแล้ว"),
  explicit: z.boolean().default(false),
  lyrics: z.string().optional(),
  isrc: z.string().optional(),
  distributionPlatforms: z.array(z.string()).min(1, "กรุณาเลือกอย่างน้อย 1 แพลตฟอร์ม"),
  contributors: z.array(z.object({
    name: z.string().min(1, "ชื่อผู้ร่วมงานห้ามเว้นว่าง"),
    role: z.string().min(1, "กรุณาระบุหน้าที่ของผู้ร่วมงาน"),
  })).optional(),
});

export const insertWaitlistSchema = createInsertSchema(waitlistEntries).pick({
  name: true,
  email: true,
  artistName: true,
});

// Define validation schema with more constraints
export const waitlistFormSchema = insertWaitlistSchema.extend({
  name: z.string().min(2, "ชื่อต้องมีอย่างน้อย 2 ตัวอักษร"),
  email: z.string().email("กรุณากรอกอีเมลที่ถูกต้อง"),
  artistName: z.string().min(2, "ชื่อศิลปิน/วงต้องมีอย่างน้อย 2 ตัวอักษร"),
});

// Export types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type SignupFormData = z.infer<typeof signupSchema>;
export type LoginFormData = z.infer<typeof loginSchema>;

export type InsertTrack = z.infer<typeof insertTrackSchema>;
export type Track = typeof tracks.$inferSelect;
export type UploadTrackData = z.infer<typeof uploadTrackSchema>;

export type InsertAlbum = z.infer<typeof insertAlbumSchema>;
export type Album = typeof albums.$inferSelect;

export type InsertTrackContributor = typeof trackContributors.$inferInsert;
export type TrackContributor = typeof trackContributors.$inferSelect;

export type InsertTrackDistribution = typeof trackDistributions.$inferInsert;
export type TrackDistribution = typeof trackDistributions.$inferSelect;

export type InsertTrackStat = typeof trackStats.$inferInsert;
export type TrackStat = typeof trackStats.$inferSelect;

export type InsertWaitlistEntry = z.infer<typeof insertWaitlistSchema>;
export type WaitlistEntry = typeof waitlistEntries.$inferSelect;

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;

export type ManagedArtist = typeof managedArtists.$inferSelect;
export type InsertManagedArtist = typeof managedArtists.$inferInsert;

// สคีมาสำหรับศิลปินที่ถูกจัดการ
export const managedArtistSchema = createInsertSchema(managedArtists).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const managedArtistFormSchema = managedArtistSchema.extend({
  artistName: z.string().min(2, "ชื่อศิลปินต้องมีอย่างน้อย 2 ตัวอักษร"),
  fullName: z.string().min(2, "ชื่อจริงต้องมีอย่างน้อย 2 ตัวอักษร"),
  spotifyUrl: z.string().optional().nullable(),
  appleMusicUrl: z.string().optional().nullable(),
});

export type ProfileFormValues = z.infer<typeof profileFormSchema>;
export type PasswordFormValues = z.infer<typeof passwordFormSchema>;
export type ManagedArtistFormValues = z.infer<typeof managedArtistFormSchema>;
