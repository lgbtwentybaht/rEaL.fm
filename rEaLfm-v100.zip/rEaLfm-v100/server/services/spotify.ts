import SpotifyWebApi from 'spotify-web-api-node';
import dotenv from 'dotenv';

dotenv.config();

// Spotify API configuration
const spotifyApi = new SpotifyWebApi({
  clientId: process.env.SPOTIFY_CLIENT_ID,
  clientSecret: process.env.SPOTIFY_CLIENT_SECRET
});

let tokenExpirationEpoch: number = 0;

async function refreshAccessToken() {
  try {
    const data = await spotifyApi.clientCredentialsGrant();
    console.log('Retrieved token. Expires in ' + data.body['expires_in'] + ' seconds.');
    
    spotifyApi.setAccessToken(data.body['access_token']);
    
    // Calculate token expiration time (subtract 60 seconds as a buffer)
    tokenExpirationEpoch = (new Date().getTime() / 1000) + data.body['expires_in'] - 60;
    
    return data.body['access_token'];
  } catch (error) {
    console.error('Error refreshing Spotify access token:', error);
    throw error;
  }
}

async function ensureValidToken() {
  const currentTime = new Date().getTime() / 1000;
  
  // If token is expired or about to expire, refresh it
  if (currentTime >= tokenExpirationEpoch) {
    return await refreshAccessToken();
  }
  
  return spotifyApi.getAccessToken();
}

export async function initSpotifyService() {
  try {
    if (!process.env.SPOTIFY_CLIENT_ID || !process.env.SPOTIFY_CLIENT_SECRET) {
      console.warn('Spotify API credentials not found. Some features might be limited.');
      return false;
    }
    
    await refreshAccessToken();
    return true;
  } catch (error) {
    console.error('Failed to initialize Spotify service:', error);
    return false;
  }
}

export async function searchTracks(query: string, limit = 5) {
  try {
    await ensureValidToken();
    const response = await spotifyApi.searchTracks(query, { limit });
    return response.body.tracks?.items || [];
  } catch (error) {
    console.error('Error searching tracks:', error);
    throw error;
  }
}

export async function getTrackDetails(trackId: string) {
  try {
    await ensureValidToken();
    const response = await spotifyApi.getTrack(trackId);
    return response.body;
  } catch (error) {
    console.error('Error getting track details:', error);
    throw error;
  }
}

export async function getArtistDetails(artistId: string) {
  try {
    await ensureValidToken();
    const response = await spotifyApi.getArtist(artistId);
    return response.body;
  } catch (error) {
    console.error('Error getting artist details:', error);
    throw error;
  }
}

export async function searchArtists(query: string, limit = 5) {
  try {
    await ensureValidToken();
    const response = await spotifyApi.searchArtists(query, { limit });
    return response.body.artists?.items || [];
  } catch (error) {
    console.error('Error searching artists:', error);
    throw error;
  }
}

export async function getArtistTopTracks(artistId: string, countryCode = 'TH') {
  try {
    await ensureValidToken();
    const response = await spotifyApi.getArtistTopTracks(artistId, countryCode);
    return response.body.tracks;
  } catch (error) {
    console.error('Error getting artist top tracks:', error);
    throw error;
  }
}

export async function getTrackAudioFeatures(trackId: string) {
  try {
    await ensureValidToken();
    const response = await spotifyApi.getAudioFeaturesForTrack(trackId);
    return response.body;
  } catch (error) {
    console.error('Error getting track audio features:', error);
    throw error;
  }
}

export async function getMultipleTracks(trackIds: string[]) {
  try {
    await ensureValidToken();
    if (trackIds.length === 0) return [];
    
    const response = await spotifyApi.getTracks(trackIds);
    return response.body.tracks;
  } catch (error) {
    console.error('Error getting multiple tracks:', error);
    throw error;
  }
}

export async function getStreamingStats(trackId: string, period = 'month') {
  try {
    await ensureValidToken();
    // This is a mock function since Spotify doesn't provide streaming stats via their API
    // In a real application, you would integrate with a streaming analytics provider or use your own data
    
    // For demo purposes, create some realistic data
    const baseStreams = Math.floor(Math.random() * 10000);
    const totalStreams = period === 'month' ? baseStreams : baseStreams * 6;
    
    // Distribution across platforms (would be based on real data in production)
    const platformDistribution = {
      "Spotify": Math.floor(totalStreams * 0.65),
      "Apple Music": Math.floor(totalStreams * 0.15),
      "YouTube Music": Math.floor(totalStreams * 0.1),
      "Joox": Math.floor(totalStreams * 0.05),
      "Others": Math.floor(totalStreams * 0.05)
    };
    
    // Daily trends (would be based on real data in production)
    const daysInPeriod = period === 'month' ? 30 : 180;
    const dailyTrends = Array.from({ length: daysInPeriod }, (_, i) => {
      const date = new Date();
      date.setDate(date.getDate() - (daysInPeriod - i));
      
      // Generate daily stream count with some variation
      const dailyStreamBase = Math.floor(totalStreams / daysInPeriod);
      const variation = Math.random() * 0.5 + 0.75; // 0.75 to 1.25
      const streams = Math.floor(dailyStreamBase * variation);
      
      return {
        date: date.toISOString().split('T')[0],
        streams
      };
    });
    
    // Geographic distribution (would be based on real data in production)
    const geoDistribution = {
      "Thailand": Math.floor(totalStreams * 0.7),
      "United States": Math.floor(totalStreams * 0.1),
      "Japan": Math.floor(totalStreams * 0.05),
      "Singapore": Math.floor(totalStreams * 0.03),
      "Other countries": Math.floor(totalStreams * 0.12)
    };
    
    return {
      trackId,
      period,
      totalStreams,
      platformDistribution,
      dailyTrends,
      geoDistribution,
      timestamp: new Date().toISOString()
    };
  } catch (error) {
    console.error('Error getting streaming stats:', error);
    throw error;
  }
}

export async function uploadTrackToSpotify(trackData: any) {
  // This is a mock function since Spotify doesn't allow direct track uploads through their API
  // In a real application, you would integrate with a distributor or use Spotify for Artists
  
  try {
    await ensureValidToken();
    
    // Simulate a processing delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Return mock result
    return {
      success: true,
      message: "Track submitted to Spotify for processing. This typically takes 3-5 business days.",
      status: "processing",
      trackId: `spotify-track-${Date.now()}`
    };
  } catch (error) {
    console.error('Error uploading track to Spotify:', error);
    throw error;
  }
}