import { users, waitlistEntries, tracks, albums, notifications, managedArtists, type User, type InsertUser, type WaitlistEntry, type InsertWaitlistEntry, type Track, type InsertTrack, type Album, type InsertAlbum, type Notification, type InsertNotification, type ManagedArtist, type InsertManagedArtist } from "@shared/schema";
import { db } from "./db";
import { and, eq, desc, count } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import MemoryStore from "memorystore";
import { pool } from "./db";

// PostgreSQL session store
export const createSessionStore = () => {
  const PostgresSessionStore = connectPg(session);
  
  return new PostgresSessionStore({
    pool,
    tableName: 'session',
    createTableIfMissing: true
  });
};

// Memory session store (fallback)
export const createMemorySessionStore = () => {
  const MemoryStoreSession = MemoryStore(session);
  
  return new MemoryStoreSession({
    checkPeriod: 86400000 // prune expired entries every 24h
  });
};

// Interface definition for storage operations
export interface IStorage {
  // Session store
  sessionStore: any;

  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllUsers(): Promise<User[]>;
  updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined>;
  deleteUser(id: number): Promise<void>;
  countUsersByRole(role: string): Promise<number>;
  
  // Track methods
  createTrack(track: InsertTrack): Promise<Track>;
  getUserTracks(userId: number): Promise<Track[]>;
  getTrack(id: number): Promise<Track | undefined>;
  updateTrack(id: number, track: Partial<InsertTrack>): Promise<Track | undefined>;
  getAllTracks(): Promise<Track[]>;
  
  // Album methods
  createAlbum(album: InsertAlbum): Promise<Album>;
  getUserAlbums(userId: number): Promise<Album[]>;
  getAlbum(id: number): Promise<Album | undefined>;
  getAllAlbums(): Promise<Album[]>;
  
  // Waitlist methods
  createWaitlistEntry(entry: InsertWaitlistEntry): Promise<WaitlistEntry>;
  getWaitlistEntries(): Promise<WaitlistEntry[]>;
  getWaitlistEntryByEmail(email: string): Promise<WaitlistEntry | undefined>;
  
  // Notification methods
  createNotification(notification: InsertNotification): Promise<Notification>;
  getUserNotifications(userId: number): Promise<Notification[]>;
  getUserUnreadNotificationsCount(userId: number): Promise<number>;
  markNotificationAsRead(id: number): Promise<Notification | undefined>;
  markAllUserNotificationsAsRead(userId: number): Promise<void>;
  
  // Managed Artists methods
  createManagedArtist(artist: InsertManagedArtist): Promise<ManagedArtist>;
  getManagedArtistsByManager(managerId: number): Promise<ManagedArtist[]>;
  getManagedArtist(id: number): Promise<ManagedArtist | undefined>;
  updateManagedArtist(id: number, artistData: Partial<InsertManagedArtist>): Promise<ManagedArtist | undefined>;
  deleteManagedArtist(id: number): Promise<void>;
  getPrimaryManagedArtist(managerId: number): Promise<ManagedArtist | undefined>;
  setManagedArtistAsPrimary(id: number, managerId: number): Promise<ManagedArtist | undefined>;
}

// Database implementation of the storage interface
export class DatabaseStorage implements IStorage {
  sessionStore: any;
  
  constructor() {
    this.sessionStore = createSessionStore();
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }
  
  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users).orderBy(desc(users.createdAt));
  }
  
  async updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set({...userData, updatedAt: new Date()})
      .where(eq(users.id, id))
      .returning();
    return updatedUser || undefined;
  }
  
  async deleteUser(id: number): Promise<void> {
    await db.delete(users).where(eq(users.id, id));
  }
  
  async countUsersByRole(role: string): Promise<number> {
    const result = await db.select({ count: count() }).from(users).where(eq(users.role, role));
    return result[0]?.count || 0;
  }

  // Track methods
  async createTrack(track: InsertTrack): Promise<Track> {
    const [newTrack] = await db
      .insert(tracks)
      .values(track)
      .returning();
    return newTrack;
  }
  
  async getUserTracks(userId: number): Promise<Track[]> {
    return await db
      .select()
      .from(tracks)
      .where(eq(tracks.userId, userId));
  }
  
  async getTrack(id: number): Promise<Track | undefined> {
    const [track] = await db
      .select()
      .from(tracks)
      .where(eq(tracks.id, id));
    return track || undefined;
  }
  
  async updateTrack(id: number, trackData: Partial<InsertTrack>): Promise<Track | undefined> {
    const [updatedTrack] = await db
      .update(tracks)
      .set(trackData)
      .where(eq(tracks.id, id))
      .returning();
    return updatedTrack || undefined;
  }
  
  async getAllTracks(): Promise<Track[]> {
    return await db.select().from(tracks).orderBy(desc(tracks.createdAt));
  }
  
  // Album methods
  async createAlbum(album: InsertAlbum): Promise<Album> {
    const [newAlbum] = await db
      .insert(albums)
      .values(album)
      .returning();
    return newAlbum;
  }
  
  async getUserAlbums(userId: number): Promise<Album[]> {
    return await db
      .select()
      .from(albums)
      .where(eq(albums.userId, userId));
  }
  
  async getAlbum(id: number): Promise<Album | undefined> {
    const [album] = await db
      .select()
      .from(albums)
      .where(eq(albums.id, id));
    return album || undefined;
  }
  
  async getAllAlbums(): Promise<Album[]> {
    return await db.select().from(albums).orderBy(desc(albums.createdAt));
  }

  // Waitlist methods
  async createWaitlistEntry(entry: InsertWaitlistEntry): Promise<WaitlistEntry> {
    const [waitlistEntry] = await db
      .insert(waitlistEntries)
      .values(entry)
      .returning();
    return waitlistEntry;
  }

  async getWaitlistEntries(): Promise<WaitlistEntry[]> {
    return await db.select().from(waitlistEntries);
  }

  async getWaitlistEntryByEmail(email: string): Promise<WaitlistEntry | undefined> {
    const [waitlistEntry] = await db
      .select()
      .from(waitlistEntries)
      .where(eq(waitlistEntries.email, email));
    return waitlistEntry || undefined;
  }

  // Notification methods
  async createNotification(notification: InsertNotification): Promise<Notification> {
    const [newNotification] = await db
      .insert(notifications)
      .values(notification)
      .returning();
    return newNotification;
  }

  async getUserNotifications(userId: number): Promise<Notification[]> {
    return await db
      .select()
      .from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt));
  }

  async getUserUnreadNotificationsCount(userId: number): Promise<number> {
    const result = await db
      .select({ count: count() })
      .from(notifications)
      .where(and(
        eq(notifications.userId, userId),
        eq(notifications.isRead, false)
      ));
    return Number(result[0]?.count) || 0;
  }

  async markNotificationAsRead(id: number): Promise<Notification | undefined> {
    const [updatedNotification] = await db
      .update(notifications)
      .set({ isRead: true })
      .where(eq(notifications.id, id))
      .returning();
    return updatedNotification || undefined;
  }

  async markAllUserNotificationsAsRead(userId: number): Promise<void> {
    await db
      .update(notifications)
      .set({ isRead: true })
      .where(eq(notifications.userId, userId));
  }
  
  // Managed Artists methods
  async createManagedArtist(artist: InsertManagedArtist): Promise<ManagedArtist> {
    const [newArtist] = await db
      .insert(managedArtists)
      .values(artist)
      .returning();
    return newArtist;
  }
  
  async getManagedArtistsByManager(managerId: number): Promise<ManagedArtist[]> {
    return await db
      .select()
      .from(managedArtists)
      .where(eq(managedArtists.managerId, managerId));
  }
  
  async getManagedArtist(id: number): Promise<ManagedArtist | undefined> {
    const [artist] = await db
      .select()
      .from(managedArtists)
      .where(eq(managedArtists.id, id));
    return artist || undefined;
  }
  
  async updateManagedArtist(id: number, artistData: Partial<InsertManagedArtist>): Promise<ManagedArtist | undefined> {
    const [updatedArtist] = await db
      .update(managedArtists)
      .set({...artistData, updatedAt: new Date()})
      .where(eq(managedArtists.id, id))
      .returning();
    return updatedArtist || undefined;
  }
  
  async deleteManagedArtist(id: number): Promise<void> {
    await db
      .delete(managedArtists)
      .where(eq(managedArtists.id, id));
  }
  
  async getPrimaryManagedArtist(managerId: number): Promise<ManagedArtist | undefined> {
    const [artist] = await db
      .select()
      .from(managedArtists)
      .where(and(
        eq(managedArtists.managerId, managerId),
        eq(managedArtists.isPrimary, true)
      ));
    return artist || undefined;
  }
  
  async setManagedArtistAsPrimary(id: number, managerId: number): Promise<ManagedArtist | undefined> {
    // First, set all other artists as non-primary
    await db
      .update(managedArtists)
      .set({ isPrimary: false })
      .where(eq(managedArtists.managerId, managerId));
    
    // Then set the selected artist as primary
    const [updatedArtist] = await db
      .update(managedArtists)
      .set({ isPrimary: true })
      .where(eq(managedArtists.id, id))
      .returning();
    
    return updatedArtist || undefined;
  }
}

// Memory storage implementation (kept as fallback, but not used)
export class MemStorage implements IStorage {
  sessionStore: any;
  private users: Map<number, User>;
  private tracks: Map<number, Track>;
  private albums: Map<number, Album>;
  private waitlistEntries: Map<number, WaitlistEntry>;
  private notifications: Map<number, Notification>;
  
  currentUserId: number;
  currentTrackId: number;
  currentAlbumId: number;
  currentWaitlistId: number;
  currentNotificationId: number;

  constructor() {
    this.sessionStore = createMemorySessionStore();
    this.users = new Map();
    this.tracks = new Map();
    this.albums = new Map();
    this.waitlistEntries = new Map();
    this.notifications = new Map();
    
    this.currentUserId = 1;
    this.currentTrackId = 1;
    this.currentAlbumId = 1;
    this.currentWaitlistId = 1;
    this.currentNotificationId = 1;
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const now = new Date();
    const user: User = { 
      ...insertUser, 
      id,
      role: insertUser.role || "artist",
      profilePicture: insertUser.profilePicture || null,
      packageType: insertUser.packageType || "free",
      createdAt: now,
      updatedAt: now
    };
    this.users.set(id, user);
    return user;
  }

  // Track methods
  async createTrack(track: InsertTrack): Promise<Track> {
    const id = this.currentTrackId++;
    const now = new Date();
    const newTrack: Track = {
      ...track,
      id,
      // Set default values for all required fields
      albumId: track.albumId ?? null,
      isrc: track.isrc ?? null,
      lyrics: track.lyrics ?? null,
      explicit: track.explicit ?? false,
      status: track.status ?? "pending",
      createdAt: now,
      updatedAt: now
    };
    this.tracks.set(id, newTrack);
    return newTrack;
  }
  
  async getUserTracks(userId: number): Promise<Track[]> {
    return Array.from(this.tracks.values()).filter(
      (track) => track.userId === userId
    );
  }
  
  async getTrack(id: number): Promise<Track | undefined> {
    return this.tracks.get(id);
  }
  
  async updateTrack(id: number, trackData: Partial<InsertTrack>): Promise<Track | undefined> {
    const track = this.tracks.get(id);
    if (!track) return undefined;
    
    const updatedTrack: Track = {
      ...track,
      ...trackData,
      updatedAt: new Date()
    };
    
    this.tracks.set(id, updatedTrack);
    return updatedTrack;
  }
  
  // Album methods
  async createAlbum(album: InsertAlbum): Promise<Album> {
    const id = this.currentAlbumId++;
    const now = new Date();
    const newAlbum: Album = {
      ...album,
      id,
      // Set default values for all required fields
      description: album.description ?? null,
      upc: album.upc ?? null,
      createdAt: now,
      updatedAt: now
    };
    this.albums.set(id, newAlbum);
    return newAlbum;
  }
  
  async getUserAlbums(userId: number): Promise<Album[]> {
    return Array.from(this.albums.values()).filter(
      (album) => album.userId === userId
    );
  }
  
  async getAlbum(id: number): Promise<Album | undefined> {
    return this.albums.get(id);
  }

  // Waitlist methods
  async createWaitlistEntry(entry: InsertWaitlistEntry): Promise<WaitlistEntry> {
    const id = this.currentWaitlistId++;
    const waitlistEntry: WaitlistEntry = { ...entry, id };
    this.waitlistEntries.set(id, waitlistEntry);
    return waitlistEntry;
  }

  async getWaitlistEntries(): Promise<WaitlistEntry[]> {
    return Array.from(this.waitlistEntries.values());
  }

  async getWaitlistEntryByEmail(email: string): Promise<WaitlistEntry | undefined> {
    return Array.from(this.waitlistEntries.values()).find(
      (entry) => entry.email === email
    );
  }

  // Missing methods required by IStorage interface
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email
    );
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  async updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser: User = {
      ...user,
      ...userData,
      updatedAt: new Date()
    };
    
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async deleteUser(id: number): Promise<void> {
    this.users.delete(id);
  }

  async countUsersByRole(role: string): Promise<number> {
    return Array.from(this.users.values()).filter(user => user.role === role).length;
  }

  async getAllTracks(): Promise<Track[]> {
    return Array.from(this.tracks.values());
  }

  async getAllAlbums(): Promise<Album[]> {
    return Array.from(this.albums.values());
  }

  // Notification methods
  async createNotification(notification: InsertNotification): Promise<Notification> {
    const id = this.currentNotificationId++;
    const newNotification: Notification = {
      ...notification,
      id,
      isRead: notification.isRead ?? false,
      linkUrl: notification.linkUrl ?? null,
      relatedId: notification.relatedId ?? null,
      createdAt: new Date()
    };
    this.notifications.set(id, newNotification);
    return newNotification;
  }

  async getUserNotifications(userId: number): Promise<Notification[]> {
    return Array.from(this.notifications.values())
      .filter(notification => notification.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getUserUnreadNotificationsCount(userId: number): Promise<number> {
    return Array.from(this.notifications.values())
      .filter(notification => notification.userId === userId && !notification.isRead)
      .length;
  }

  async markNotificationAsRead(id: number): Promise<Notification | undefined> {
    const notification = this.notifications.get(id);
    if (!notification) return undefined;
    
    const updatedNotification: Notification = {
      ...notification,
      isRead: true
    };
    
    this.notifications.set(id, updatedNotification);
    return updatedNotification;
  }

  async markAllUserNotificationsAsRead(userId: number): Promise<void> {
    Array.from(this.notifications.values())
      .filter(notification => notification.userId === userId)
      .forEach(notification => {
        this.notifications.set(notification.id, { ...notification, isRead: true });
      });
  }
  
  // Managed Artists methods
  private managedArtists: Map<number, ManagedArtist> = new Map();
  private currentManagedArtistId: number = 1;
  
  async createManagedArtist(artist: InsertManagedArtist): Promise<ManagedArtist> {
    const id = this.currentManagedArtistId++;
    const now = new Date();
    const newArtist: ManagedArtist = {
      ...artist,
      id,
      profilePicture: artist.profilePicture || null,
      bio: artist.bio || null,
      spotifyUrl: artist.spotifyUrl || null,
      appleMusicUrl: artist.appleMusicUrl || null,
      isPrimary: artist.isPrimary ?? true,
      createdAt: now,
      updatedAt: now
    };
    this.managedArtists.set(id, newArtist);
    return newArtist;
  }
  
  async getManagedArtistsByManager(managerId: number): Promise<ManagedArtist[]> {
    return Array.from(this.managedArtists.values()).filter(
      (artist) => artist.managerId === managerId
    );
  }
  
  async getManagedArtist(id: number): Promise<ManagedArtist | undefined> {
    return this.managedArtists.get(id);
  }
  
  async updateManagedArtist(id: number, artistData: Partial<InsertManagedArtist>): Promise<ManagedArtist | undefined> {
    const artist = this.managedArtists.get(id);
    if (!artist) return undefined;
    
    // Explicitly set optional fields to ensure they're never undefined
    const updatedArtist: ManagedArtist = {
      ...artist,
      ...artistData,
      profilePicture: artistData.profilePicture !== undefined ? artistData.profilePicture : artist.profilePicture,
      bio: artistData.bio !== undefined ? artistData.bio : artist.bio,
      spotifyUrl: artistData.spotifyUrl !== undefined ? artistData.spotifyUrl : artist.spotifyUrl,
      appleMusicUrl: artistData.appleMusicUrl !== undefined ? artistData.appleMusicUrl : artist.appleMusicUrl,
      updatedAt: new Date()
    };
    
    this.managedArtists.set(id, updatedArtist);
    return updatedArtist;
  }
  
  async deleteManagedArtist(id: number): Promise<void> {
    this.managedArtists.delete(id);
  }
  
  async getPrimaryManagedArtist(managerId: number): Promise<ManagedArtist | undefined> {
    return Array.from(this.managedArtists.values()).find(
      (artist) => artist.managerId === managerId && artist.isPrimary
    );
  }
  
  async setManagedArtistAsPrimary(id: number, managerId: number): Promise<ManagedArtist | undefined> {
    // Set all artists of this manager to non-primary
    Array.from(this.managedArtists.values())
      .filter(artist => artist.managerId === managerId)
      .forEach(artist => {
        this.managedArtists.set(artist.id, { ...artist, isPrimary: false });
      });
    
    // Set the selected artist as primary
    const artist = this.managedArtists.get(id);
    if (!artist) return undefined;
    
    const updatedArtist: ManagedArtist = {
      ...artist,
      isPrimary: true,
      updatedAt: new Date()
    };
    
    this.managedArtists.set(id, updatedArtist);
    return updatedArtist;
  }
}

// Export DatabaseStorage instance as the default storage
export const storage = new DatabaseStorage();
