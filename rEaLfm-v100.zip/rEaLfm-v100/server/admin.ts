import express from "express";
import { storage } from "./storage";
import { hashPassword } from "./auth";

// Admin middleware
export function requireAdmin(req: express.Request, res: express.Response, next: express.NextFunction) {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: "ต้องเข้าสู่ระบบก่อนใช้งาน" });
  }

  if (req.user.role !== 'admin') {
    return res.status(403).json({ message: "ไม่มีสิทธิ์เข้าถึงส่วนนี้" });
  }

  next();
}

// Set up admin routes
export function setupAdminRoutes(app: express.Express) {
  const router = express.Router();

  // Get all users
  router.get('/users', requireAdmin, async (_req: express.Request, res: express.Response) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "ไม่สามารถดึงข้อมูลผู้ใช้ได้" });
    }
  });

  // Get user by ID
  router.get('/users/:id', requireAdmin, async (req: express.Request, res: express.Response) => {
    try {
      const userId = parseInt(req.params.id);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "รหัสผู้ใช้ไม่ถูกต้อง" });
      }

      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "ไม่พบผู้ใช้" });
      }

      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "ไม่สามารถดึงข้อมูลผู้ใช้ได้" });
    }
  });

  // Update user
  router.patch('/users/:id', requireAdmin, async (req: express.Request, res: express.Response) => {
    try {
      const userId = parseInt(req.params.id);
      const userData = req.body;

      if (userData.password) {
        userData.password = await hashPassword(userData.password);
      }

      const user = await storage.updateUser(userId, userData);
      if (!user) {
        return res.status(404).json({ message: "ไม่พบผู้ใช้" });
      }

      res.json(user);
    } catch (error) {
      console.error("Error updating user:", error);
      res.status(500).json({ message: "ไม่สามารถอัพเดทข้อมูลผู้ใช้ได้" });
    }
  });

  // Delete user
  router.delete('/users/:id', requireAdmin, async (req: express.Request, res: express.Response) => {
    try {
      const userId = parseInt(req.params.id);
      await storage.deleteUser(userId);
      res.json({ message: "ลบผู้ใช้สำเร็จ" });
    } catch (error) {
      console.error("Error deleting user:", error);
      res.status(500).json({ message: "ไม่สามารถลบผู้ใช้ได้" });
    }
  });

  // Get all tracks
  router.get('/tracks', requireAdmin, async (_req: express.Request, res: express.Response) => {
    try {
      const tracks = await storage.getAllTracks();
      res.json(tracks);
    } catch (error) {
      console.error("Error fetching tracks:", error);
      res.status(500).json({ message: "ไม่สามารถดึงข้อมูลเพลงได้" });
    }
  });

  // Register admin routes
  app.use('/api/admin', router);
}