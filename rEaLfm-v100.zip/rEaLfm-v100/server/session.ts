import session from 'express-session';
import connectPg from 'connect-pg-simple';
import MemoryStore from 'memorystore';
import { pool } from './db';

// PostgreSQL session store
export const createSessionStore = () => {
  const PostgresSessionStore = connectPg(session);
  
  return new PostgresSessionStore({
    pool,
    tableName: 'session',
    createTableIfMissing: true
  });
};

// Memory session store (fallback)
export const createMemorySessionStore = () => {
  const MemoryStoreSession = MemoryStore(session);
  
  return new MemoryStoreSession({
    checkPeriod: 86400000 // prune expired entries every 24h
  });
};