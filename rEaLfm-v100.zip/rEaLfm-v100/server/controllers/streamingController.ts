import { Request, Response, NextFunction } from 'express';
import { searchTracks, getTrackDetails, getArtistDetails, getArtistTopTracks, searchArtists } from '../services/spotify';

export async function searchSpotifyTracks(req: Request, res: Response, next: NextFunction) {
  try {
    const { query } = req.query;
    
    if (!query || typeof query !== 'string') {
      return res.status(400).json({ message: 'Query parameter is required' });
    }
    
    const tracks = await searchTracks(query);
    res.json(tracks);
  } catch (error) {
    next(error);
  }
}

export async function searchSpotifyArtists(req: Request, res: Response, next: NextFunction) {
  try {
    const { query } = req.query;
    
    if (!query || typeof query !== 'string') {
      return res.status(400).json({ message: 'Query parameter is required' });
    }
    
    const artists = await searchArtists(query);
    res.json(artists);
  } catch (error) {
    next(error);
  }
}

export async function getSpotifyTrackDetails(req: Request, res: Response, next: NextFunction) {
  try {
    const { id } = req.params;
    
    if (!id) {
      return res.status(400).json({ message: 'Track ID is required' });
    }
    
    const track = await getTrackDetails(id);
    res.json(track);
  } catch (error) {
    next(error);
  }
}

export async function getSpotifyArtistDetails(req: Request, res: Response, next: NextFunction) {
  try {
    const { id } = req.params;
    
    if (!id) {
      return res.status(400).json({ message: 'Artist ID is required' });
    }
    
    const artist = await getArtistDetails(id);
    res.json(artist);
  } catch (error) {
    next(error);
  }
}

export async function getSpotifyArtistTopTracks(req: Request, res: Response, next: NextFunction) {
  try {
    const { id } = req.params;
    const { country } = req.query;
    
    if (!id) {
      return res.status(400).json({ message: 'Artist ID is required' });
    }
    
    const countryCode = typeof country === 'string' ? country : 'TH';
    const tracks = await getArtistTopTracks(id, countryCode);
    res.json(tracks);
  } catch (error) {
    next(error);
  }
}