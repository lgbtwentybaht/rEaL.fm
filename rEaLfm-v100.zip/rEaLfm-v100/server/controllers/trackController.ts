import { Request, Response, NextFunction } from 'express';
import { storage } from '../storage';
import { insertTrackSchema } from '@shared/schema';
import { fromZodError } from 'zod-validation-error';
import fs from 'fs';
import path from 'path';
import { promisify } from 'util';

const writeFileAsync = promisify(fs.writeFile);
const mkdirAsync = promisify(fs.mkdir);

export async function getAllTracks(req: Request, res: Response, next: NextFunction) {
  try {
    // If admin, get all tracks, otherwise only get user's tracks
    let tracks;
    if (req.user?.role === 'admin') {
      tracks = await storage.getAllTracks();
    } else if (req.user) {
      tracks = await storage.getUserTracks(req.user.id);
    } else {
      return res.status(401).json({ message: 'Authentication required' });
    }

    res.json(tracks);
  } catch (error) {
    next(error);
  }
}

export async function getTrackById(req: Request, res: Response, next: NextFunction) {
  try {
    const { id } = req.params;
    const track = await storage.getTrack(parseInt(id));

    if (!track) {
      return res.status(404).json({ message: 'Track not found' });
    }

    // Check if user is authorized to view this track (owner or admin)
    if (req.user && (req.user.id === track.userId || req.user.role === 'admin')) {
      res.json(track);
    } else {
      res.status(403).json({ message: 'Unauthorized to view this track' });
    }
  } catch (error) {
    next(error);
  }
}

export async function createTrack(req: Request, res: Response, next: NextFunction) {
  try {
    if (!req.user) {
      return res.status(401).json({ message: 'Authentication required' });
    }

    if (!req.file) {
      return res.status(400).json({ message: 'ไม่พบไฟล์เพลง' });
    }

    // Validate user's package and track limit
    const userTracks = await storage.getUserTracks(req.user.id);
    if (req.user.packageType === 'free' && userTracks.length >= 2) {
      return res.status(403).json({ 
        message: 'คุณได้ใช้โควต้าการอัปโหลดเพลงของแพคเกจฟรีหมดแล้ว (สูงสุด 2 เพลงต่อปี)',
        upgradeRequired: true
      });
    } else if (req.user.packageType === 'basic' && userTracks.length >= 50) {
      return res.status(403).json({ 
        message: 'คุณได้ใช้โควต้าการอัปโหลดเพลงของแพคเกจ Basic หมดแล้ว (สูงสุด 50 เพลงต่อปี)',
        upgradeRequired: true
      });
    }

    // Generate unique filename
    const timestamp = Date.now();
    const fileExtension = path.extname(req.file.originalname);
    const filename = `track_${req.user?.id}_${timestamp}${fileExtension}`;

    // Ensure uploads/tracks directory exists
    const uploadsDir = path.join(process.cwd(), 'uploads', 'tracks');
    try {
      // Check if directory exists and create if it doesn't
      if (!fs.existsSync(uploadsDir)) {
        console.log(`Creating directory: ${uploadsDir}`);
        await mkdirAsync(uploadsDir, { recursive: true });
      }
    } catch (err) {
      console.error('Error creating directory:', err);
      return res.status(500).json({ message: 'เกิดข้อผิดพลาดในการสร้างไดเรกทอรี' });
    }

    const filepath = path.join(uploadsDir, filename);

    try {
      // Write file to disk
      console.log(`Writing file to: ${filepath}`);
      await writeFileAsync(filepath, req.file.buffer);
      console.log('File written successfully');
    } catch (err) {
      console.error('Error writing file:', err);
      return res.status(500).json({ message: 'เกิดข้อผิดพลาดในการบันทึกไฟล์' });
    }

    // Create a track duration (ในขั้นตอนนี้เราควรใช้ libraryเช่น music-metadata 
    // แต่เพื่อความเรียบง่ายเราจะจำลองการคำนวณความยาวเพลง)
    const fileSizeInBytes = req.file.size;
    // สมมติว่า average bitrate คือ 192kbps (24KB/s)
    const avgBytesPerSecond = 24 * 1024;
    // คำนวณความยาวโดยประมาณจากขนาดไฟล์
    const durationSeconds = Math.round(fileSizeInBytes / avgBytesPerSecond);

    // สร้างการแจ้งเตือนใหม่เมื่ออัปโหลดเพลง
    await storage.createNotification({
      userId: req.user.id,
      type: 'track',
      title: 'อัปโหลดเพลงสำเร็จ',
      message: `เพลง ${req.body.title} ของคุณได้รับการอัปโหลดเรียบร้อยแล้วและกำลังรอการตรวจสอบ`,
      isRead: false,
      linkUrl: '/dashboard/tracks',
      createdAt: new Date()
    });

    // Create track record
    const track = await storage.createTrack({
      ...req.body,
      userId: req.user?.id,
      audioFile: filename,
      status: 'pending',
      duration: durationSeconds
    });

    // หากเป็นแอดมิน สร้างการแจ้งเตือนใหม่สำหรับแอดมิน
    const admins = (await storage.getAllUsers()).filter(user => user.role === 'admin');
    for (const admin of admins) {
      if (admin.id !== req.user.id) { // ไม่สร้างการแจ้งเตือนถ้าผู้อัปโหลดเป็นแอดมินเอง
        await storage.createNotification({
          userId: admin.id,
          type: 'track',
          title: 'มีเพลงใหม่รอการตรวจสอบ',
          message: `เพลง ${req.body.title} โดย ${req.user.artistName || req.user.username} รอการตรวจสอบและอนุมัติ`,
          isRead: false,
          linkUrl: `/admin/tracks/${track.id}`,
          createdAt: new Date()
        });
      }
    }

    res.status(201).json({
      message: 'อัปโหลดเพลงสำเร็จ',
      track
    });
  } catch (error) {
    next(error);
  }
}

export async function updateTrackStatus(req: Request, res: Response, next: NextFunction) {
  try {
    const { id } = req.params;
    const { status } = req.body;

    if (!req.user || req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Only admins can update track status' });
    }

    // Validate status value
    const validStatuses = ['pending', 'processing', 'distributing', 'live', 'rejected'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ message: 'Invalid status value' });
    }

    // If status is rejected, require a rejection reason
    if (status === 'rejected' && !req.body.rejectionReason) {
      return res.status(400).json({ message: 'Rejection reason is required when rejecting a track' });
    }

    // Get track to check current status and owner
    const existingTrack = await storage.getTrack(parseInt(id));
    if (!existingTrack) {
      return res.status(404).json({ message: 'Track not found' });
    }

    // Update track status
    const track = await storage.updateTrack(parseInt(id), { 
      status,
      // Include rejection reason if provided
      ...(req.body.rejectionReason && { rejectionReason: req.body.rejectionReason })
    });

    if (!track) {
      return res.status(404).json({ message: 'Track not found after update' });
    }

    // Get track owner to send notification
    const trackOwner = await storage.getUser(existingTrack.userId);
    if (trackOwner) {
      // Create a notification for the track owner
      let notificationMessage = '';
      let notificationTitle = '';

      switch(status) {
        case 'processing':
          notificationTitle = 'เพลงของคุณกำลังถูกประมวลผล';
          notificationMessage = `เพลง ${track.title} กำลังอยู่ในขั้นตอนการประมวลผล และเตรียมพร้อมสำหรับการเผยแพร่`;
          break;
        case 'distributing':
          notificationTitle = 'เพลงของคุณกำลังถูกเผยแพร่';
          notificationMessage = `เพลง ${track.title} กำลังถูกเผยแพร่ไปยังแพลตฟอร์มต่างๆ`;
          break;
        case 'live':
          notificationTitle = 'เพลงของคุณเผยแพร่แล้ว';
          notificationMessage = `เพลง ${track.title} ได้รับการเผยแพร่บนแพลตฟอร์มทั้งหมดแล้ว`;
          break;
        case 'rejected':
          notificationTitle = 'เพลงของคุณถูกปฏิเสธ';
          notificationMessage = `เพลง ${track.title} ถูกปฏิเสธการเผยแพร่ เนื่องจาก: ${req.body.rejectionReason || 'ไม่ระบุเหตุผล'}`;
          break;
        default:
          notificationTitle = 'การอัปเดตสถานะเพลง';
          notificationMessage = `เพลง ${track.title} มีการอัปเดตสถานะเป็น ${status}`;
      }

      await storage.createNotification({
        userId: trackOwner.id,
        type: 'track',
        title: notificationTitle,
        message: notificationMessage,
        isRead: false,
        linkUrl: `/dashboard/tracks/${track.id}`,
        createdAt: new Date()
      });
    }

    res.json({
      message: `อัปเดตสถานะเพลงเป็น ${status} เรียบร้อยแล้ว`,
      track
    });
  } catch (error) {
    next(error);
  }
}

export async function deleteTrack(req: Request, res: Response, next: NextFunction) {
  try {
    const { id } = req.params;

    // Get track to check ownership and get file path
    const track = await storage.getTrack(parseInt(id));

    if (!track) {
      return res.status(404).json({ message: 'Track not found' });
    }

    // Check if user is authorized to delete this track (owner or admin)
    if (req.user && (req.user.id === track.userId || req.user.role === 'admin')) {
      // Set status to deleted instead of actually deleting
      // This preserves history and allows for recovery if needed
      const updatedTrack = await storage.updateTrack(parseInt(id), { 
        status: 'deleted' 
      });

      // Optionally, could also delete the file, but better to keep it for now
      // const filePath = path.join(process.cwd(), 'uploads', track.audioFile);
      // if (fs.existsSync(filePath)) {
      //   await fs.promises.unlink(filePath);
      // }

      res.json({ 
        message: 'Track marked as deleted',
        track: updatedTrack
      });
    } else {
      res.status(403).json({ message: 'Unauthorized to delete this track' });
    }
  } catch (error) {
    next(error);
  }
}