import express, { type Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { waitlistFormSchema, loginSchema, signupSchema, InsertUser } from "@shared/schema";
import { fromZodError } from "zod-validation-error";
import { setupAuth, hashPassword } from "./auth";
import { setupAdminRoutes } from "./admin";
import multer from "multer";
import path from "path";
import * as trackController from "./controllers/trackController";
import * as streamingController from "./controllers/streamingController";
import { initMusicServices } from "./services";
import fs from "fs";

// Express with sessions
declare module 'express-session' {
  interface SessionData {
    userId: number;
  }
}

declare global {
  namespace Express {
    interface User {
      id: number;
      username: string;
      email: string;
      role: string;
    }
  }
}

// Use Passport.js and authentication from auth.ts instead

// Ensure upload directories exist
const ensureDirectoryExists = (directory: string) => {
  if (!fs.existsSync(directory)) {
    fs.mkdirSync(directory, { recursive: true });
  }
};

// Configure multer for file uploads
const storage_config = multer.diskStorage({
  destination: (req, file, cb) => {
    let uploadPath = '';
    
    if (file.fieldname === 'profileImage') {
      uploadPath = path.join(process.cwd(), 'uploads', 'profiles');
    } else if (file.fieldname === 'trackAudio') {
      uploadPath = path.join(process.cwd(), 'uploads', 'tracks');
    } else if (file.fieldname === 'albumCover') {
      uploadPath = path.join(process.cwd(), 'uploads', 'albums');
    } else {
      uploadPath = path.join(process.cwd(), 'uploads');
    }
    
    ensureDirectoryExists(uploadPath);
    cb(null, uploadPath);
  },
  filename: (req, file, cb) => {
    // Create a unique filename with timestamp and random string
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    const ext = path.extname(file.originalname);
    cb(null, uniqueSuffix + ext);
  }
});

const upload = multer({
  storage: storage_config,
  limits: {
    fileSize: 100 * 1024 * 1024, // 100MB limit for audio files
  },
  fileFilter: (req, file, cb) => {
    if (file.fieldname === 'profileImage') {
      // Accept only images for profile pictures
      const allowedImageTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
      if (allowedImageTypes.includes(file.mimetype)) {
        cb(null, true);
      } else {
        cb(new Error('รูปแบบไฟล์ไม่ถูกต้อง กรุณาอัพโหลดรูปภาพเท่านั้น'));
      }
    } else if (file.fieldname === 'trackAudio') {
      // Accept only audio files for tracks
      const allowedAudioTypes = ['audio/mpeg', 'audio/mp3', 'audio/wav', 'audio/flac', 'audio/aac', 'audio/ogg'];
      if (allowedAudioTypes.includes(file.mimetype)) {
        cb(null, true);
      } else {
        cb(new Error('รูปแบบไฟล์ไม่ถูกต้อง กรุณาอัปโหลดไฟล์ MP3, WAV, FLAC, AAC หรือ OGG เท่านั้น'));
      }
    } else {
      // Default: accept the file
      cb(null, true);
    }
  },
});

// Ensure uploads directory exists
if (!fs.existsSync(path.join(process.cwd(), 'uploads'))) {
  fs.mkdirSync(path.join(process.cwd(), 'uploads'));
}
if (!fs.existsSync(path.join(process.cwd(), 'uploads', 'tracks'))) {
  fs.mkdirSync(path.join(process.cwd(), 'uploads', 'tracks'));
}
if (!fs.existsSync(path.join(process.cwd(), 'uploads', 'profiles'))) {
  fs.mkdirSync(path.join(process.cwd(), 'uploads', 'profiles'));
}
if (!fs.existsSync(path.join(process.cwd(), 'uploads', 'albums'))) {
  fs.mkdirSync(path.join(process.cwd(), 'uploads', 'albums'));
}

// Authentication middleware
const requireAuth = (req: Request, res: Response, next: NextFunction) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: "ต้องเข้าสู่ระบบก่อนใช้งาน" });
  }
  
  // TypeScript type assertion to ensure req.user is defined
  if (!req.user) {
    return res.status(401).json({ message: "ไม่พบข้อมูลผู้ใช้" });
  }
  
  next();
};

// Admin middleware
const requireAdmin = (req: Request, res: Response, next: NextFunction) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: "ต้องเข้าสู่ระบบก่อนใช้งาน" });
  }
  if (req.user?.role !== 'admin') {
    return res.status(403).json({ message: "ไม่มีสิทธิ์เข้าถึงส่วนนี้" });
  }
  next();
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication with Passport.js
  setupAuth(app);

  // Setup admin routes
  setupAdminRoutes(app);

  // Initialize music streaming services
  const musicServices = await initMusicServices();
  console.log("Music services initialization status:", musicServices);

  // API routes
  const apiRouter = express.Router();

  // Handle waitlist form submissions
  apiRouter.post("/waitlist", async (req: Request, res: Response) => {
    try {
      // Validate request body against schema
      const result = waitlistFormSchema.safeParse(req.body);

      if (!result.success) {
        const validationError = fromZodError(result.error);
        return res.status(400).json({ 
          message: "การตรวจสอบล้มเหลว", 
          errors: validationError.details 
        });
      }

      const entryData = result.data;

      // Check if email already exists
      const existingEntry = await storage.getWaitlistEntryByEmail(entryData.email);
      if (existingEntry) {
        return res.status(409).json({ 
          message: "อีเมลนี้ได้ลงทะเบียนไว้แล้ว" 
        });
      }

      // Store the waitlist entry
      const newEntry = await storage.createWaitlistEntry(entryData);

      // Return success response
      return res.status(201).json({
        message: "ลงทะเบียนรอใช้งานเรียบร้อยแล้ว!",
        data: newEntry
      });
    } catch (error) {
      console.error("Error adding to waitlist:", error);
      return res.status(500).json({ 
        message: "เกิดข้อผิดพลาดขณะประมวลผลคำขอของคุณ" 
      });
    }
  });

  // Get all waitlist entries (for admin purposes)
  apiRouter.get("/waitlist", async (_req: Request, res: Response) => {
    try {
      const entries = await storage.getWaitlistEntries();
      return res.status(200).json(entries);
    } catch (error) {
      console.error("Error fetching waitlist entries:", error);
      return res.status(500).json({ 
        message: "เกิดข้อผิดพลาดขณะดึงข้อมูลรายการลงทะเบียน" 
      });
    }
  });

  // Authentication related routes are handled by setupAuth in auth.ts

  // Create initial admin if none exists
  apiRouter.post("/initialize", async (_req, res) => {
    try {
      // Check if admin exists
      const adminCount = await storage.countUsersByRole('admin');
      if (adminCount > 0) {
        return res.status(200).json({ message: "แอดมินมีอยู่แล้ว" });
      }

      // Ensure uploads directory exists
      const uploadsDir = path.join(process.cwd(), "uploads");
      if (!fs.existsSync(uploadsDir)) {
        fs.mkdirSync(uploadsDir, { recursive: true });
      }

      // Create admin user
      const hashedPassword = await hashPassword('admin123');
      const adminUser = await storage.createUser({
        username: 'admin',
        email: 'admin@real.fm',
        password: hashedPassword,
        fullName: 'System Administrator',
        artistName: 'Admin',
        profilePicture: null,
        role: 'admin',
        packageType: 'free',
      });

      // Create test artist accounts
      const testAccounts = [];
      const packages = ['free', 'basic', 'pro'] as const;

      for (let i = 0; i < packages.length; i++) {
        const packageType = packages[i];
        const hashedPassword = await hashPassword('password123');

        const testArtist = await storage.createUser({
          username: `testartist${i+1}`,
          email: `testartist${i+1}@example.com`,
          password: hashedPassword,
          fullName: `Test Artist ${i+1}`,
          artistName: `TestArtist${i+1}`,
          role: 'artist',
          packageType,
          profilePicture: null,
        });

        testAccounts.push(testArtist);
      }

      res.status(201).json({ 
        message: "สร้างแอดมินและบัญชีทดสอบสำเร็จ!",
        admin: adminUser,
        testAccounts
      });
    } catch (error) {
      console.error("Error creating admin:", error);
      res.status(500).json({ message: "เกิดข้อผิดพลาดในการสร้างแอดมิน" });
    }
  });

  // Tracks API

  // Tracks routes - using controller for better organization
  apiRouter.get("/tracks", requireAuth, trackController.getAllTracks);
  apiRouter.get("/tracks/:id", requireAuth, trackController.getTrackById);
  apiRouter.post("/tracks", requireAuth, upload.single('audioFile'), trackController.createTrack);
  apiRouter.patch("/tracks/:id/status", requireAdmin, trackController.updateTrackStatus);
  apiRouter.delete("/tracks/:id", requireAuth, trackController.deleteTrack);

  // Streaming and analytics routes
  // apiRouter.get("/tracks/:id/stats", requireAuth, streamingController.getTrackStreamingStats);
  // apiRouter.get("/tracks/:id/revenue", requireAuth, streamingController.getTrackRevenue);
  // apiRouter.post("/tracks/:id/distribute", requireAuth, streamingController.distributeTrack);
  // apiRouter.get("/artist/revenue", requireAuth, streamingController.getArtistRevenue);
  // apiRouter.get("/artist/analytics", requireAuth, streamingController.getArtistAnalytics);
  
  // Spotify API endpoints
  apiRouter.get("/spotify/search/tracks", requireAuth, streamingController.searchSpotifyTracks);
  apiRouter.get("/spotify/search/artists", requireAuth, streamingController.searchSpotifyArtists);
  apiRouter.get("/spotify/tracks/:id", requireAuth, streamingController.getSpotifyTrackDetails);
  apiRouter.get("/spotify/artists/:id", requireAuth, streamingController.getSpotifyArtistDetails);
  apiRouter.get("/spotify/artists/:id/top-tracks", requireAuth, streamingController.getSpotifyArtistTopTracks);

  // Payment and package upgrade routes
  apiRouter.post("/payments/upgrade", requireAuth, async (req: Request, res: Response) => {
    try {
      const { packageType, discountCode } = req.body;
      
      // Validate package type
      if (!packageType || !['basic', 'pro'].includes(packageType)) {
        return res.status(400).json({ message: 'Invalid package type' });
      }
      
      // Double-check user is authenticated (should be covered by requireAuth)
      if (!req.user) {
        return res.status(401).json({ message: 'ต้องเข้าสู่ระบบก่อนใช้งาน' });
      }
      
      const currentUser = req.user as Express.User;
      
      // Get current user
      const user = await storage.getUser(currentUser.id);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Check if user is already on this package
      if (user.packageType === packageType) {
        return res.status(400).json({ message: 'You already have this package' });
      }
      
      // In a real app, you would handle payment processing here
      // This would include credit card processing, discount validation, etc.
      
      // For demo purposes, we'll just update the user's package
      const updatedUser = await storage.updateUser(currentUser.id, { packageType });
      
      // Create a notification about the upgrade
      await storage.createNotification({
        userId: currentUser.id,
        type: 'payment',
        title: 'แพ็คเกจถูกอัปเกรดแล้ว',
        message: `คุณได้อัปเกรดเป็นแพ็คเกจ ${packageType === 'basic' ? 'Basic' : 'Pro'} เรียบร้อยแล้ว`,
        isRead: false,
        linkUrl: null,
        relatedId: null,
        createdAt: new Date()
      });
      
      res.json({ 
        success: true, 
        message: 'Package upgraded successfully',
        user: updatedUser
      });
    } catch (error) {
      console.error('Error upgrading package:', error);
      res.status(500).json({ message: 'Failed to upgrade package' });
    }
  });

  // User profile management
  apiRouter.get("/users/profile", requireAuth, async (req: Request, res: Response) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "ต้องเข้าสู่ระบบก่อนใช้งาน" });
      }
      
      const currentUser = req.user as Express.User;
      const user = await storage.getUser(currentUser.id);
      
      if (!user) {
        return res.status(404).json({ message: "ไม่พบข้อมูลผู้ใช้" });
      }
      res.json(user);
    } catch (error) {
      console.error("Error fetching profile:", error);
      res.status(500).json({ message: "ไม่สามารถดึงข้อมูลโปรไฟล์ได้" });
    }
  });

  // Upload profile image
  apiRouter.post("/users/profile/image", requireAuth, upload.single('profileImage'), async (req: Request, res: Response) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "ต้องเข้าสู่ระบบก่อนใช้งาน" });
      }

      if (!req.file) {
        return res.status(400).json({ message: "ไม่พบไฟล์รูปภาพที่อัพโหลด" });
      }
      
      console.log("Uploaded file:", req.file);
      
      // Get file path 
      const imageUrl = `/uploads/profiles/${req.file.filename}`;
      console.log("Image URL for database:", imageUrl);
      
      // Update user profile with image URL
      const currentUser = req.user as Express.User;
      const userId = currentUser.id;
      const updatedUser = await storage.updateUser(userId, { profilePicture: imageUrl });
      
      if (!updatedUser) {
        return res.status(404).json({ message: "ไม่พบข้อมูลผู้ใช้" });
      }
      
      console.log("User updated successfully with new profile picture");
      
      res.json({ 
        message: "อัพโหลดรูปภาพสำเร็จ", 
        imageUrl,
        user: updatedUser
      });
    } catch (error) {
      console.error("Error uploading profile image:", error);
      res.status(500).json({ message: "ไม่สามารถอัพโหลดรูปภาพได้", error: String(error) });
    }
  });

  apiRouter.patch("/users/profile", requireAuth, async (req: Request, res: Response) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "ต้องเข้าสู่ระบบก่อนใช้งาน" });
      }

      const currentUser = req.user as Express.User;
      const userId = currentUser.id;
      const { 
        username, 
        artistName, 
        email, 
        bio, 
        website, 
        phone, 
        location, 
        instagram, 
        facebook, 
        twitter,
        profilePicture 
      } = req.body;

      // Check if username is already taken by another user
      if (username !== currentUser.username) {
        const existingUser = await storage.getUserByUsername(username);
        if (existingUser && existingUser.id !== userId) {
          return res.status(409).json({ message: "ชื่อผู้ใช้นี้ถูกใช้งานแล้ว" });
        }
      }

      // Check if email is already taken by another user
      if (email !== currentUser.email) {
        const existingUser = await storage.getUserByEmail(email);
        if (existingUser && existingUser.id !== userId) {
          return res.status(409).json({ message: "อีเมลนี้ถูกใช้งานแล้ว" });
        }
      }

      // Update user profile
      const user = await storage.updateUser(userId, {
        username,
        artistName,
        email,
        bio,
        website,
        phone,
        location,
        instagram,
        facebook,
        twitter,
        profilePicture
      });

      if (!user) {
        return res.status(404).json({ message: "ไม่พบข้อมูลผู้ใช้" });
      }

      res.json({ message: "อัปเดตโปรไฟล์สำเร็จ", user });
    } catch (error) {
      console.error("Error updating profile:", error);
      res.status(500).json({ message: "ไม่สามารถอัปเดตโปรไฟล์ได้" });
    }
  });

  // Notification routes
  // Get user notifications
  apiRouter.get("/notifications", requireAuth, async (req: Request, res: Response) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "ต้องเข้าสู่ระบบก่อนใช้งาน" });
      }
      
      const currentUser = req.user as Express.User;
      const notifications = await storage.getUserNotifications(currentUser.id);
      res.json(notifications);
    } catch (error) {
      console.error("Error fetching notifications:", error);
      res.status(500).json({ message: "ไม่สามารถดึงข้อมูลการแจ้งเตือนได้" });
    }
  });

  // Get unread notifications count
  apiRouter.get("/notifications/unread/count", requireAuth, async (req: Request, res: Response) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "ต้องเข้าสู่ระบบก่อนใช้งาน" });
      }
      
      const currentUser = req.user as Express.User;
      const count = await storage.getUserUnreadNotificationsCount(currentUser.id);
      res.json({ count });
    } catch (error) {
      console.error("Error fetching unread notifications count:", error);
      res.status(500).json({ message: "ไม่สามารถนับการแจ้งเตือนที่ยังไม่ได้อ่านได้" });
    }
  });

  // Mark notification as read
  apiRouter.patch("/notifications/:id/read", requireAuth, async (req: Request, res: Response) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "ต้องเข้าสู่ระบบก่อนใช้งาน" });
      }
      
      const notificationId = parseInt(req.params.id);
      if (isNaN(notificationId)) {
        return res.status(400).json({ message: "รหัสการแจ้งเตือนไม่ถูกต้อง" });
      }

      const updatedNotification = await storage.markNotificationAsRead(notificationId);
      if (!updatedNotification) {
        return res.status(404).json({ message: "ไม่พบการแจ้งเตือนนี้" });
      }

      res.json({ message: "อัปเดตสถานะการแจ้งเตือนเรียบร้อยแล้ว", notification: updatedNotification });
    } catch (error) {
      console.error("Error marking notification as read:", error);
      res.status(500).json({ message: "ไม่สามารถอัปเดตสถานะการแจ้งเตือนได้" });
    }
  });

  // Mark all notifications as read
  apiRouter.patch("/notifications/read-all", requireAuth, async (req: Request, res: Response) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "ต้องเข้าสู่ระบบก่อนใช้งาน" });
      }
      
      const currentUser = req.user as Express.User;
      await storage.markAllUserNotificationsAsRead(currentUser.id);
      res.json({ message: "อัปเดตสถานะการแจ้งเตือนทั้งหมดเรียบร้อยแล้ว" });
    } catch (error) {
      console.error("Error marking all notifications as read:", error);
      res.status(500).json({ message: "ไม่สามารถอัปเดตสถานะการแจ้งเตือนทั้งหมดได้" });
    }
  });

  // User password update
  apiRouter.patch("/users/password", requireAuth, async (req: Request, res: Response) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "ต้องเข้าสู่ระบบก่อนใช้งาน" });
      }

      const currentUser = req.user as Express.User;
      const userId = currentUser.id;
      const { currentPassword, newPassword } = req.body;

      // Get the user's current password hash
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "ไม่พบข้อมูลผู้ใช้" });
      }

      // Import auth functions
      const { comparePasswords, hashPassword } = await import('./auth');

      // Verify current password
      const isPasswordCorrect = await comparePasswords(currentPassword, user.password);
      if (!isPasswordCorrect) {
        return res.status(400).json({ message: "รหัสผ่านปัจจุบันไม่ถูกต้อง" });
      }

      // Hash and update the new password
      const hashedPassword = await hashPassword(newPassword);
      await storage.updateUser(userId, { password: hashedPassword });

      res.json({ message: "อัปเดตรหัสผ่านสำเร็จ" });
    } catch (error) {
      console.error("Error updating password:", error);
      res.status(500).json({ message: "ไม่สามารถอัปเดตรหัสผ่านได้" });
    }
  });
  
  // Managed Artists routes
  
  // Get all managed artists for the current user
  apiRouter.get("/artists/managed", requireAuth, async (req: Request, res: Response) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "ต้องเข้าสู่ระบบก่อนใช้งาน" });
      }
      
      const currentUser = req.user as Express.User;
      const artists = await storage.getManagedArtistsByManager(currentUser.id);
      res.json(artists);
    } catch (error) {
      console.error("Error fetching managed artists:", error);
      res.status(500).json({ message: "ไม่สามารถดึงข้อมูลศิลปินที่จัดการได้", error: String(error) });
    }
  });
  
  // Create a new managed artist
  apiRouter.post("/artists/managed", requireAuth, async (req: Request, res: Response) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "ต้องเข้าสู่ระบบก่อนใช้งาน" });
      }
      
      const currentUser = req.user as Express.User;
      const { artistName, fullName, bio, spotifyUrl, appleMusicUrl } = req.body;
      
      if (!artistName || !fullName) {
        return res.status(400).json({ message: "ต้องระบุชื่อศิลปินและชื่อจริง" });
      }
      
      // Check if this is the first artist, if so make it primary
      const existingArtists = await storage.getManagedArtistsByManager(currentUser.id);
      const isPrimary = existingArtists.length === 0;
      
      const newArtist = await storage.createManagedArtist({
        managerId: currentUser.id,
        artistName,
        fullName,
        bio: bio || null,
        spotifyUrl: spotifyUrl || null,
        appleMusicUrl: appleMusicUrl || null,
        isPrimary
      });
      
      res.status(201).json(newArtist);
    } catch (error) {
      console.error("Error creating managed artist:", error);
      res.status(500).json({ message: "ไม่สามารถสร้างศิลปินที่จัดการได้", error: String(error) });
    }
  });
  
  // Get a specific managed artist
  apiRouter.get("/artists/managed/:id", requireAuth, async (req: Request, res: Response) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "ต้องเข้าสู่ระบบก่อนใช้งาน" });
      }
      
      const currentUser = req.user as Express.User;
      const artistId = parseInt(req.params.id);
      
      if (isNaN(artistId)) {
        return res.status(400).json({ message: "รหัสศิลปินไม่ถูกต้อง" });
      }
      
      const artist = await storage.getManagedArtist(artistId);
      
      if (!artist) {
        return res.status(404).json({ message: "ไม่พบศิลปินที่ระบุ" });
      }
      
      // Check if this artist belongs to the current user
      if (artist.managerId !== currentUser.id) {
        return res.status(403).json({ message: "คุณไม่มีสิทธิ์เข้าถึงศิลปินนี้" });
      }
      
      res.json(artist);
    } catch (error) {
      console.error("Error fetching managed artist:", error);
      res.status(500).json({ message: "ไม่สามารถดึงข้อมูลศิลปินที่จัดการได้", error: String(error) });
    }
  });
  
  // Update a managed artist
  apiRouter.patch("/artists/managed/:id", requireAuth, async (req: Request, res: Response) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "ต้องเข้าสู่ระบบก่อนใช้งาน" });
      }
      
      const currentUser = req.user as Express.User;
      const artistId = parseInt(req.params.id);
      
      if (isNaN(artistId)) {
        return res.status(400).json({ message: "รหัสศิลปินไม่ถูกต้อง" });
      }
      
      const artist = await storage.getManagedArtist(artistId);
      
      if (!artist) {
        return res.status(404).json({ message: "ไม่พบศิลปินที่ระบุ" });
      }
      
      // Check if this artist belongs to the current user
      if (artist.managerId !== currentUser.id) {
        return res.status(403).json({ message: "คุณไม่มีสิทธิ์แก้ไขศิลปินนี้" });
      }
      
      const { artistName, fullName, bio, spotifyUrl, appleMusicUrl } = req.body;
      
      const updatedArtist = await storage.updateManagedArtist(artistId, {
        artistName,
        fullName,
        bio,
        spotifyUrl,
        appleMusicUrl
      });
      
      res.json(updatedArtist);
    } catch (error) {
      console.error("Error updating managed artist:", error);
      res.status(500).json({ message: "ไม่สามารถอัพเดทข้อมูลศิลปินที่จัดการได้", error: String(error) });
    }
  });
  
  // Upload profile image for a managed artist
  apiRouter.post("/artists/managed/:id/image", requireAuth, upload.single('profileImage'), async (req: Request, res: Response) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "ต้องเข้าสู่ระบบก่อนใช้งาน" });
      }
      
      const currentUser = req.user as Express.User;
      const artistId = parseInt(req.params.id);
      
      if (isNaN(artistId)) {
        return res.status(400).json({ message: "รหัสศิลปินไม่ถูกต้อง" });
      }
      
      if (!req.file) {
        return res.status(400).json({ message: "ไม่พบไฟล์รูปภาพที่อัพโหลด" });
      }
      
      const artist = await storage.getManagedArtist(artistId);
      
      if (!artist) {
        return res.status(404).json({ message: "ไม่พบศิลปินที่ระบุ" });
      }
      
      // Check if this artist belongs to the current user
      if (artist.managerId !== currentUser.id) {
        return res.status(403).json({ message: "คุณไม่มีสิทธิ์แก้ไขศิลปินนี้" });
      }
      
      // Get file path
      const imageUrl = `/uploads/profiles/${req.file.filename}`;
      
      // Update artist with image URL
      const updatedArtist = await storage.updateManagedArtist(artistId, { profilePicture: imageUrl });
      
      if (!updatedArtist) {
        return res.status(404).json({ message: "ไม่พบข้อมูลศิลปิน" });
      }
      
      res.json({ 
        message: "อัพโหลดรูปภาพสำเร็จ", 
        imageUrl,
        artist: updatedArtist
      });
    } catch (error) {
      console.error("Error uploading artist profile image:", error);
      res.status(500).json({ message: "ไม่สามารถอัพโหลดรูปภาพได้", error: String(error) });
    }
  });
  
  // Set a managed artist as primary
  apiRouter.patch("/artists/managed/:id/primary", requireAuth, async (req: Request, res: Response) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "ต้องเข้าสู่ระบบก่อนใช้งาน" });
      }
      
      const currentUser = req.user as Express.User;
      const artistId = parseInt(req.params.id);
      
      if (isNaN(artistId)) {
        return res.status(400).json({ message: "รหัสศิลปินไม่ถูกต้อง" });
      }
      
      const artist = await storage.getManagedArtist(artistId);
      
      if (!artist) {
        return res.status(404).json({ message: "ไม่พบศิลปินที่ระบุ" });
      }
      
      // Check if this artist belongs to the current user
      if (artist.managerId !== currentUser.id) {
        return res.status(403).json({ message: "คุณไม่มีสิทธิ์แก้ไขศิลปินนี้" });
      }
      
      // Set this artist as primary
      const updatedArtist = await storage.setManagedArtistAsPrimary(artistId, currentUser.id);
      
      res.json({ 
        message: "ตั้งเป็นศิลปินหลักสำเร็จ", 
        artist: updatedArtist
      });
    } catch (error) {
      console.error("Error setting primary artist:", error);
      res.status(500).json({ message: "ไม่สามารถตั้งค่าศิลปินหลักได้", error: String(error) });
    }
  });
  
  // Delete a managed artist
  apiRouter.delete("/artists/managed/:id", requireAuth, async (req: Request, res: Response) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "ต้องเข้าสู่ระบบก่อนใช้งาน" });
      }
      
      const currentUser = req.user as Express.User;
      const artistId = parseInt(req.params.id);
      
      if (isNaN(artistId)) {
        return res.status(400).json({ message: "รหัสศิลปินไม่ถูกต้อง" });
      }
      
      const artist = await storage.getManagedArtist(artistId);
      
      if (!artist) {
        return res.status(404).json({ message: "ไม่พบศิลปินที่ระบุ" });
      }
      
      // Check if this artist belongs to the current user
      if (artist.managerId !== currentUser.id) {
        return res.status(403).json({ message: "คุณไม่มีสิทธิ์ลบศิลปินนี้" });
      }
      
      // Check if this is a primary artist - can't delete primary artist
      if (artist.isPrimary) {
        return res.status(400).json({ message: "ไม่สามารถลบศิลปินหลักได้ กรุณาตั้งศิลปินอื่นเป็นศิลปินหลักก่อน" });
      }
      
      // Delete artist
      await storage.deleteManagedArtist(artistId);
      
      res.json({ message: "ลบศิลปินสำเร็จ" });
    } catch (error) {
      console.error("Error deleting managed artist:", error);
      res.status(500).json({ message: "ไม่สามารถลบศิลปินได้", error: String(error) });
    }
  });

  // Mount API routes
  app.use("/api", apiRouter);

  // Serve static files for uploads
  app.use("/uploads", express.static(path.join(process.cwd(), "uploads")));

  // Create HTTP server
  const httpServer = createServer(app);

  return httpServer;
}