import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import express, { Express } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User as SelectUser } from "@shared/schema";

declare global {
  namespace Express {
    interface User extends SelectUser {}
  }
}

const scryptAsync = promisify(scrypt);

export async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

export async function comparePasswords(supplied: string, stored: string) {
  // Handle old passwords that might not be in the format "hash.salt"
  if (!stored.includes(".")) {
    // For backward compatibility with old hash method (if any)
    return false;
  }
  
  const [hashed, salt] = stored.split(".");
  if (!hashed || !salt) {
    return false;
  }
  
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

export function setupAuth(app: Express) {
  const SESSION_SECRET = process.env.SESSION_SECRET || 'real-fm-music-distribution-platform-secret';
  
  const sessionSettings: session.SessionOptions = {
    secret: SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    store: storage.sessionStore,
    cookie: {
      secure: process.env.NODE_ENV === 'production',
      maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
    }
  };

  app.set("trust proxy", 1);
  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        if (!user) {
          return done(null, false, { message: "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง" });
        }
        
        const isValidPassword = await comparePasswords(password, user.password);
        if (!isValidPassword) {
          return done(null, false, { message: "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง" });
        }

        return done(null, user);
      } catch (error) {
        console.error("Auth error:", error);
        return done(error);
      }
    }),
  );

  passport.serializeUser((user, done) => done(null, user.id));
  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (error) {
      done(error);
    }
  });

  const router = express.Router();

  // Registration route
  router.post("/signup", async (req, res, next) => {
    try {
      // Check if the username is already taken
      const existingUser = await storage.getUserByUsername(req.body.username);
      if (existingUser) {
        return res.status(400).json({ message: "ชื่อผู้ใช้นี้ถูกใช้งานแล้ว" });
      }
      
      // Check if the email is already taken
      const existingEmail = await storage.getUserByEmail(req.body.email);
      if (existingEmail) {
        return res.status(400).json({ message: "อีเมลนี้ถูกใช้งานแล้ว" });
      }

      // Hash the password
      const hashedPassword = await hashPassword(req.body.password);
      
      // Create the user
      const user = await storage.createUser({
        ...req.body,
        password: hashedPassword,
      });

      // Log the user in
      req.login(user, (err) => {
        if (err) return next(err);
        return res.status(201).json({ message: "สร้างบัญชีผู้ใช้สำเร็จ", user });
      });
    } catch (error) {
      next(error);
    }
  });

  // Login route
  router.post("/login", (req, res, next) => {
    passport.authenticate("local", (err: Error, user: SelectUser, info: any) => {
      if (err) return next(err);
      if (!user) {
        return res.status(401).json({ message: info?.message || "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง" });
      }
      
      req.login(user, (err) => {
        if (err) return next(err);
        return res.status(200).json({ message: "เข้าสู่ระบบสำเร็จ", user });
      });
    })(req, res, next);
  });

  // Logout route
  router.post("/logout", (req, res, next) => {
    req.logout((err) => {
      if (err) return next(err);
      req.session.destroy((err) => {
        if (err) return next(err);
        res.clearCookie('connect.sid');
        return res.status(200).json({ message: "ออกจากระบบสำเร็จ" });
      });
    });
  });

  // Get current user
  router.get("/me", (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "ต้องเข้าสู่ระบบก่อนใช้งาน" });
    }
    res.json(req.user);
  });

  // Create admin user route (only for initial setup)
  router.post("/create-admin", async (req, res, next) => {
    try {
      // Check if admin exists
      const adminCount = await storage.countUsersByRole('admin');
      
      // If there is already an admin, only allow creation by an authenticated admin
      if (adminCount > 0) {
        if (!req.isAuthenticated() || req.user.role !== 'admin') {
          return res.status(403).json({ message: "ไม่มีสิทธิ์สร้างผู้ดูแลระบบ" });
        }
      }
      
      // Hash the password
      const hashedPassword = await hashPassword(req.body.password);
      
      // Create admin user
      const adminUser = await storage.createUser({
        ...req.body,
        password: hashedPassword,
        role: 'admin',
      });

      res.status(201).json({ 
        message: "สร้างผู้ดูแลระบบสำเร็จ", 
        user: adminUser 
      });
    } catch (error) {
      next(error);
    }
  });

  // Create test accounts route (only for admins)
  router.post("/create-test-accounts", async (req, res, next) => {
    try {
      // Only allow admins to create test accounts
      if (!req.isAuthenticated() || req.user.role !== 'admin') {
        return res.status(403).json({ message: "ไม่มีสิทธิ์สร้างบัญชีทดสอบ" });
      }
      
      const testAccounts = [];
      
      // Create test artist accounts (free, basic, pro)
      const packages = ['free', 'basic', 'pro'] as const;
      for (let i = 0; i < packages.length; i++) {
        const packageType = packages[i];
        const hashedPassword = await hashPassword('password123');
        
        const testArtist = await storage.createUser({
          username: `testartist${i+1}`,
          email: `testartist${i+1}@example.com`,
          password: hashedPassword,
          fullName: `Test Artist ${i+1}`,
          artistName: `TestArtist${i+1}`,
          role: 'artist',
          packageType,
          profilePicture: null,
        });
        
        testAccounts.push(testArtist);
      }
      
      res.status(201).json({ 
        message: "สร้างบัญชีทดสอบสำเร็จ", 
        testAccounts 
      });
    } catch (error) {
      next(error);
    }
  });

  app.use('/api/auth', router);
}