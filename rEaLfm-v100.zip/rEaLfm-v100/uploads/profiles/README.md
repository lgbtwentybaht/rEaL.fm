This directory is for storing profile images
