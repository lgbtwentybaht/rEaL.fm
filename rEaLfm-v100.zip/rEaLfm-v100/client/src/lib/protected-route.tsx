import { useAuth } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";
import { Redirect, Route } from "wouter";

export function ProtectedRoute({
  path,
  component: Component,
  role
}: {
  path: string;
  component: () => React.JSX.Element | null;
  role?: 'artist' | 'admin';
}) {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <Route path={path}>
        <div className="flex items-center justify-center min-h-screen">
          <Loader2 className="h-8 w-8 animate-spin text-border" />
        </div>
      </Route>
    );
  }

  // Check if user is authenticated
  if (!user) {
    return (
      <Route path={path}>
        <Redirect to="/auth" />
      </Route>
    );
  }

  // Allow users to access dashboard pages based on role
  if (path.startsWith('/dashboard')) {
    if (user.role === 'admin' || user.role === 'artist') {
      return <Route path={path} component={Component} />;
    }
  }

  // Handle admin routes
  if (path.startsWith('/admin')) {
    if (user.role === 'admin') {
      return <Route path={path} component={Component} />;
    }
    return <Route path={path}><Redirect to="/dashboard" /></Route>;
  }

  // Default case - allow access
  return <Route path={path} component={Component} />;
}