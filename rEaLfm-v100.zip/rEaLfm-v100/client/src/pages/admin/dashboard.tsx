import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart2, Check, Music, RefreshCw, Users, Clock, X, AlertCircle } from "lucide-react";
import { User, Track } from "@shared/schema";
import { DashboardHeader } from "@/components/dashboard/DashboardHeader";
import { DashboardNav } from "@/components/dashboard/DashboardNav";

export const AdminNav = DashboardNav;

export default function AdminDashboard() {
  const [, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState("overview");

  // Fetch admin data
  const { data: userData, isLoading: isLoadingUser } = useQuery({
    queryKey: ['/api/auth/me'],
    queryFn: () => apiRequest<User>({ url: '/api/auth/me', method: 'GET' })
  });

  // Fetch all users (for admin)
  const { data: usersData, isLoading: isLoadingUsers } = useQuery({
    queryKey: ['/api/admin/users'],
    queryFn: () => apiRequest<User[]>({ url: '/api/admin/users', method: 'GET' }),
    enabled: userData?.role === 'admin'
  });

  // Fetch all tracks (for admin)
  const { data: tracksData, isLoading: isLoadingTracks } = useQuery({
    queryKey: ['/api/admin/tracks'],
    queryFn: () => apiRequest<Track[]>({ url: '/api/admin/tracks', method: 'GET' }),
    enabled: userData?.role === 'admin'
  });

  // Admin stats
  const getStatCards = () => {
    const userCount = usersData?.length || 0;
    const artistCount = usersData?.filter(user => user.role === 'artist').length || 0;
    const trackCount = tracksData?.length || 0;
    const pendingTracks = tracksData?.filter(track => track.status === 'pending').length || 0;

    return [
      {
        title: "ผู้ใช้ทั้งหมด",
        value: userCount.toString(),
        icon: Users,
        description: `${artistCount} ศิลปิน`,
        color: "bg-blue-50 text-blue-600",
      },
      {
        title: "เพลงทั้งหมด",
        value: trackCount.toString(),
        icon: Music,
        description: "จำนวนเพลงทั้งหมดในระบบ",
        color: "bg-green-50 text-green-600",
      },
      {
        title: "เพลงรอตรวจสอบ",
        value: pendingTracks.toString(),
        icon: Clock,
        description: "เพลงที่รอการอนุมัติ",
        color: "bg-yellow-50 text-yellow-600",
      },
      {
        title: "แพลตฟอร์ม",
        value: "15",
        icon: BarChart2,
        description: "แพลตฟอร์มที่รองรับ",
        color: "bg-purple-50 text-purple-600",
      },
    ];
  };

  const statCards = getStatCards();

  // Calculate recent track status
  const getRecentTrackStatusDistribution = () => {
    if (!tracksData || tracksData.length === 0) return { live: 0, pending: 0, rejected: 0 };
    
    const last30Days = new Date();
    last30Days.setDate(last30Days.getDate() - 30);
    
    const recentTracks = tracksData.filter(track => new Date(track.createdAt) > last30Days);
    
    const statusCount = {
      live: recentTracks.filter(track => track.status === 'live').length,
      pending: recentTracks.filter(track => track.status === 'pending').length,
      rejected: recentTracks.filter(track => track.status === 'rejected').length,
    };
    
    return statusCount;
  };

  const trackStatusCount = getRecentTrackStatusDistribution();

  if (isLoadingUser) {
    return (
      <div className="flex h-screen w-full items-center justify-center">
        <div className="flex flex-col items-center gap-2">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
          <p className="text-sm text-muted-foreground">กำลังโหลดข้อมูล...</p>
        </div>
      </div>
    );
  }

  // Verify admin access
  if (userData && userData.role !== 'admin') {
    // Redirect non-admin users
    navigate("/dashboard");
    return null;
  }

  return (
    <div className="flex min-h-screen bg-background">
      {/* Sidebar */}
      <DashboardNav />

      {/* Main content */}
      <div className="flex-1 overflow-hidden">
        <DashboardHeader user={userData} />

        <main className="flex-1 overflow-y-auto p-6">
          <div className="mx-auto max-w-6xl space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold tracking-tight">ระบบจัดการ</h1>
                <p className="text-muted-foreground">
                  ยินดีต้อนรับผู้ดูแลระบบ, {userData?.fullName || userData?.username}
                </p>
              </div>
            </div>

            <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab} className="space-y-6">
              <TabsList>
                <TabsTrigger value="overview">ภาพรวม</TabsTrigger>
                <TabsTrigger value="users">ผู้ใช้งาน</TabsTrigger>
                <TabsTrigger value="tracks">เพลง</TabsTrigger>
                <TabsTrigger value="reports">รายงาน</TabsTrigger>
              </TabsList>
              
              {/* Overview Tab */}
              <TabsContent value="overview" className="space-y-6">
                {/* Stats overview */}
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                  {statCards.map((stat, index) => (
                    <Card key={index}>
                      <CardHeader className={`rounded-t-lg ${stat.color}`}>
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-lg">{stat.title}</CardTitle>
                          <stat.icon className="h-5 w-5" />
                        </div>
                      </CardHeader>
                      <CardContent className="pt-6">
                        <div className="text-3xl font-bold">{stat.value}</div>
                        <p className="text-sm text-muted-foreground mt-1">
                          {stat.description}
                        </p>
                      </CardContent>
                    </Card>
                  ))}
                </div>

                {/* Recent activity */}
                <div className="grid gap-6 md:grid-cols-2">
                  {/* Recent tracks */}
                  <Card>
                    <CardHeader>
                      <CardTitle>เพลงล่าสุด</CardTitle>
                      <CardDescription>เพลงที่อัปโหลดล่าสุดที่รอการตรวจสอบ</CardDescription>
                    </CardHeader>
                    <CardContent>
                      {isLoadingTracks ? (
                        <div className="flex justify-center p-4">
                          <div className="h-6 w-6 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
                        </div>
                      ) : (
                        <div className="space-y-4">
                          {tracksData && tracksData.length > 0 ? (
                            tracksData
                              .filter(track => track.status === 'pending')
                              .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
                              .slice(0, 5)
                              .map(track => (
                                <div key={track.id} className="flex items-center justify-between border-b pb-2 last:border-0">
                                  <div className="flex items-center">
                                    <div className="h-8 w-8 bg-gray-100 rounded-md flex items-center justify-center mr-3">
                                      <Music className="h-4 w-4 text-gray-500" />
                                    </div>
                                    <div>
                                      <p className="text-sm font-medium">{track.title}</p>
                                      <p className="text-xs text-muted-foreground">
                                        อัปโหลดเมื่อ {new Date(track.createdAt).toLocaleDateString('th-TH')}
                                      </p>
                                    </div>
                                  </div>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => navigate(`/admin/tracks/${track.id}`)}
                                  >
                                    ตรวจสอบ
                                  </Button>
                                </div>
                              ))
                          ) : (
                            <div className="text-center py-4 text-muted-foreground">
                              ไม่มีเพลงที่รอการตรวจสอบ
                            </div>
                          )}
                        </div>
                      )}
                    </CardContent>
                    <CardFooter>
                      <Button
                        variant="outline"
                        size="sm"
                        className="w-full"
                        onClick={() => setActiveTab("tracks")}
                      >
                        ดูทั้งหมด
                      </Button>
                    </CardFooter>
                  </Card>

                  {/* Track stats */}
                  <Card>
                    <CardHeader>
                      <CardTitle>สถิติการตรวจสอบเพลง</CardTitle>
                      <CardDescription>
                        สถิติการตรวจสอบเพลงในช่วง 30 วันที่ผ่านมา
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center">
                            <div className="mr-2 h-8 w-8 rounded-full bg-green-100 flex items-center justify-center">
                              <Check className="h-4 w-4 text-green-600" />
                            </div>
                            <div>
                              <p className="text-sm font-medium">อนุมัติแล้ว</p>
                              <p className="text-xs text-muted-foreground">เพลงที่ผ่านการตรวจสอบ</p>
                            </div>
                          </div>
                          <div className="text-2xl font-bold">{trackStatusCount.live}</div>
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <div className="flex items-center">
                            <div className="mr-2 h-8 w-8 rounded-full bg-yellow-100 flex items-center justify-center">
                              <Clock className="h-4 w-4 text-yellow-600" />
                            </div>
                            <div>
                              <p className="text-sm font-medium">รอตรวจสอบ</p>
                              <p className="text-xs text-muted-foreground">เพลงที่ยังรอการตรวจสอบ</p>
                            </div>
                          </div>
                          <div className="text-2xl font-bold">{trackStatusCount.pending}</div>
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <div className="flex items-center">
                            <div className="mr-2 h-8 w-8 rounded-full bg-red-100 flex items-center justify-center">
                              <X className="h-4 w-4 text-red-600" />
                            </div>
                            <div>
                              <p className="text-sm font-medium">ไม่ผ่านการตรวจสอบ</p>
                              <p className="text-xs text-muted-foreground">เพลงที่ไม่ผ่านเกณฑ์</p>
                            </div>
                          </div>
                          <div className="text-2xl font-bold">{trackStatusCount.rejected}</div>
                        </div>
                      </div>
                    </CardContent>
                    <CardFooter>
                      <Button
                        variant="outline"
                        size="sm"
                        className="w-full"
                        onClick={() => setActiveTab("reports")}
                      >
                        ดูรายงานเพิ่มเติม
                      </Button>
                    </CardFooter>
                  </Card>
                </div>
              </TabsContent>

              {/* Users Tab */}
              <TabsContent value="users" className="space-y-6">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                      <CardTitle>รายชื่อผู้ใช้งาน</CardTitle>
                      <CardDescription>
                        ผู้ใช้งานและศิลปินทั้งหมดในระบบ
                      </CardDescription>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => navigate("/admin/users")}
                    >
                      ดูทั้งหมด
                    </Button>
                  </CardHeader>
                  <CardContent>
                    {isLoadingUsers ? (
                      <div className="flex justify-center p-4">
                        <div className="h-6 w-6 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {usersData && usersData.length > 0 ? (
                          usersData.slice(0, 5).map(user => (
                            <div key={user.id} className="flex items-center justify-between border-b pb-2 last:border-0">
                              <div className="flex items-center">
                                <div className="h-8 w-8 bg-primary/10 rounded-full flex items-center justify-center mr-3 text-xs font-bold">
                                  {user.artistName?.[0] || user.username[0]}
                                </div>
                                <div>
                                  <p className="text-sm font-medium">{user.artistName || user.username}</p>
                                  <p className="text-xs text-muted-foreground">
                                    {user.email}
                                  </p>
                                </div>
                              </div>
                              <div className="flex items-center">
                                <span className={`inline-flex rounded-full px-2 py-0.5 text-xs font-medium ${
                                  user.role === 'admin' ? 'bg-purple-50 text-purple-600' : 'bg-blue-50 text-blue-600'
                                }`}>
                                  {user.role === 'admin' ? 'ผู้ดูแลระบบ' : 'ศิลปิน'}
                                </span>
                              </div>
                            </div>
                          ))
                        ) : (
                          <div className="text-center py-4 text-muted-foreground">
                            ไม่พบข้อมูลผู้ใช้
                          </div>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Tracks Tab */}
              <TabsContent value="tracks" className="space-y-6">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                      <CardTitle>เพลงที่รอการตรวจสอบ</CardTitle>
                      <CardDescription>
                        เพลงทั้งหมดที่รอการตรวจสอบ
                      </CardDescription>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => navigate("/admin/tracks")}
                    >
                      ดูทั้งหมด
                    </Button>
                  </CardHeader>
                  <CardContent>
                    {isLoadingTracks ? (
                      <div className="flex justify-center p-4">
                        <div className="h-6 w-6 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {tracksData && tracksData
                          .filter(track => track.status === 'pending')
                          .length > 0 ? (
                          tracksData
                            .filter(track => track.status === 'pending')
                            .map(track => (
                              <div key={track.id} className="flex items-center justify-between border-b pb-2 last:border-0">
                                <div className="flex items-center">
                                  <div className="h-8 w-8 bg-gray-100 rounded-md flex items-center justify-center mr-3">
                                    <Music className="h-4 w-4 text-gray-500" />
                                  </div>
                                  <div>
                                    <p className="text-sm font-medium">{track.title}</p>
                                    <p className="text-xs text-muted-foreground">
                                      {`ศิลปิน ID: ${track.userId} • ${track.genre} • อัปโหลดเมื่อ ${new Date(track.createdAt).toLocaleDateString('th-TH')}`}
                                    </p>
                                  </div>
                                </div>
                                <div className="flex space-x-2">
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => navigate(`/admin/tracks/${track.id}`)}
                                  >
                                    ตรวจสอบ
                                  </Button>
                                </div>
                              </div>
                            ))
                        ) : (
                          <div className="text-center py-4 text-muted-foreground">
                            ไม่มีเพลงที่รอการตรวจสอบ
                          </div>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Reports Tab */}
              <TabsContent value="reports" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>รายงานสรุป</CardTitle>
                    <CardDescription>
                      รายงานสรุปสถิติการใช้งานระบบ
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="h-80 flex items-center justify-center">
                    <div className="text-center">
                      <BarChart2 className="mx-auto h-16 w-16 text-muted-foreground" />
                      <p className="mt-2 text-sm text-muted-foreground">
                        รายงานแบบละเอียดจะอยู่ที่นี่
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>
    </div>
  );
}