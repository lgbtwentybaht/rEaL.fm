import { useState, useEffect } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useLocation, useRoute } from "wouter";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { AdminNav } from "@/components/admin/AdminNav";
import { AdminHeader } from "@/components/admin/AdminHeader";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ChevronLeft, User, ShieldCheck, Loader2, Save } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { User as UserType } from "@shared/schema";

// User schema
const editUserSchema = z.object({
  username: z
    .string()
    .min(3, "ชื่อผู้ใช้ต้องมีอย่างน้อย 3 ตัวอักษร")
    .max(30, "ชื่อผู้ใช้ต้องไม่เกิน 30 ตัวอักษร")
    .regex(/^[a-zA-Z0-9_]+$/, "ชื่อผู้ใช้ต้องประกอบด้วยตัวอักษร ตัวเลข หรือ _ เท่านั้น"),
  email: z
    .string()
    .email("รูปแบบอีเมลไม่ถูกต้อง"),
  password: z
    .string()
    .min(8, "รหัสผ่านต้องมีอย่างน้อย 8 ตัวอักษร")
    .optional()
    .or(z.literal("")),
  confirmPassword: z
    .string()
    .min(8, "รหัสผ่านต้องมีอย่างน้อย 8 ตัวอักษร")
    .optional()
    .or(z.literal("")),
  role: z.enum(["artist", "admin"]),
  artistName: z
    .string()
    .min(2, "ชื่อศิลปินต้องมีอย่างน้อย 2 ตัวอักษร")
    .max(50, "ชื่อศิลปินต้องไม่เกิน 50 ตัวอักษร")
    .optional()
    .or(z.literal("")),
  fullName: z
    .string()
    .min(2, "ชื่อ-นามสกุลต้องมีอย่างน้อย 2 ตัวอักษร")
    .max(100, "ชื่อ-นามสกุลต้องไม่เกิน 100 ตัวอักษร"),
  bio: z
    .string()
    .max(500, "ประวัติต้องไม่เกิน 500 ตัวอักษร")
    .optional()
    .or(z.literal("")),
  packageType: z.enum(["free", "basic", "pro"]),
}).refine((data) => !data.password || !data.confirmPassword || data.password === data.confirmPassword, {
  message: "รหัสผ่านไม่ตรงกัน",
  path: ["confirmPassword"],
});

type EditUserFormValues = z.infer<typeof editUserSchema>;

export default function EditUserPage() {
  const [activeTab, setActiveTab] = useState("account");
  const [, navigate] = useLocation();
  const [match, params] = useRoute("/admin/users/edit/:id");
  const { toast } = useToast();
  const userId = params?.id ? parseInt(params.id) : null;

  // Form setup
  const form = useForm<EditUserFormValues>({
    resolver: zodResolver(editUserSchema),
    defaultValues: {
      username: "",
      email: "",
      password: "",
      confirmPassword: "",
      role: "artist",
      artistName: "",
      fullName: "",
      bio: "",
      packageType: "free",
    },
  });

  // Fetch user data
  const {
    data: user,
    isLoading,
    error,
  } = useQuery<UserType>({
    queryKey: [`/api/admin/users/${userId}`],
    enabled: !!userId,
  });

  // Update form values when user data is loaded
  useEffect(() => {
    if (user) {
      form.reset({
        username: user.username,
        email: user.email,
        password: "",
        confirmPassword: "",
        role: user.role as "artist" | "admin",
        artistName: user.artistName || "",
        fullName: user.fullName || "",
        bio: user.bio || "",
        packageType: user.packageType as "free" | "basic" | "pro",
      });
    }
  }, [user, form]);

  // Watch role for conditional rendering
  const userRole = form.watch("role");

  // Update user mutation
  const updateUserMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest({
        url: `/api/admin/users/${userId}`,
        method: "PATCH",
        body: data
      });
    },
    onSuccess: () => {
      toast({
        title: "อัปเดตผู้ใช้สำเร็จ",
        description: "ข้อมูลผู้ใช้ถูกอัปเดตเรียบร้อยแล้ว",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      queryClient.invalidateQueries({ queryKey: [`/api/admin/users/${userId}`] });
    },
    onError: (error: Error) => {
      toast({
        title: "ไม่สามารถอัปเดตผู้ใช้ได้",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Form submission handler
  const onSubmit = (data: EditUserFormValues) => {
    // If user is admin, clear artist-specific fields
    if (data.role === "admin") {
      data.artistName = "";
      data.bio = "";
    }

    // Otherwise if role is artist but artistName is empty, use username
    else if (data.role === "artist" && (!data.artistName || data.artistName.trim() === "")) {
      data.artistName = data.username;
    }

    // Remove password fields if empty
    const finalData = { ...data };
    if (!finalData.password) {
      delete finalData.password;
      delete finalData.confirmPassword;
    }

    updateUserMutation.mutate(finalData);
  };

  if (isLoading) {
    return (
      <div className="flex min-h-screen bg-background">
        <AdminNav />
        
        <div className="flex-1">
          <AdminHeader title="แก้ไขผู้ใช้" description="แก้ไขข้อมูลผู้ใช้" />
          
          <main className="flex-1 p-6 flex items-center justify-center">
            <div className="text-center">
              <Loader2 className="h-12 w-12 animate-spin mx-auto mb-4 text-primary" />
              <p className="text-muted-foreground">กำลังโหลดข้อมูล...</p>
            </div>
          </main>
        </div>
      </div>
    );
  }

  if (error || !userId) {
    return (
      <div className="flex min-h-screen bg-background">
        <AdminNav />
        
        <div className="flex-1">
          <AdminHeader title="แก้ไขผู้ใช้" description="แก้ไขข้อมูลผู้ใช้" />
          
          <main className="flex-1 p-6">
            <div className="mb-6">
              <Button 
                variant="outline" 
                className="flex items-center gap-1" 
                onClick={() => navigate("/admin/users")}
              >
                <ChevronLeft className="h-4 w-4" />
                กลับไปหน้ารายชื่อผู้ใช้
              </Button>
            </div>
            
            <div className="text-center p-6 bg-red-50 rounded-lg border border-red-100">
              <p className="text-red-500 mb-2">
                {error ? "เกิดข้อผิดพลาดในการโหลดข้อมูลผู้ใช้" : "ไม่พบผู้ใช้ที่ต้องการแก้ไข"}
              </p>
              <Button 
                onClick={() => navigate("/admin/users")}
                variant="outline"
              >
                กลับไปหน้ารายชื่อผู้ใช้
              </Button>
            </div>
          </main>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-background">
      <AdminNav />
      
      <div className="flex-1">
        <AdminHeader title={`แก้ไขผู้ใช้: ${user?.username}`} description="แก้ไขข้อมูลผู้ใช้" />
        
        <main className="flex-1 p-6">
          <div className="mb-6">
            <Button 
              variant="outline" 
              className="flex items-center gap-1" 
              onClick={() => navigate("/admin/users")}
            >
              <ChevronLeft className="h-4 w-4" />
              กลับไปหน้ารายชื่อผู้ใช้
            </Button>
          </div>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="mb-4">
                  <TabsTrigger value="account">
                    <User className="mr-2 h-4 w-4" />
                    ข้อมูลบัญชี
                  </TabsTrigger>
                  <TabsTrigger value="profile">
                    <User className="mr-2 h-4 w-4" />
                    ข้อมูลโปรไฟล์
                  </TabsTrigger>
                </TabsList>
                
                <TabsContent value="account">
                  <Card>
                    <CardHeader>
                      <CardTitle>ข้อมูลบัญชีผู้ใช้</CardTitle>
                      <CardDescription>
                        แก้ไขข้อมูลสำหรับการเข้าสู่ระบบและการตั้งค่าบัญชี
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex flex-wrap gap-4">
                        <div className="space-y-2 flex-1 min-w-[300px]">
                          <FormField
                            control={form.control}
                            name="username"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>ชื่อผู้ใช้ <span className="text-red-500">*</span></FormLabel>
                                <FormControl>
                                  <Input placeholder="username" {...field} />
                                </FormControl>
                                <FormDescription>
                                  ชื่อผู้ใช้สำหรับการเข้าสู่ระบบ
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <div className="space-y-2 flex-1 min-w-[300px]">
                          <FormField
                            control={form.control}
                            name="email"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>อีเมล <span className="text-red-500">*</span></FormLabel>
                                <FormControl>
                                  <Input 
                                    type="email"
                                    placeholder="email@example.com" 
                                    {...field} 
                                  />
                                </FormControl>
                                <FormDescription>
                                  อีเมลที่ใช้ในการติดต่อและรับข้อมูลข่าวสาร
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      </div>
                      
                      <div className="flex flex-wrap gap-4">
                        <div className="space-y-2 flex-1 min-w-[300px]">
                          <FormField
                            control={form.control}
                            name="password"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>รหัสผ่าน</FormLabel>
                                <FormControl>
                                  <Input 
                                    type="password"
                                    placeholder="เว้นว่างไว้ถ้าไม่ต้องการเปลี่ยน"
                                    {...field} 
                                  />
                                </FormControl>
                                <FormDescription>
                                  เว้นว่างไว้หากไม่ต้องการเปลี่ยนรหัสผ่าน
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <div className="space-y-2 flex-1 min-w-[300px]">
                          <FormField
                            control={form.control}
                            name="confirmPassword"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>ยืนยันรหัสผ่าน</FormLabel>
                                <FormControl>
                                  <Input 
                                    type="password"
                                    placeholder="เว้นว่างไว้ถ้าไม่ต้องการเปลี่ยน"
                                    {...field} 
                                  />
                                </FormControl>
                                <FormDescription>
                                  กรอกรหัสผ่านอีกครั้งเพื่อยืนยัน
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <FormField
                          control={form.control}
                          name="role"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>ประเภทผู้ใช้ <span className="text-red-500">*</span></FormLabel>
                              <div className="flex gap-4 mt-2">
                                <div className="flex items-center">
                                  <FormControl>
                                    <input
                                      type="radio"
                                      id="role-artist"
                                      value="artist"
                                      checked={field.value === "artist"}
                                      onChange={() => field.onChange("artist")}
                                      className="h-4 w-4 border-gray-300 text-primary focus:ring-primary"
                                    />
                                  </FormControl>
                                  <label
                                    htmlFor="role-artist"
                                    className="ml-2 block text-sm font-medium leading-6"
                                  >
                                    <div className="flex items-center">
                                      <User className="mr-1 h-4 w-4" />
                                      ศิลปิน
                                    </div>
                                  </label>
                                </div>
                                <div className="flex items-center">
                                  <FormControl>
                                    <input
                                      type="radio"
                                      id="role-admin"
                                      value="admin"
                                      checked={field.value === "admin"}
                                      onChange={() => field.onChange("admin")}
                                      className="h-4 w-4 border-gray-300 text-primary focus:ring-primary"
                                    />
                                  </FormControl>
                                  <label
                                    htmlFor="role-admin"
                                    className="ml-2 block text-sm font-medium leading-6"
                                  >
                                    <div className="flex items-center">
                                      <ShieldCheck className="mr-1 h-4 w-4" />
                                      ผู้ดูแลระบบ
                                    </div>
                                  </label>
                                </div>
                              </div>
                              <FormDescription>
                                กำหนดสิทธิ์และความสามารถในการเข้าถึงระบบ
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <FormField
                          control={form.control}
                          name="packageType"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>แพ็คเกจ <span className="text-red-500">*</span></FormLabel>
                              <div className="flex gap-4 mt-2">
                                <div className="flex items-center">
                                  <FormControl>
                                    <input
                                      type="radio"
                                      id="package-free"
                                      checked={field.value === "free"}
                                      onChange={() => field.onChange("free")}
                                      className="h-4 w-4 border-gray-300 text-primary focus:ring-primary"
                                    />
                                  </FormControl>
                                  <label
                                    htmlFor="package-free"
                                    className="ml-2 block text-sm font-medium leading-6"
                                  >
                                    ฟรี
                                  </label>
                                </div>
                                <div className="flex items-center">
                                  <FormControl>
                                    <input
                                      type="radio"
                                      id="package-basic"
                                      checked={field.value === "basic"}
                                      onChange={() => field.onChange("basic")}
                                      className="h-4 w-4 border-gray-300 text-primary focus:ring-primary"
                                    />
                                  </FormControl>
                                  <label
                                    htmlFor="package-basic"
                                    className="ml-2 block text-sm font-medium leading-6"
                                  >
                                    พื้นฐาน
                                  </label>
                                </div>
                                <div className="flex items-center">
                                  <FormControl>
                                    <input
                                      type="radio"
                                      id="package-pro"
                                      checked={field.value === "pro"}
                                      onChange={() => field.onChange("pro")}
                                      className="h-4 w-4 border-gray-300 text-primary focus:ring-primary"
                                    />
                                  </FormControl>
                                  <label
                                    htmlFor="package-pro"
                                    className="ml-2 block text-sm font-medium leading-6"
                                  >
                                    โปร
                                  </label>
                                </div>
                              </div>
                              <FormDescription>
                                แพ็คเกจที่ผู้ใช้ลงทะเบียน
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
                
                <TabsContent value="profile">
                  <Card>
                    <CardHeader>
                      <CardTitle>ข้อมูลโปรไฟล์</CardTitle>
                      <CardDescription>
                        แก้ไขข้อมูลส่วนตัวและรายละเอียดศิลปิน
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {userRole === "artist" && (
                        <div className="flex flex-wrap gap-4">
                          <div className="space-y-2 flex-1 min-w-[300px]">
                            <FormField
                              control={form.control}
                              name="artistName"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>ชื่อศิลปิน</FormLabel>
                                  <FormControl>
                                    <Input 
                                      placeholder="ชื่อที่ใช้แสดงต่อผู้ฟัง" 
                                      {...field} 
                                      value={field.value || ""}
                                    />
                                  </FormControl>
                                  <FormDescription>
                                    ชื่อที่จะแสดงให้ผู้ฟังเห็น
                                  </FormDescription>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                          
                          <div className="space-y-2 flex-1 min-w-[300px]">
                            <FormField
                              control={form.control}
                              name="fullName"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>ชื่อ-นามสกุล <span className="text-red-500">*</span></FormLabel>
                                  <FormControl>
                                    <Input 
                                      placeholder="ชื่อจริง นามสกุล" 
                                      {...field} 
                                      value={field.value || ""}
                                    />
                                  </FormControl>
                                  <FormDescription>
                                    ชื่อและนามสกุลจริงของผู้ใช้
                                  </FormDescription>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                        </div>
                      )}
                      
                      {userRole === "admin" && (
                        <div className="space-y-2">
                          <FormField
                            control={form.control}
                            name="fullName"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>ชื่อ-นามสกุล <span className="text-red-500">*</span></FormLabel>
                                <FormControl>
                                  <Input 
                                    placeholder="ชื่อจริง นามสกุล" 
                                    {...field} 
                                    value={field.value || ""}
                                  />
                                </FormControl>
                                <FormDescription>
                                  ชื่อและนามสกุลจริงของผู้ดูแลระบบ
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      )}
                      
                      {userRole === "artist" && (
                        <div className="space-y-2">
                          <FormField
                            control={form.control}
                            name="bio"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>ประวัติศิลปิน</FormLabel>
                                <FormControl>
                                  <Textarea 
                                    placeholder="เล่าเกี่ยวกับตัวคุณหรือผลงานของคุณ..." 
                                    className="min-h-24" 
                                    {...field} 
                                    value={field.value || ""}
                                  />
                                </FormControl>
                                <FormDescription>
                                  ประวัติและข้อมูลเกี่ยวกับตัวศิลปินที่จะแสดงในโปรไฟล์
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
              
              <div className="flex justify-end">
                <Button
                  type="button"
                  variant="outline"
                  className="mr-2"
                  onClick={() => navigate("/admin/users")}
                >
                  ยกเลิก
                </Button>
                <Button 
                  type="submit"
                  disabled={updateUserMutation.isPending}
                  className="gap-1"
                >
                  {updateUserMutation.isPending ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      กำลังบันทึก...
                    </>
                  ) : (
                    <>
                      <Save className="h-4 w-4" />
                      บันทึกการเปลี่ยนแปลง
                    </>
                  )}
                </Button>
              </div>
            </form>
          </Form>
        </main>
      </div>
    </div>
  );
}