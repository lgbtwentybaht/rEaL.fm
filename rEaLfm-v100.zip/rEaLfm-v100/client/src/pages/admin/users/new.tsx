import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { AdminNav } from "@/components/admin/AdminNav";
import { AdminHeader } from "@/components/admin/AdminHeader";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ChevronLeft, User, ShieldCheck } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

// User schema
const newUserSchema = z.object({
  username: z
    .string()
    .min(3, "ชื่อผู้ใช้ต้องมีอย่างน้อย 3 ตัวอักษร")
    .max(30, "ชื่อผู้ใช้ต้องไม่เกิน 30 ตัวอักษร")
    .regex(/^[a-zA-Z0-9_]+$/, "ชื่อผู้ใช้ต้องประกอบด้วยตัวอักษร ตัวเลข หรือ _ เท่านั้น"),
  email: z
    .string()
    .email("รูปแบบอีเมลไม่ถูกต้อง"),
  password: z
    .string()
    .min(8, "รหัสผ่านต้องมีอย่างน้อย 8 ตัวอักษร"),
  confirmPassword: z
    .string()
    .min(8, "รหัสผ่านต้องมีอย่างน้อย 8 ตัวอักษร"),
  role: z.enum(["artist", "admin"]),
  artistName: z
    .string()
    .min(2, "ชื่อศิลปินต้องมีอย่างน้อย 2 ตัวอักษร")
    .max(50, "ชื่อศิลปินต้องไม่เกิน 50 ตัวอักษร")
    .optional()
    .or(z.literal("")),
  fullName: z
    .string()
    .min(2, "ชื่อ-นามสกุลต้องมีอย่างน้อย 2 ตัวอักษร")
    .max(100, "ชื่อ-นามสกุลต้องไม่เกิน 100 ตัวอักษร"),
  bio: z
    .string()
    .max(500, "ประวัติต้องไม่เกิน 500 ตัวอักษร")
    .optional()
    .or(z.literal("")),
  packageType: z.enum(["free", "basic", "pro"]),
}).refine((data) => data.password === data.confirmPassword, {
  message: "รหัสผ่านไม่ตรงกัน",
  path: ["confirmPassword"],
});

type NewUserFormValues = z.infer<typeof newUserSchema>;

export default function NewUserPage() {
  const [activeTab, setActiveTab] = useState("account");
  const [, navigate] = useLocation();
  const { toast } = useToast();

  // Form setup
  const form = useForm<NewUserFormValues>({
    resolver: zodResolver(newUserSchema),
    defaultValues: {
      username: "",
      email: "",
      password: "",
      confirmPassword: "",
      role: "artist",
      artistName: "",
      fullName: "",
      bio: "",
      packageType: "free",
    },
  });

  // Watch role for conditional rendering
  const userRole = form.watch("role");

  // Create user mutation
  const createUserMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest("POST", "/api/admin/users", data);
    },
    onSuccess: () => {
      toast({
        title: "สร้างผู้ใช้สำเร็จ",
        description: "ผู้ใช้ใหม่ถูกสร้างเรียบร้อยแล้ว",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      navigate("/admin/users");
    },
    onError: (error: Error) => {
      toast({
        title: "ไม่สามารถสร้างผู้ใช้ได้",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Form submission handler
  const onSubmit = (data: NewUserFormValues) => {
    // If user is admin, clear artist-specific fields
    if (data.role === "admin") {
      data.artistName = "";
      data.bio = "";
    }

    // Otherwise if role is artist but artistName is empty, use username
    else if (data.role === "artist" && (!data.artistName || data.artistName.trim() === "")) {
      data.artistName = data.username;
    }

    createUserMutation.mutate(data);
  };

  return (
    <div className="flex min-h-screen bg-background">
      <AdminNav />
      
      <div className="flex-1">
        <AdminHeader title="เพิ่มผู้ใช้ใหม่" description="สร้างบัญชีผู้ใช้ใหม่ในระบบ" />
        
        <main className="flex-1 p-6">
          <div className="mb-6">
            <Button 
              variant="outline" 
              className="flex items-center gap-1" 
              onClick={() => navigate("/admin/users")}
            >
              <ChevronLeft className="h-4 w-4" />
              กลับไปหน้ารายชื่อผู้ใช้
            </Button>
          </div>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="mb-4">
                  <TabsTrigger value="account">
                    <User className="mr-2 h-4 w-4" />
                    ข้อมูลบัญชี
                  </TabsTrigger>
                  <TabsTrigger value="profile">
                    <User className="mr-2 h-4 w-4" />
                    ข้อมูลโปรไฟล์
                  </TabsTrigger>
                </TabsList>
                
                <TabsContent value="account">
                  <Card>
                    <CardHeader>
                      <CardTitle>ข้อมูลบัญชีผู้ใช้</CardTitle>
                      <CardDescription>
                        กรอกข้อมูลสำหรับการเข้าสู่ระบบและการตั้งค่าบัญชี
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex gap-4">
                        <div className="space-y-2 flex-1">
                          <FormField
                            control={form.control}
                            name="username"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>ชื่อผู้ใช้ <span className="text-red-500">*</span></FormLabel>
                                <FormControl>
                                  <Input placeholder="username" {...field} />
                                </FormControl>
                                <FormDescription>
                                  ชื่อผู้ใช้สำหรับการเข้าสู่ระบบ
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <div className="space-y-2 flex-1">
                          <FormField
                            control={form.control}
                            name="email"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>อีเมล <span className="text-red-500">*</span></FormLabel>
                                <FormControl>
                                  <Input 
                                    type="email"
                                    placeholder="email@example.com" 
                                    {...field} 
                                  />
                                </FormControl>
                                <FormDescription>
                                  อีเมลที่ใช้ในการติดต่อและรับข้อมูลข่าวสาร
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      </div>
                      
                      <div className="flex gap-4">
                        <div className="space-y-2 flex-1">
                          <FormField
                            control={form.control}
                            name="password"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>รหัสผ่าน <span className="text-red-500">*</span></FormLabel>
                                <FormControl>
                                  <Input 
                                    type="password"
                                    placeholder="••••••••"
                                    {...field} 
                                  />
                                </FormControl>
                                <FormDescription>
                                  รหัสผ่านต้องมีความยาวอย่างน้อย 8 ตัวอักษร
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <div className="space-y-2 flex-1">
                          <FormField
                            control={form.control}
                            name="confirmPassword"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>ยืนยันรหัสผ่าน <span className="text-red-500">*</span></FormLabel>
                                <FormControl>
                                  <Input 
                                    type="password"
                                    placeholder="••••••••"
                                    {...field} 
                                  />
                                </FormControl>
                                <FormDescription>
                                  กรอกรหัสผ่านอีกครั้งเพื่อยืนยัน
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <FormField
                          control={form.control}
                          name="role"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>ประเภทผู้ใช้ <span className="text-red-500">*</span></FormLabel>
                              <div className="flex gap-4 mt-2">
                                <div className="flex items-center">
                                  <FormControl>
                                    <input
                                      type="radio"
                                      id="role-artist"
                                      value="artist"
                                      checked={field.value === "artist"}
                                      onChange={() => field.onChange("artist")}
                                      className="h-4 w-4 border-gray-300 text-primary focus:ring-primary"
                                    />
                                  </FormControl>
                                  <label
                                    htmlFor="role-artist"
                                    className="ml-2 block text-sm font-medium leading-6"
                                  >
                                    <div className="flex items-center">
                                      <User className="mr-1 h-4 w-4" />
                                      ศิลปิน
                                    </div>
                                  </label>
                                </div>
                                <div className="flex items-center">
                                  <FormControl>
                                    <input
                                      type="radio"
                                      id="role-admin"
                                      value="admin"
                                      checked={field.value === "admin"}
                                      onChange={() => field.onChange("admin")}
                                      className="h-4 w-4 border-gray-300 text-primary focus:ring-primary"
                                    />
                                  </FormControl>
                                  <label
                                    htmlFor="role-admin"
                                    className="ml-2 block text-sm font-medium leading-6"
                                  >
                                    <div className="flex items-center">
                                      <ShieldCheck className="mr-1 h-4 w-4" />
                                      ผู้ดูแลระบบ
                                    </div>
                                  </label>
                                </div>
                              </div>
                              <FormDescription>
                                กำหนดสิทธิ์และความสามารถในการเข้าถึงระบบ
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <FormField
                          control={form.control}
                          name="packageType"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>แพ็คเกจ <span className="text-red-500">*</span></FormLabel>
                              <div className="flex gap-4 mt-2">
                                <div className="flex items-center">
                                  <FormControl>
                                    <input
                                      type="radio"
                                      id="package-free"
                                      checked={field.value === "free"}
                                      onChange={() => field.onChange("free")}
                                      className="h-4 w-4 border-gray-300 text-primary focus:ring-primary"
                                    />
                                  </FormControl>
                                  <label
                                    htmlFor="package-free"
                                    className="ml-2 block text-sm font-medium leading-6"
                                  >
                                    ฟรี
                                  </label>
                                </div>
                                <div className="flex items-center">
                                  <FormControl>
                                    <input
                                      type="radio"
                                      id="package-basic"
                                      checked={field.value === "basic"}
                                      onChange={() => field.onChange("basic")}
                                      className="h-4 w-4 border-gray-300 text-primary focus:ring-primary"
                                    />
                                  </FormControl>
                                  <label
                                    htmlFor="package-basic"
                                    className="ml-2 block text-sm font-medium leading-6"
                                  >
                                    พื้นฐาน
                                  </label>
                                </div>
                                <div className="flex items-center">
                                  <FormControl>
                                    <input
                                      type="radio"
                                      id="package-pro"
                                      checked={field.value === "pro"}
                                      onChange={() => field.onChange("pro")}
                                      className="h-4 w-4 border-gray-300 text-primary focus:ring-primary"
                                    />
                                  </FormControl>
                                  <label
                                    htmlFor="package-pro"
                                    className="ml-2 block text-sm font-medium leading-6"
                                  >
                                    โปร
                                  </label>
                                </div>
                              </div>
                              <FormDescription>
                                กำหนดแพ็คเกจการใช้งานของผู้ใช้
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </CardContent>
                    <CardFooter className="flex justify-between">
                      <Button 
                        type="button" 
                        variant="outline" 
                        onClick={() => navigate("/admin/users")}
                      >
                        ยกเลิก
                      </Button>
                      <Button 
                        type="button" 
                        onClick={() => setActiveTab("profile")}
                      >
                        ถัดไป
                      </Button>
                    </CardFooter>
                  </Card>
                </TabsContent>
                
                <TabsContent value="profile">
                  <Card>
                    <CardHeader>
                      <CardTitle>ข้อมูลโปรไฟล์</CardTitle>
                      <CardDescription>
                        กรอกข้อมูลโปรไฟล์ส่วนตัวของผู้ใช้
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex gap-4">
                        <div className="space-y-2 flex-1">
                          <FormField
                            control={form.control}
                            name="fullName"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>ชื่อ-นามสกุล <span className="text-red-500">*</span></FormLabel>
                                <FormControl>
                                  <Input placeholder="ชื่อ นามสกุล" {...field} />
                                </FormControl>
                                <FormDescription>
                                  ชื่อและนามสกุลจริงของผู้ใช้
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        {userRole === "artist" && (
                          <div className="space-y-2 flex-1">
                            <FormField
                              control={form.control}
                              name="artistName"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>ชื่อศิลปิน</FormLabel>
                                  <FormControl>
                                    <Input placeholder="ชื่อที่ใช้แสดงตัวตนของศิลปิน" {...field} />
                                  </FormControl>
                                  <FormDescription>
                                    ชื่อที่ใช้แสดงบนระบบสตรีมมิงและต่อสาธารณะ
                                  </FormDescription>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                        )}
                      </div>
                      
                      {userRole === "artist" && (
                        <div className="space-y-2">
                          <FormField
                            control={form.control}
                            name="bio"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>ประวัติศิลปิน</FormLabel>
                                <FormControl>
                                  <Textarea 
                                    placeholder="ประวัติหรือข้อมูลเกี่ยวกับศิลปิน" 
                                    className="min-h-[120px]"
                                    {...field} 
                                  />
                                </FormControl>
                                <FormDescription>
                                  ข้อมูลเกี่ยวกับประวัติและผลงานของศิลปิน
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      )}
                    </CardContent>
                    <CardFooter className="flex justify-between">
                      <div className="flex gap-2">
                        <Button 
                          type="button" 
                          variant="outline" 
                          onClick={() => setActiveTab("account")}
                        >
                          ย้อนกลับ
                        </Button>
                        <Button 
                          type="button" 
                          variant="outline" 
                          onClick={() => navigate("/admin/users")}
                        >
                          ยกเลิก
                        </Button>
                      </div>
                      <Button 
                        type="submit"
                        disabled={createUserMutation.isPending}
                      >
                        {createUserMutation.isPending ? (
                          <>
                            <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-background border-t-transparent"></div>
                            กำลังสร้างผู้ใช้...
                          </>
                        ) : (
                          "สร้างผู้ใช้ใหม่"
                        )}
                      </Button>
                    </CardFooter>
                  </Card>
                </TabsContent>
              </Tabs>
            </form>
          </Form>
        </main>
      </div>
    </div>
  );
}