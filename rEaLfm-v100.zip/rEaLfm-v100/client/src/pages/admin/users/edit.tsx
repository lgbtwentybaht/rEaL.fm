import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useLocation, useParams } from "wouter";
import { z } from "zod";
import { User } from "@shared/schema";
import { AdminNav } from "../dashboard";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowLeft, Save, UserCog, Package, ShieldAlert } from "lucide-react";
import { Separator } from "@/components/ui/separator";

// Form schema for user edit
const userEditSchema = z.object({
  username: z.string().min(3, "ชื่อผู้ใช้ต้องมีความยาวอย่างน้อย 3 ตัวอักษร"),
  email: z.string().email("กรุณาใส่อีเมลที่ถูกต้อง"),
  fullName: z.string().min(2, "ชื่อต้องมีความยาวอย่างน้อย 2 ตัวอักษร"),
  artistName: z.string().min(2, "ชื่อศิลปินต้องมีความยาวอย่างน้อย 2 ตัวอักษร"),
  role: z.enum(["admin", "artist"]),
  packageType: z.enum(["free", "basic", "pro"]),
});

type UserEditFormValues = z.infer<typeof userEditSchema>;

export default function EditUser() {
  const { id } = useParams();
  const [, navigate] = useLocation();
  const { user: currentUser, isLoading: isAuthLoading } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("profile");
  
  // Check if current user is admin
  if (!isAuthLoading && (!currentUser || currentUser.role !== 'admin')) {
    navigate('/auth');
    return null;
  }
  
  // Fetch user data
  const { data: user, isLoading: isUserLoading } = useQuery({
    queryKey: [`/api/admin/users/${id}`],
    queryFn: () => apiRequest<User>({ url: `/api/admin/users/${id}`, method: 'GET' }),
    enabled: !!id,
  });
  
  // Setup form with user data
  const form = useForm<UserEditFormValues>({
    resolver: zodResolver(userEditSchema),
    defaultValues: {
      username: "",
      email: "",
      fullName: "",
      artistName: "",
      role: "artist",
      packageType: "free",
    },
  });
  
  // Update form values when user data is loaded
  useEffect(() => {
    if (user) {
      form.reset({
        username: user.username,
        email: user.email,
        fullName: user.fullName || "",
        artistName: user.artistName || "",
        role: user.role,
        packageType: user.packageType,
      });
    }
  }, [user, form]);
  
  // Update user mutation
  const updateUserMutation = useMutation({
    mutationFn: async (data: UserEditFormValues) => {
      return await apiRequest<User>({
        url: `/api/admin/users/${id}`,
        method: "PATCH",
        body: data,
      });
    },
    onSuccess: () => {
      toast({
        title: "อัพเดทผู้ใช้สำเร็จ",
        description: "ข้อมูลผู้ใช้ถูกอัพเดทเรียบร้อยแล้ว",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/admin/users/${id}`] });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/users'] });
    },
    onError: (error) => {
      toast({
        title: "เกิดข้อผิดพลาด",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Handle form submission
  const onSubmit = (data: UserEditFormValues) => {
    updateUserMutation.mutate(data);
  };
  
  if (isAuthLoading || isUserLoading) {
    return (
      <div className="flex h-screen w-full items-center justify-center">
        <div className="flex flex-col items-center gap-2">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
          <p className="text-sm text-muted-foreground">กำลังโหลดข้อมูล...</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="flex min-h-screen bg-background">
      <AdminNav />
      
      <div className="flex-1 ml-64">
        <header className="border-b bg-background">
          <div className="flex h-14 items-center px-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate("/admin/users")}
              className="mr-4"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              กลับไปยังรายชื่อผู้ใช้
            </Button>
            <h1 className="text-xl font-semibold">แก้ไขผู้ใช้: {user?.username}</h1>
          </div>
        </header>
        
        <main className="p-6">
          <div className="mx-auto max-w-4xl">
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="mb-4">
                <TabsTrigger value="profile">
                  <UserCog className="mr-2 h-4 w-4" />
                  ข้อมูลผู้ใช้
                </TabsTrigger>
                <TabsTrigger value="package">
                  <Package className="mr-2 h-4 w-4" />
                  แพ็คเกจและสิทธิ์การใช้งาน
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="profile" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>ข้อมูลบัญชี</CardTitle>
                    <CardDescription>
                      แก้ไขข้อมูลบัญชีและสิทธิ์การใช้งานของผู้ใช้
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...form}>
                      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                        <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
                          <FormField
                            control={form.control}
                            name="username"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>ชื่อผู้ใช้</FormLabel>
                                <FormControl>
                                  <Input {...field} />
                                </FormControl>
                                <FormDescription>
                                  ชื่อที่ใช้ในการเข้าสู่ระบบ
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="email"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>อีเมล</FormLabel>
                                <FormControl>
                                  <Input type="email" {...field} />
                                </FormControl>
                                <FormDescription>
                                  อีเมลสำหรับการติดต่อและการแจ้งเตือน
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="fullName"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>ชื่อ-นามสกุล</FormLabel>
                                <FormControl>
                                  <Input {...field} />
                                </FormControl>
                                <FormDescription>
                                  ชื่อและนามสกุลจริงของผู้ใช้
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="artistName"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>ชื่อศิลปิน</FormLabel>
                                <FormControl>
                                  <Input {...field} />
                                </FormControl>
                                <FormDescription>
                                  ชื่อที่ใช้แสดงบนแพลตฟอร์มสตรีมมิง
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <Separator />
                        
                        <FormField
                          control={form.control}
                          name="role"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>บทบาท</FormLabel>
                              <Select
                                onValueChange={field.onChange}
                                defaultValue={field.value}
                                value={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="เลือกบทบาท" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="admin">
                                    <div className="flex items-center">
                                      <ShieldAlert className="mr-2 h-4 w-4 text-red-500" />
                                      <span>แอดมิน</span>
                                    </div>
                                  </SelectItem>
                                  <SelectItem value="artist">
                                    <div className="flex items-center">
                                      <UserCog className="mr-2 h-4 w-4 text-blue-500" />
                                      <span>ศิลปิน</span>
                                    </div>
                                  </SelectItem>
                                </SelectContent>
                              </Select>
                              <FormDescription>
                                กำหนดบทบาทและสิทธิ์การเข้าถึงของผู้ใช้
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="flex justify-end">
                          <Button 
                            type="submit" 
                            disabled={updateUserMutation.isPending}
                            className="ml-auto"
                          >
                            {updateUserMutation.isPending ? (
                              <>
                                <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-background border-t-transparent"></div>
                                กำลังบันทึก...
                              </>
                            ) : (
                              <>
                                <Save className="mr-2 h-4 w-4" />
                                บันทึกการเปลี่ยนแปลง
                              </>
                            )}
                          </Button>
                        </div>
                      </form>
                    </Form>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="package" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>แพ็คเกจและสิทธิ์การใช้งาน</CardTitle>
                    <CardDescription>
                      เปลี่ยนแปลงแพ็คเกจและกำหนดสิทธิ์การใช้งานของผู้ใช้
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...form}>
                      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                        <FormField
                          control={form.control}
                          name="packageType"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>แพ็คเกจ</FormLabel>
                              <Select
                                onValueChange={field.onChange}
                                defaultValue={field.value}
                                value={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="เลือกแพ็คเกจ" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="free">
                                    <div className="flex items-center">
                                      <span className="mr-2 h-4 w-4 rounded-full bg-gray-200"></span>
                                      <span>แพ็คเกจฟรี</span>
                                    </div>
                                  </SelectItem>
                                  <SelectItem value="basic">
                                    <div className="flex items-center">
                                      <span className="mr-2 h-4 w-4 rounded-full bg-blue-400"></span>
                                      <span>แพ็คเกจ Basic</span>
                                    </div>
                                  </SelectItem>
                                  <SelectItem value="pro">
                                    <div className="flex items-center">
                                      <span className="mr-2 h-4 w-4 rounded-full bg-purple-500"></span>
                                      <span>แพ็คเกจ Pro</span>
                                    </div>
                                  </SelectItem>
                                </SelectContent>
                              </Select>
                              <FormDescription>
                                แพ็คเกจจะกำหนดสิทธิ์การใช้งานและขีดจำกัดต่างๆ
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="mt-6 grid grid-cols-1 gap-4 md:grid-cols-3">
                          <Card className={`border-2 ${form.watch("packageType") === "free" ? "border-primary" : "border-transparent"}`}>
                            <CardHeader className="pb-2">
                              <CardTitle className="text-lg">แพ็คเกจฟรี</CardTitle>
                            </CardHeader>
                            <CardContent className="pb-2">
                              <ul className="space-y-2 text-sm">
                                <li className="flex items-center">
                                  <span className="mr-2">✓</span>
                                  <span>อัพโหลดได้ 5 เพลง</span>
                                </li>
                                <li className="flex items-center">
                                  <span className="mr-2">✓</span>
                                  <span>3 แพลตฟอร์ม</span>
                                </li>
                                <li className="flex items-center">
                                  <span className="mr-2">✓</span>
                                  <span>รายงานพื้นฐาน</span>
                                </li>
                                <li className="flex items-center">
                                  <span className="mr-2">✕</span>
                                  <span className="text-muted-foreground">ไม่มีทีมงาน</span>
                                </li>
                              </ul>
                            </CardContent>
                          </Card>
                          
                          <Card className={`border-2 ${form.watch("packageType") === "basic" ? "border-primary" : "border-transparent"}`}>
                            <CardHeader className="pb-2">
                              <CardTitle className="text-lg">แพ็คเกจ Basic</CardTitle>
                            </CardHeader>
                            <CardContent className="pb-2">
                              <ul className="space-y-2 text-sm">
                                <li className="flex items-center">
                                  <span className="mr-2">✓</span>
                                  <span>อัพโหลดได้ 30 เพลง</span>
                                </li>
                                <li className="flex items-center">
                                  <span className="mr-2">✓</span>
                                  <span>8 แพลตฟอร์ม</span>
                                </li>
                                <li className="flex items-center">
                                  <span className="mr-2">✓</span>
                                  <span>รายงานขั้นสูง</span>
                                </li>
                                <li className="flex items-center">
                                  <span className="mr-2">✓</span>
                                  <span>ทีมงาน 3 คน</span>
                                </li>
                              </ul>
                            </CardContent>
                          </Card>
                          
                          <Card className={`border-2 ${form.watch("packageType") === "pro" ? "border-primary" : "border-transparent"}`}>
                            <CardHeader className="pb-2">
                              <CardTitle className="text-lg">แพ็คเกจ Pro</CardTitle>
                            </CardHeader>
                            <CardContent className="pb-2">
                              <ul className="space-y-2 text-sm">
                                <li className="flex items-center">
                                  <span className="mr-2">✓</span>
                                  <span>ไม่จำกัดจำนวนเพลง</span>
                                </li>
                                <li className="flex items-center">
                                  <span className="mr-2">✓</span>
                                  <span>ทุกแพลตฟอร์ม</span>
                                </li>
                                <li className="flex items-center">
                                  <span className="mr-2">✓</span>
                                  <span>รายงานขั้นสูงและวิเคราะห์</span>
                                </li>
                                <li className="flex items-center">
                                  <span className="mr-2">✓</span>
                                  <span>ทีมงาน 10 คน</span>
                                </li>
                              </ul>
                            </CardContent>
                          </Card>
                        </div>
                        
                        <div className="flex justify-end">
                          <Button 
                            type="submit" 
                            disabled={updateUserMutation.isPending}
                            className="ml-auto"
                          >
                            {updateUserMutation.isPending ? (
                              <>
                                <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-background border-t-transparent"></div>
                                กำลังบันทึก...
                              </>
                            ) : (
                              <>
                                <Save className="mr-2 h-4 w-4" />
                                บันทึกการเปลี่ยนแปลง
                              </>
                            )}
                          </Button>
                        </div>
                      </form>
                    </Form>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>
    </div>
  );
}