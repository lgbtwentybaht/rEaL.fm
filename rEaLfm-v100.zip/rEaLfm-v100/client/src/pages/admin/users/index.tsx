import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useState } from "react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { AdminNav } from "@/components/admin/AdminNav";
import { AdminHeader } from "@/components/admin/AdminHeader";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  MoreHorizontal,
  Plus,
  Pencil,
  Trash2,
  Shield,
  User,
  Search,
  Loader2,
} from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { User as UserType } from "@shared/schema";

export default function UsersPage() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [userToDelete, setUserToDelete] = useState<UserType | null>(null);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);

  // Fetch users data
  const {
    data: users,
    isLoading,
    error,
  } = useQuery<UserType[]>({
    queryKey: ["/api/admin/users"],
  });

  // Delete user mutation
  const deleteUserMutation = useMutation({
    mutationFn: async (userId: number) => {
      return await apiRequest("DELETE", `/api/admin/users/${userId}`);
    },
    onSuccess: () => {
      toast({
        title: "ลบผู้ใช้สำเร็จ",
        description: "ผู้ใช้ถูกลบออกจากระบบเรียบร้อยแล้ว",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      setShowDeleteDialog(false);
    },
    onError: (error: Error) => {
      toast({
        title: "ไม่สามารถลบผู้ใช้ได้",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Handle delete confirmation
  const confirmDelete = (user: UserType) => {
    setUserToDelete(user);
    setShowDeleteDialog(true);
  };

  // Filter users by search term
  const filteredUsers = users?.filter(
    (user) =>
      user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (user.artistName && 
        user.artistName.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (user.fullName && 
        user.fullName.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  // Get role display info
  const getRoleDisplay = (role: string) => {
    if (role === "admin") {
      return {
        icon: <Shield className="h-3 w-3" />,
        label: "ผู้ดูแลระบบ",
        variant: "destructive" as const,
      };
    }
    return {
      icon: <User className="h-3 w-3" />,
      label: "ศิลปิน",
      variant: "default" as const,
    };
  };

  // Get package display info
  const getPackageDisplay = (packageType: string) => {
    switch (packageType) {
      case "free":
        return {
          label: "ฟรี",
          variant: "outline" as const,
        };
      case "basic":
        return {
          label: "พื้นฐาน",
          variant: "secondary" as const,
        };
      case "pro":
        return {
          label: "โปร",
          variant: "default" as const,
        };
      default:
        return {
          label: packageType,
          variant: "outline" as const,
        };
    }
  };

  if (isLoading) {
    return (
      <div className="flex min-h-screen bg-background">
        <AdminNav />
        <div className="flex-1">
          <AdminHeader title="จัดการผู้ใช้" description="ดูและจัดการผู้ใช้ทั้งหมดในระบบ" />
          <main className="flex-1 p-6 flex items-center justify-center">
            <div className="text-center">
              <Loader2 className="h-12 w-12 animate-spin mx-auto mb-4 text-primary" />
              <p className="text-muted-foreground">กำลังโหลดข้อมูล...</p>
            </div>
          </main>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex min-h-screen bg-background">
        <AdminNav />
        <div className="flex-1">
          <AdminHeader title="จัดการผู้ใช้" description="ดูและจัดการผู้ใช้ทั้งหมดในระบบ" />
          <main className="flex-1 p-6">
            <div className="text-center p-6 bg-red-50 rounded-lg border border-red-100">
              <p className="text-red-500 mb-2">เกิดข้อผิดพลาดในการโหลดข้อมูลผู้ใช้</p>
              <Button 
                onClick={() => queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] })}
                variant="outline"
              >
                ลองใหม่
              </Button>
            </div>
          </main>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-background">
      <AdminNav />
      
      <div className="flex-1">
        <AdminHeader 
          title="จัดการผู้ใช้" 
          description="ดูและจัดการผู้ใช้ทั้งหมดในระบบ" 
        />
        
        <main className="flex-1 p-6">
          <div className="flex justify-between items-center mb-6">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="ค้นหาผู้ใช้..."
                className="pl-8 w-[300px]"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Button 
              onClick={() => navigate("/admin/users/new")}
              className="flex items-center gap-1"
            >
              <Plus className="h-4 w-4" />
              เพิ่มผู้ใช้ใหม่
            </Button>
          </div>
          
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ผู้ใช้</TableHead>
                  <TableHead>อีเมล</TableHead>
                  <TableHead>ประเภท</TableHead>
                  <TableHead>แพ็คเกจ</TableHead>
                  <TableHead className="text-right">การจัดการ</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredUsers && filteredUsers.length > 0 ? (
                  filteredUsers.map((user) => {
                    const roleDisplay = getRoleDisplay(user.role);
                    const packageDisplay = getPackageDisplay(user.packageType);
                    
                    return (
                      <TableRow key={user.id}>
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <Avatar>
                              <AvatarImage 
                                src={user.profilePicture || ""} 
                                alt={user.artistName || user.username} 
                              />
                              <AvatarFallback>
                                {user.username.substring(0, 2).toUpperCase()}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <div className="font-medium">
                                {user.artistName || user.username}
                              </div>
                              <div className="text-sm text-muted-foreground">
                                @{user.username}
                              </div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>{user.email}</TableCell>
                        <TableCell>
                          <Badge variant={roleDisplay.variant} className="flex items-center w-fit gap-1">
                            {roleDisplay.icon}
                            {roleDisplay.label}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge variant={packageDisplay.variant}>
                            {packageDisplay.label}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" className="h-8 w-8 p-0">
                                <span className="sr-only">เปิดเมนู</span>
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>การจัดการ</DropdownMenuLabel>
                              <DropdownMenuItem 
                                onClick={() => navigate(`/admin/users/edit/${user.id}`)}
                                className="flex items-center gap-2 cursor-pointer"
                              >
                                <Pencil className="h-4 w-4" />
                                แก้ไข
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem
                                onClick={() => confirmDelete(user)}
                                className="flex items-center gap-2 text-red-500 cursor-pointer"
                              >
                                <Trash2 className="h-4 w-4" />
                                ลบ
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    );
                  })
                ) : (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-10">
                      {searchTerm ? (
                        <div>
                          <p className="text-muted-foreground mb-1">ไม่พบผู้ใช้ที่ตรงกับการค้นหา</p>
                          <p className="text-sm text-muted-foreground">ลองใช้คำค้นหาอื่น</p>
                        </div>
                      ) : (
                        <div>
                          <p className="text-muted-foreground mb-1">ยังไม่มีผู้ใช้ในระบบ</p>
                          <Button 
                            onClick={() => navigate("/admin/users/new")}
                            variant="link"
                            className="text-primary"
                          >
                            + เพิ่มผู้ใช้ใหม่
                          </Button>
                        </div>
                      )}
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
          
          {/* Delete confirmation dialog */}
          <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>ยืนยันการลบผู้ใช้</DialogTitle>
                <DialogDescription>
                  คุณแน่ใจหรือไม่ที่ต้องการลบผู้ใช้ {userToDelete?.username}?
                  การกระทำนี้ไม่สามารถย้อนกลับได้ และข้อมูลทั้งหมดของผู้ใช้จะถูกลบออกจากระบบ
                </DialogDescription>
              </DialogHeader>
              <DialogFooter>
                <Button
                  variant="outline"
                  onClick={() => setShowDeleteDialog(false)}
                >
                  ยกเลิก
                </Button>
                <Button
                  variant="destructive"
                  onClick={() => userToDelete && deleteUserMutation.mutate(userToDelete.id)}
                  disabled={deleteUserMutation.isPending}
                >
                  {deleteUserMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      กำลังลบ...
                    </>
                  ) : (
                    "ลบผู้ใช้"
                  )}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </main>
      </div>
    </div>
  );
}