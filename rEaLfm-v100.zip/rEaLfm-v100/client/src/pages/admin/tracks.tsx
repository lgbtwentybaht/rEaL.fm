import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Track } from "@shared/schema";
import { AdminNav } from "./dashboard";

import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search, MoreHorizontal, RefreshCw, CheckCircle, XCircle } from "lucide-react";

export default function AdminTracks() {
  const { user, isLoading: isAuthLoading } = useAuth();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");
  const [approveTrackId, setApproveTrackId] = useState<number | null>(null);
  const [rejectTrackId, setRejectTrackId] = useState<number | null>(null);
  
  // Check if user is admin
  if (!isAuthLoading && (!user || user.role !== 'admin')) {
    navigate('/auth');
    return null;
  }
  
  // Fetch tracks
  const { data: tracks, isLoading: isTracksLoading, refetch } = useQuery({
    queryKey: ['/api/admin/tracks'],
    queryFn: () => apiRequest<Track[]>({ url: '/api/admin/tracks', method: 'GET' }),
  });
  
  // Approve track mutation
  const approveTrackMutation = useMutation({
    mutationFn: async (trackId: number) => {
      return await apiRequest({ 
        url: `/api/admin/tracks/${trackId}/approve`, 
        method: 'POST' 
      });
    },
    onSuccess: () => {
      toast({
        title: "อนุมัติเพลงสำเร็จ",
        description: "อัพเดทสถานะเพลงเป็น 'กำลังเผยแพร่' เรียบร้อยแล้ว",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/tracks'] });
      setApproveTrackId(null);
    },
    onError: (error) => {
      toast({
        title: "เกิดข้อผิดพลาด",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Reject track mutation
  const rejectTrackMutation = useMutation({
    mutationFn: async (trackId: number) => {
      return await apiRequest({ 
        url: `/api/admin/tracks/${trackId}/reject`, 
        method: 'POST' 
      });
    },
    onSuccess: () => {
      toast({
        title: "ปฏิเสธเพลงสำเร็จ",
        description: "อัพเดทสถานะเพลงเป็น 'ถูกปฏิเสธ' เรียบร้อยแล้ว",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/tracks'] });
      setRejectTrackId(null);
    },
    onError: (error) => {
      toast({
        title: "เกิดข้อผิดพลาด",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Filter tracks by search query
  const filteredTracks = tracks?.filter(track => {
    if (!searchQuery) return true;
    
    const query = searchQuery.toLowerCase();
    return (
      track.title.toLowerCase().includes(query) ||
      track.isrc?.toLowerCase().includes(query) ||
      track.genre?.toLowerCase().includes(query)
    );
  });
  
  if (isAuthLoading) {
    return (
      <div className="flex h-screen w-full items-center justify-center">
        <div className="flex flex-col items-center gap-2">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
          <p className="text-sm text-muted-foreground">กำลังโหลดข้อมูล...</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="flex min-h-screen bg-background">
      <AdminNav />
      
      <div className="flex-1 ml-64">
        <header className="border-b bg-background">
          <div className="flex h-14 items-center px-4">
            <h1 className="text-xl font-semibold">จัดการเพลงทั้งหมด</h1>
            <div className="ml-auto flex items-center gap-4">
              <div className="relative w-64">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="ค้นหาเพลง..."
                  className="pl-8"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Button variant="outline" onClick={() => refetch()}>
                <RefreshCw className="mr-2 h-4 w-4" />
                รีเฟรช
              </Button>
            </div>
          </div>
        </header>
        
        <main className="p-6">
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[80px]">ID</TableHead>
                  <TableHead>ชื่อเพลง</TableHead>
                  <TableHead>ศิลปิน</TableHead>
                  <TableHead>วันที่อัพโหลด</TableHead>
                  <TableHead>วันที่เผยแพร่</TableHead>
                  <TableHead>ISRC</TableHead>
                  <TableHead>สถานะ</TableHead>
                  <TableHead className="text-right">การกระทำ</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isTracksLoading ? (
                  <TableRow>
                    <TableCell colSpan={8} className="h-24 text-center">
                      <div className="flex justify-center items-center h-full">
                        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
                      </div>
                    </TableCell>
                  </TableRow>
                ) : filteredTracks && filteredTracks.length > 0 ? (
                  filteredTracks.map((track) => (
                    <TableRow key={track.id}>
                      <TableCell className="font-medium">{track.id}</TableCell>
                      <TableCell>{track.title}</TableCell>
                      <TableCell>{track.userId}</TableCell>
                      <TableCell>{new Date(track.createdAt).toLocaleDateString('th-TH')}</TableCell>
                      <TableCell>{new Date(track.releaseDate).toLocaleDateString('th-TH')}</TableCell>
                      <TableCell>{track.isrc || '-'}</TableCell>
                      <TableCell>
                        <Badge variant={
                          track.status === 'live' ? 'default' :
                          track.status === 'pending' ? 'outline' :
                          track.status === 'rejected' ? 'destructive' : 'secondary'
                        }>
                          {track.status === 'live' ? 'ออนไลน์' :
                           track.status === 'pending' ? 'รอตรวจสอบ' :
                           track.status === 'processing' ? 'กำลังประมวลผล' :
                           track.status === 'distributing' ? 'กำลังเผยแพร่' :
                           track.status === 'rejected' ? 'ถูกปฏิเสธ' : 'ไม่ทราบสถานะ'}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        {track.status === 'pending' ? (
                          <div className="flex justify-end gap-2">
                            <Button 
                              size="sm" 
                              variant="outline"
                              className="flex gap-1 text-green-600 border-green-600 hover:bg-green-50 hover:text-green-700"
                              onClick={() => setApproveTrackId(track.id)}
                            >
                              <CheckCircle className="h-4 w-4" />
                              อนุมัติ
                            </Button>
                            <Button 
                              size="sm" 
                              variant="outline"
                              className="flex gap-1 text-red-600 border-red-600 hover:bg-red-50 hover:text-red-700"
                              onClick={() => setRejectTrackId(track.id)}
                            >
                              <XCircle className="h-4 w-4" />
                              ปฏิเสธ
                            </Button>
                          </div>
                        ) : (
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" className="h-8 w-8 p-0">
                                <span className="sr-only">เปิดเมนู</span>
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>การกระทำ</DropdownMenuLabel>
                              <DropdownMenuItem onClick={() => navigate(`/admin/tracks/${track.id}`)}>
                                ดูรายละเอียด
                              </DropdownMenuItem>
                              {track.status !== 'live' && track.status !== 'distributing' && (
                                <DropdownMenuItem onClick={() => setApproveTrackId(track.id)}>
                                  อนุมัติ
                                </DropdownMenuItem>
                              )}
                              {track.status !== 'rejected' && (
                                <DropdownMenuItem 
                                  className="text-red-600"
                                  onClick={() => setRejectTrackId(track.id)}
                                >
                                  ปฏิเสธ
                                </DropdownMenuItem>
                              )}
                            </DropdownMenuContent>
                          </DropdownMenu>
                        )}
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={8} className="h-24 text-center">
                      ไม่พบข้อมูลเพลง
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </main>
      </div>
      
      {/* Approve Confirmation Dialog */}
      <AlertDialog open={!!approveTrackId} onOpenChange={() => setApproveTrackId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>ยืนยันการอนุมัติเพลง</AlertDialogTitle>
            <AlertDialogDescription>
              คุณต้องการอนุมัติเพลงนี้เพื่อเผยแพร่ไปยังแพลตฟอร์มสตรีมมิ่งหรือไม่?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>ยกเลิก</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => approveTrackId && approveTrackMutation.mutate(approveTrackId)}
              className="bg-green-600 hover:bg-green-700"
            >
              {approveTrackMutation.isPending ? (
                <span className="flex items-center gap-2">
                  <span className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent"></span>
                  กำลังอนุมัติ...
                </span>
              ) : "อนุมัติเพลง"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      {/* Reject Confirmation Dialog */}
      <AlertDialog open={!!rejectTrackId} onOpenChange={() => setRejectTrackId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>ยืนยันการปฏิเสธเพลง</AlertDialogTitle>
            <AlertDialogDescription>
              คุณต้องการปฏิเสธเพลงนี้หรือไม่? ศิลปินจะได้รับการแจ้งเตือนเกี่ยวกับการปฏิเสธนี้
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>ยกเลิก</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => rejectTrackId && rejectTrackMutation.mutate(rejectTrackId)}
              className="bg-red-600 hover:bg-red-700"
            >
              {rejectTrackMutation.isPending ? (
                <span className="flex items-center gap-2">
                  <span className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent"></span>
                  กำลังปฏิเสธ...
                </span>
              ) : "ปฏิเสธเพลง"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}