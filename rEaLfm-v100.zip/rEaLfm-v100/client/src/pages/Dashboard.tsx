import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Music, Upload, BarChart2, Settings, Users, Album, Plus } from "lucide-react";
import { User, Track } from "@shared/schema";
import { DashboardHeader } from "@/components/dashboard/DashboardHeader";
import { DashboardNav } from "@/components/dashboard/DashboardNav";

export default function Dashboard() {
  const [, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState("overview");

  // Fetch user data
  const { data: userData, isLoading: isLoadingUser } = useQuery({
    queryKey: ['/api/auth/me'],
    queryFn: () => apiRequest<User>({ url: '/api/auth/me', method: 'GET' })
  });

  // Fetch user's tracks
  const { data: tracksData, isLoading: isLoadingTracks } = useQuery({
    queryKey: ['/api/tracks'],
    queryFn: () => apiRequest<Track[]>({ url: '/api/tracks', method: 'GET' })
  });

  // Stats data
  const statCards = [
    {
      title: "รวมการสตรีม",
      value: "14,309",
      change: "+12.5%",
      isPositive: true,
      description: "จากเดือนที่แล้ว",
    },
    {
      title: "รายได้ทั้งหมด",
      value: "฿8,219",
      change: "+5.2%",
      isPositive: true,
      description: "จากเดือนที่แล้ว",
    },
    {
      title: "เพลงทั้งหมด",
      value: tracksData?.length || "0",
      change: "",
      isPositive: true,
      description: "เพลงที่อัพโหลดแล้ว",
    },
    {
      title: "แพลตฟอร์ม",
      value: "15",
      change: "",
      isPositive: true,
      description: "ที่เผยแพร่แล้ว",
    },
  ];

  if (isLoadingUser) {
    return (
      <div className="flex h-screen w-full items-center justify-center">
        <div className="flex flex-col items-center gap-2">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
          <p className="text-sm text-muted-foreground">กำลังโหลดข้อมูล...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-background">
      {/* Sidebar */}
      <DashboardNav />

      {/* Main content */}
      <div className="flex-1 overflow-hidden">
        <DashboardHeader user={userData} />

        <main className="flex-1 overflow-y-auto p-6">
          <div className="mx-auto max-w-6xl space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold tracking-tight">แดชบอร์ด</h1>
                <p className="text-muted-foreground">
                  ยินดีต้อนรับกลับมา, {userData?.artistName || userData?.username}
                </p>
              </div>
              <Button
                onClick={() => navigate("/dashboard/upload")}
                className="flex items-center gap-2"
              >
                <Upload className="h-4 w-4" />
                อัพโหลดเพลงใหม่
              </Button>
            </div>

            <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab} className="space-y-4">
              <TabsList>
                <TabsTrigger value="overview">ภาพรวม</TabsTrigger>
                <TabsTrigger value="tracks">เพลงของฉัน</TabsTrigger>
                <TabsTrigger value="albums">อัลบั้ม</TabsTrigger>
                <TabsTrigger value="analytics">สถิติ</TabsTrigger>
              </TabsList>
              
              {/* Overview Tab */}
              <TabsContent value="overview" className="space-y-6">
                {/* Stats overview */}
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                  {statCards.map((stat, index) => (
                    <Card key={index}>
                      <CardHeader className="pb-2">
                        <CardDescription>{stat.title}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold">{stat.value}</div>
                        {stat.change && (
                          <p className={`text-xs ${stat.isPositive ? "text-green-500" : "text-red-500"}`}>
                            {stat.change} {stat.description}
                          </p>
                        )}
                        {!stat.change && <p className="text-xs text-muted-foreground">{stat.description}</p>}
                      </CardContent>
                    </Card>
                  ))}
                </div>

                {/* Recent tracks */}
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-semibold">เพลงล่าสุด</h2>
                    <Button variant="link" onClick={() => setActiveTab("tracks")}>ดูทั้งหมด</Button>
                  </div>
                  <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                    {isLoadingTracks && (
                      <div className="col-span-full flex justify-center p-12">
                        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
                      </div>
                    )}
                    
                    {!isLoadingTracks && tracksData && tracksData.length === 0 && (
                      <Card className="col-span-full">
                        <CardHeader>
                          <CardTitle className="text-center">ยังไม่มีเพลง</CardTitle>
                          <CardDescription className="text-center">คุณยังไม่ได้อัพโหลดเพลงใด ๆ</CardDescription>
                        </CardHeader>
                        <CardFooter className="justify-center">
                          <Button onClick={() => navigate("/dashboard/upload")} className="flex items-center gap-2">
                            <Upload className="h-4 w-4" />
                            อัพโหลดเพลงแรกของคุณ
                          </Button>
                        </CardFooter>
                      </Card>
                    )}

                    {!isLoadingTracks && tracksData && tracksData.slice(0, 3).map((track) => (
                      <Card key={track.id} className="overflow-hidden">
                        <div className="aspect-square bg-gray-100 relative">
                          <div className="absolute inset-0 flex items-center justify-center bg-black/5">
                            <Music className="h-10 w-10 text-gray-400" />
                          </div>
                        </div>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-lg truncate">{track.title}</CardTitle>
                          <CardDescription>
                            สถานะ: <span className={`font-medium ${
                              track.status === 'live' ? 'text-green-500' :
                              track.status === 'pending' ? 'text-yellow-500' :
                              track.status === 'rejected' ? 'text-red-500' : 'text-blue-500'
                            }`}>
                              {track.status === 'live' ? 'ออนไลน์' :
                               track.status === 'pending' ? 'รอการตรวจสอบ' :
                               track.status === 'processing' ? 'กำลังประมวลผล' :
                               track.status === 'distributing' ? 'กำลังเผยแพร่' :
                               track.status === 'rejected' ? 'ถูกปฏิเสธ' : 'ไม่ทราบสถานะ'}
                            </span>
                          </CardDescription>
                        </CardHeader>
                        <CardFooter>
                          <Button
                            variant="outline"
                            size="sm"
                            className="w-full"
                            onClick={() => navigate(`/dashboard/tracks/${track.id}`)}
                          >
                            ดูรายละเอียด
                          </Button>
                        </CardFooter>
                      </Card>
                    ))}
                  </div>
                </div>
              </TabsContent>

              {/* Tracks Tab */}
              <TabsContent value="tracks" className="space-y-4">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-semibold">เพลงทั้งหมด</h2>
                  <Button onClick={() => navigate("/dashboard/upload")} className="flex items-center gap-2">
                    <Plus className="h-4 w-4" />
                    เพลงใหม่
                  </Button>
                </div>

                {/* Tracks grid */}
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                  {isLoadingTracks && (
                    <div className="col-span-full flex justify-center p-12">
                      <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
                    </div>
                  )}
                  
                  {!isLoadingTracks && tracksData && tracksData.length === 0 && (
                    <Card className="col-span-full">
                      <CardHeader>
                        <CardTitle className="text-center">ยังไม่มีเพลง</CardTitle>
                        <CardDescription className="text-center">คุณยังไม่ได้อัพโหลดเพลงใด ๆ</CardDescription>
                      </CardHeader>
                      <CardFooter className="justify-center">
                        <Button onClick={() => navigate("/dashboard/upload")} className="flex items-center gap-2">
                          <Upload className="h-4 w-4" />
                          อัพโหลดเพลงแรกของคุณ
                        </Button>
                      </CardFooter>
                    </Card>
                  )}

                  {!isLoadingTracks && tracksData && tracksData.map((track) => (
                    <Card key={track.id} className="overflow-hidden">
                      <div className="aspect-square bg-gray-100 relative">
                        <div className="absolute inset-0 flex items-center justify-center bg-black/5">
                          <Music className="h-10 w-10 text-gray-400" />
                        </div>
                      </div>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-lg truncate">{track.title}</CardTitle>
                        <CardDescription>
                            สถานะ: <span className={`font-medium ${
                              track.status === 'live' ? 'text-green-500' :
                              track.status === 'pending' ? 'text-yellow-500' :
                              track.status === 'rejected' ? 'text-red-500' : 'text-blue-500'
                            }`}>
                              {track.status === 'live' ? 'ออนไลน์' :
                               track.status === 'pending' ? 'รอการตรวจสอบ' :
                               track.status === 'processing' ? 'กำลังประมวลผล' :
                               track.status === 'distributing' ? 'กำลังเผยแพร่' :
                               track.status === 'rejected' ? 'ถูกปฏิเสธ' : 'ไม่ทราบสถานะ'}
                            </span>
                        </CardDescription>
                      </CardHeader>
                      <CardFooter>
                        <Button
                          variant="outline"
                          size="sm"
                          className="w-full"
                          onClick={() => navigate(`/dashboard/tracks/${track.id}`)}
                        >
                          ดูรายละเอียด
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              {/* Albums Tab */}
              <TabsContent value="albums" className="space-y-4">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-semibold">อัลบั้มทั้งหมด</h2>
                  <Button onClick={() => navigate("/dashboard/albums/new")} className="flex items-center gap-2">
                    <Plus className="h-4 w-4" />
                    อัลบั้มใหม่
                  </Button>
                </div>

                <Card className="p-12 text-center">
                  <Album className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="text-lg font-medium mb-2">ยังไม่มีอัลบั้ม</h3>
                  <p className="text-muted-foreground mb-6">คุณยังไม่ได้สร้างอัลบั้มใด ๆ</p>
                  <Button onClick={() => navigate("/dashboard/albums/new")} className="mx-auto">
                    สร้างอัลบั้มแรกของคุณ
                  </Button>
                </Card>
              </TabsContent>

              {/* Analytics Tab */}
              <TabsContent value="analytics" className="space-y-4">
                <h2 className="text-xl font-semibold">สถิติและการวิเคราะห์</h2>
                
                <div className="grid gap-4 md:grid-cols-2">
                  <Card>
                    <CardHeader>
                      <CardTitle>สถิติการสตรีม</CardTitle>
                      <CardDescription>ข้อมูลการสตรีมในช่วง 30 วันที่ผ่านมา</CardDescription>
                    </CardHeader>
                    <CardContent className="h-80 flex items-center justify-center">
                      <BarChart2 className="h-16 w-16 text-muted-foreground" />
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader>
                      <CardTitle>รายได้</CardTitle>
                      <CardDescription>รายได้จากการสตรีมในช่วง 30 วันที่ผ่านมา</CardDescription>
                    </CardHeader>
                    <CardContent className="h-80 flex items-center justify-center">
                      <BarChart2 className="h-16 w-16 text-muted-foreground" />
                    </CardContent>
                  </Card>
                </div>
                
                <Card>
                  <CardHeader>
                    <CardTitle>แพลตฟอร์มยอดนิยม</CardTitle>
                    <CardDescription>การสตรีมแยกตามแพลตฟอร์ม</CardDescription>
                  </CardHeader>
                  <CardContent className="h-80 flex items-center justify-center">
                    <p className="text-center text-muted-foreground">
                      ยังไม่มีข้อมูลการสตรีมสำหรับแสดงในขณะนี้
                    </p>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>
    </div>
  );
}