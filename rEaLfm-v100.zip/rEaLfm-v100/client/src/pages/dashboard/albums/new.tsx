import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useLocation } from "wouter";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { DashboardHeader } from "@/components/dashboard/DashboardHeader";
import { DashboardNav } from "@/components/dashboard/DashboardNav";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Track } from "@shared/schema";
import { ArrowLeft, Check, Music, Upload } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";

// Album creation schema
const albumSchema = z.object({
  title: z.string().min(1, {
    message: "ชื่ออัลบั้มต้องมีอย่างน้อย 1 ตัวอักษร",
  }),
  description: z.string().optional(),
  releaseDate: z.string().min(1, {
    message: "วันที่เผยแพร่ไม่ควรเป็นค่าว่าง",
  }),
  trackIds: z.array(z.number()).optional(),
});

type AlbumFormValues = z.infer<typeof albumSchema>;

export default function CreateAlbumPage() {
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedTracks, setSelectedTracks] = useState<number[]>([]);
  const [coverFile, setCoverFile] = useState<File | null>(null);

  // Fetch user's tracks for album creation
  const { data: tracks, isLoading: isLoadingTracks } = useQuery({
    queryKey: ['/api/tracks'],
    queryFn: () => apiRequest<Track[]>({ url: '/api/tracks', method: 'GET' })
  });

  // Filter tracks - only include tracks that are not part of an album
  const availableTracks = tracks?.filter(track => !track.albumId);

  // Create form with validation
  const form = useForm<AlbumFormValues>({
    resolver: zodResolver(albumSchema),
    defaultValues: {
      title: "",
      description: "",
      releaseDate: new Date().toISOString().split("T")[0],
      trackIds: [],
    },
  });

  // Handle file selection for album cover
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files[0]) {
      const file = files[0];
      // Check file type
      if (!file.type.includes("image/")) {
        toast({
          title: "รูปแบบไฟล์ไม่ถูกต้อง",
          description: "กรุณาเลือกไฟล์รูปภาพประเภท JPG, PNG, GIF เท่านั้น",
          variant: "destructive",
        });
        return;
      }

      // Check file size
      if (file.size > 5 * 1024 * 1024) { // 5MB
        toast({
          title: "ไฟล์ขนาดใหญ่เกินไป",
          description: "ขนาดไฟล์ต้องไม่เกิน 5MB",
          variant: "destructive",
        });
        return;
      }

      setCoverFile(file);
    }
  };

  // Handle track selection
  const handleTrackToggle = (trackId: number) => {
    setSelectedTracks(prev => {
      if (prev.includes(trackId)) {
        return prev.filter(id => id !== trackId);
      } else {
        return [...prev, trackId];
      }
    });
  };

  // Create album mutation
  const createAlbumMutation = useMutation({
    mutationFn: async (data: FormData) => {
      return await apiRequest({ 
        url: "/api/albums", 
        method: "POST", 
        body: data 
      });
    },
    onSuccess: () => {
      toast({
        title: "สร้างอัลบั้มสำเร็จ",
        description: "อัลบั้มใหม่ของคุณได้รับการสร้างเรียบร้อยแล้ว",
      });
      
      // Invalidate albums query cache
      queryClient.invalidateQueries({ queryKey: ['/api/albums'] });
      
      // Navigate back to albums page
      setTimeout(() => {
        navigate("/dashboard/albums");
      }, 1500);
    },
    onError: (error) => {
      toast({
        title: "เกิดข้อผิดพลาด",
        description: error instanceof Error ? error.message : "ไม่สามารถสร้างอัลบั้มได้ โปรดลองอีกครั้ง",
        variant: "destructive",
      });
    },
  });

  // Handle form submission
  const onSubmit = (data: AlbumFormValues) => {
    const formData = new FormData();
    
    // Add basic album info
    formData.append("title", data.title);
    if (data.description) formData.append("description", data.description);
    formData.append("releaseDate", data.releaseDate);
    
    // Add track IDs
    selectedTracks.forEach(trackId => {
      formData.append("trackIds[]", trackId.toString());
    });
    
    // Add cover image if available
    if (coverFile) {
      formData.append("coverImage", coverFile);
    }
    
    // Submit the form
    createAlbumMutation.mutate(formData);
  };

  return (
    <div className="flex min-h-screen bg-background">
      {/* Sidebar */}
      <DashboardNav />

      {/* Main content */}
      <div className="flex-1 overflow-hidden">
        <DashboardHeader user={user} />

        <main className="flex-1 overflow-y-auto p-6">
          <div className="mx-auto max-w-3xl space-y-6">
            <div className="flex items-center">
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => navigate("/dashboard/albums")}
                className="mr-2"
              >
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold tracking-tight">สร้างอัลบั้มใหม่</h1>
                <p className="text-sm text-muted-foreground">
                  กรอกข้อมูลอัลบั้มและเลือกเพลงที่ต้องการรวมไว้ในอัลบั้ม
                </p>
              </div>
            </div>

            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>ข้อมูลอัลบั้ม</CardTitle>
                    <CardDescription>
                      กรอกข้อมูลพื้นฐานของอัลบั้มที่ต้องการสร้าง
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Album Title */}
                    <FormField
                      control={form.control}
                      name="title"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>ชื่ออัลบั้ม</FormLabel>
                          <FormControl>
                            <Input placeholder="กรอกชื่ออัลบั้ม" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Release Date */}
                    <FormField
                      control={form.control}
                      name="releaseDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>วันที่เผยแพร่</FormLabel>
                          <FormControl>
                            <Input type="date" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Description */}
                    <FormField
                      control={form.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>คำอธิบาย</FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="กรอกคำอธิบายอัลบั้ม (ไม่บังคับ)"
                              className="min-h-32"
                              {...field}
                            />
                          </FormControl>
                          <FormDescription>
                            คำอธิบายจะแสดงบนแพลตฟอร์มที่รองรับ
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Album Cover */}
                    <div className="space-y-2">
                      <FormLabel>ปกอัลบั้ม</FormLabel>
                      <div className="rounded-lg border border-dashed p-6 text-center">
                        {coverFile ? (
                          <div className="space-y-2">
                            <div className="mx-auto h-32 w-32 overflow-hidden rounded-md">
                              <img
                                src={URL.createObjectURL(coverFile)}
                                alt="Album cover preview"
                                className="h-full w-full object-cover"
                              />
                            </div>
                            <div className="text-sm font-medium">{coverFile.name}</div>
                            <div className="text-xs text-muted-foreground">
                              {(coverFile.size / (1024 * 1024)).toFixed(2)} MB
                            </div>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => setCoverFile(null)}
                            >
                              เปลี่ยนรูปภาพ
                            </Button>
                          </div>
                        ) : (
                          <>
                            <div className="mx-auto h-32 w-32 rounded-md bg-muted flex items-center justify-center">
                              <Upload className="h-8 w-8 text-muted-foreground" />
                            </div>
                            <div className="mt-2 text-sm font-medium">
                              ลากไฟล์รูปภาพมาวางที่นี่หรือ
                            </div>
                            <Input
                              id="cover-image"
                              type="file"
                              accept="image/*"
                              className="hidden"
                              onChange={handleFileChange}
                            />
                            <Button
                              variant="outline"
                              size="sm"
                              className="mt-2"
                              onClick={() => document.getElementById("cover-image")?.click()}
                            >
                              เลือกรูปภาพ
                            </Button>
                            <div className="mt-2 text-xs text-muted-foreground">
                              รองรับไฟล์ JPG, PNG, GIF ขนาดไม่เกิน 5MB
                            </div>
                          </>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>เพลงในอัลบั้ม</CardTitle>
                    <CardDescription>
                      เลือกเพลงที่ต้องการรวมไว้ในอัลบั้มนี้
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {isLoadingTracks ? (
                      <div className="flex justify-center py-8">
                        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
                      </div>
                    ) : !availableTracks || availableTracks.length === 0 ? (
                      <div className="text-center py-8 text-muted-foreground">
                        <Music className="h-8 w-8 mx-auto mb-2" />
                        <p>ไม่มีเพลงที่สามารถเพิ่มลงในอัลบั้มได้</p>
                        <p className="text-sm">กรุณาอัพโหลดเพลงก่อนสร้างอัลบั้ม</p>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        {availableTracks.map((track) => (
                          <div
                            key={track.id}
                            className={`flex items-center justify-between rounded-lg border p-3 transition-colors ${
                              selectedTracks.includes(track.id) ? "border-primary bg-primary/5" : ""
                            }`}
                          >
                            <div className="flex items-center gap-3">
                              <Music className="h-5 w-5 text-muted-foreground" />
                              <div>
                                <div className="font-medium">{track.title}</div>
                                <div className="text-sm text-muted-foreground">
                                  {track.genre} • {new Date(track.releaseDate).toLocaleDateString('th-TH')}
                                </div>
                              </div>
                            </div>
                            <Checkbox
                              checked={selectedTracks.includes(track.id)}
                              onCheckedChange={() => handleTrackToggle(track.id)}
                            />
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                  <CardFooter className="flex flex-col space-y-2 sm:flex-row sm:justify-between sm:space-y-0">
                    <div className="text-sm text-muted-foreground">
                      {selectedTracks.length} เพลงที่เลือก
                    </div>
                    <div className="flex space-x-2">
                      <Button 
                        variant="outline"
                        onClick={() => navigate("/dashboard/albums")}
                      >
                        ยกเลิก
                      </Button>
                      <Button 
                        type="submit"
                        disabled={selectedTracks.length === 0 || createAlbumMutation.isPending}
                      >
                        {createAlbumMutation.isPending ? (
                          <span className="flex items-center gap-2">
                            <div className="h-4 w-4 animate-spin rounded-full border-2 border-background border-t-transparent"></div>
                            กำลังสร้างอัลบั้ม...
                          </span>
                        ) : (
                          <span className="flex items-center gap-2">
                            <Check className="h-4 w-4" />
                            สร้างอัลบั้ม
                          </span>
                        )}
                      </Button>
                    </div>
                  </CardFooter>
                </Card>
              </form>
            </Form>
          </div>
        </main>
      </div>
    </div>
  );
}