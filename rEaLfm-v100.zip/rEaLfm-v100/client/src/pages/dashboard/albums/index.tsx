import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Album, Layers, Plus, Search } from "lucide-react";
import { DashboardHeader } from "@/components/dashboard/DashboardHeader";
import { DashboardNav } from "@/components/dashboard/DashboardNav";
import { useAuth } from "@/hooks/use-auth";

export default function AlbumsPage() {
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");

  // Fetch albums data
  const { data: albums, isLoading } = useQuery({
    queryKey: ['/api/albums'],
    queryFn: () => apiRequest({ url: '/api/albums', method: 'GET' })
  });

  // Filter albums based on search query
  const filteredAlbums = albums?.filter(album => 
    album?.title?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex min-h-screen bg-background">
      {/* Sidebar */}
      <DashboardNav />

      {/* Main content */}
      <div className="flex-1 overflow-hidden">
        <DashboardHeader user={user} />

        <main className="flex-1 overflow-y-auto p-6">
          <div className="mx-auto max-w-6xl space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-3xl font-bold tracking-tight">อัลบั้ม</h1>
                <p className="text-muted-foreground">
                  จัดการอัลบั้มและเพลงในอัลบั้มของคุณ
                </p>
              </div>
              
              <Button
                onClick={() => navigate("/dashboard/albums/new")}
                className="flex items-center gap-2 shrink-0"
              >
                <Plus className="h-4 w-4" />
                สร้างอัลบั้มใหม่
              </Button>
            </div>

            {/* Search bar */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="ค้นหาอัลบั้ม..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>

            {/* Albums grid */}
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {isLoading && (
                <div className="col-span-full flex justify-center p-12">
                  <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
                </div>
              )}
              
              {!isLoading && (!filteredAlbums || filteredAlbums.length === 0) && (
                <Card className="col-span-full p-12 text-center">
                  <Album className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="text-lg font-medium mb-2">ยังไม่มีอัลบั้ม</h3>
                  <p className="text-muted-foreground mb-6">คุณยังไม่ได้สร้างอัลบั้มใด ๆ</p>
                  <Button onClick={() => navigate("/dashboard/albums/new")} className="mx-auto">
                    สร้างอัลบั้มแรกของคุณ
                  </Button>
                </Card>
              )}

              {!isLoading && filteredAlbums && filteredAlbums.map((album) => (
                <Card key={album.id} className="overflow-hidden">
                  <div className="aspect-square bg-gray-100 relative">
                    <div className="absolute inset-0 flex items-center justify-center bg-black/5">
                      <Layers className="h-10 w-10 text-gray-400" />
                    </div>
                  </div>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg truncate">{album.title}</CardTitle>
                    <CardDescription>
                      {album.tracks?.length || 0} เพลง • {new Date(album.releaseDate).toLocaleDateString('th-TH')}
                    </CardDescription>
                  </CardHeader>
                  <CardFooter>
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full"
                      onClick={() => navigate(`/dashboard/albums/${album.id}`)}
                    >
                      ดูรายละเอียด
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}