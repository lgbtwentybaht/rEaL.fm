import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { DashboardHeader } from "@/components/dashboard/DashboardHeader";
import { DashboardNav } from "@/components/dashboard/DashboardNav";
import { useAuth } from "@/hooks/use-auth";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  BarChart2, 
  DollarSign, 
  Music, 
  PieChart, 
  TrendingUp
} from "lucide-react";

// Sample interface for analytics data
interface AnalyticsData {
  totalStreams: number;
  totalRevenue: number;
  streamsByPlatform: {
    platform: string;
    streams: number;
    percentage: number;
  }[];
  revenueByPlatform: {
    platform: string;
    revenue: number;
    percentage: number;
  }[];
  chartData: {
    date: string;
    streams: number;
    revenue: number;
  }[];
}

export default function AnalyticsPage() {
  const { user } = useAuth();
  const [period, setPeriod] = useState<string>("month");

  // Fetch artist analytics
  const { data: analyticsData, isLoading } = useQuery({
    queryKey: ['/api/artist/analytics', period],
    queryFn: () => apiRequest<AnalyticsData>({ 
      url: `/api/artist/analytics?period=${period}`, 
      method: 'GET' 
    })
  });

  // Fetch artist revenue
  const { data: revenueData, isLoading: isLoadingRevenue } = useQuery({
    queryKey: ['/api/artist/revenue', period],
    queryFn: () => apiRequest<any>({ 
      url: `/api/artist/revenue?period=${period}`, 
      method: 'GET' 
    })
  });

  // Default placeholder data when no data is available
  const placeholderData = {
    totalStreams: 0,
    totalRevenue: 0,
    streamsByPlatform: [],
    revenueByPlatform: [],
    chartData: []
  };

  return (
    <div className="flex min-h-screen bg-background">
      {/* Sidebar */}
      <DashboardNav />

      {/* Main content */}
      <div className="flex-1 overflow-hidden">
        <DashboardHeader user={user} />

        <main className="flex-1 overflow-y-auto p-6">
          <div className="mx-auto max-w-6xl space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold tracking-tight">สถิติและรายได้</h1>
                <p className="text-muted-foreground">
                  ดูสถิติการสตรีมและรายได้จากเพลงของคุณ
                </p>
              </div>
              
              <Select
                value={period}
                onValueChange={(value) => setPeriod(value)}
              >
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="เลือกช่วงเวลา" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="week">7 วันที่ผ่านมา</SelectItem>
                  <SelectItem value="month">30 วันที่ผ่านมา</SelectItem>
                  <SelectItem value="year">ปีนี้</SelectItem>
                  <SelectItem value="all">ทั้งหมด</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* KPIs */}
            <div className="grid gap-4 md:grid-cols-3">
              <Card>
                <CardHeader className="pb-2">
                  <CardDescription>ยอดสตรีมรวม</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center">
                    <Music className="h-5 w-5 text-muted-foreground mr-2" />
                    <div className="text-2xl font-bold">
                      {isLoading ? (
                        <div className="h-6 w-20 animate-pulse rounded bg-muted"></div>
                      ) : (
                        analyticsData?.totalStreams.toLocaleString() || placeholderData.totalStreams.toLocaleString()
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardDescription>รายได้รวม</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center">
                    <DollarSign className="h-5 w-5 text-muted-foreground mr-2" />
                    <div className="text-2xl font-bold">
                      {isLoadingRevenue ? (
                        <div className="h-6 w-20 animate-pulse rounded bg-muted"></div>
                      ) : (
                        (revenueData?.totalRevenue || placeholderData.totalRevenue).toLocaleString('th-TH', {
                          style: 'currency',
                          currency: 'THB',
                          minimumFractionDigits: 2
                        })
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardDescription>แนวโน้ม</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center">
                    <TrendingUp className="h-5 w-5 text-green-500 mr-2" />
                    <div className="text-2xl font-bold">
                      {isLoading ? (
                        <div className="h-6 w-20 animate-pulse rounded bg-muted"></div>
                      ) : (
                        "0%"
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Tabs defaultValue="streams">
              <TabsList>
                <TabsTrigger value="streams">การสตรีม</TabsTrigger>
                <TabsTrigger value="revenue">รายได้</TabsTrigger>
                <TabsTrigger value="platforms">แพลตฟอร์ม</TabsTrigger>
              </TabsList>
              
              {/* Streams */}
              <TabsContent value="streams">
                <Card>
                  <CardHeader>
                    <CardTitle>การสตรีมตามเวลา</CardTitle>
                    <CardDescription>
                      สถิติการสตรีมเพลงในช่วง {period === 'week' ? '7 วัน' : 
                        period === 'month' ? '30 วัน' : 
                        period === 'year' ? 'ปีนี้' : 'ทั้งหมด'} ที่ผ่านมา
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="h-80 p-6">
                    {isLoading ? (
                      <div className="h-full w-full flex items-center justify-center">
                        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
                      </div>
                    ) : analyticsData?.chartData && analyticsData.chartData.length > 0 ? (
                      <div className="h-full w-full flex items-center justify-center">
                        <BarChart2 className="h-24 w-24 text-muted-foreground opacity-50" />
                      </div>
                    ) : (
                      <div className="h-full w-full flex items-center justify-center">
                        <p className="text-center text-muted-foreground">
                          ไม่มีข้อมูลการสตรีมสำหรับช่วงเวลานี้
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
              
              {/* Revenue */}
              <TabsContent value="revenue">
                <Card>
                  <CardHeader>
                    <CardTitle>รายได้ตามเวลา</CardTitle>
                    <CardDescription>
                      รายได้จากการสตรีมเพลงในช่วง {period === 'week' ? '7 วัน' : 
                        period === 'month' ? '30 วัน' : 
                        period === 'year' ? 'ปีนี้' : 'ทั้งหมด'} ที่ผ่านมา
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="h-80 p-6">
                    {isLoadingRevenue ? (
                      <div className="h-full w-full flex items-center justify-center">
                        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
                      </div>
                    ) : revenueData?.chartData && revenueData.chartData.length > 0 ? (
                      <div className="h-full w-full flex items-center justify-center">
                        <BarChart2 className="h-24 w-24 text-muted-foreground opacity-50" />
                      </div>
                    ) : (
                      <div className="h-full w-full flex items-center justify-center">
                        <p className="text-center text-muted-foreground">
                          ไม่มีข้อมูลรายได้สำหรับช่วงเวลานี้
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
              
              {/* Platforms */}
              <TabsContent value="platforms">
                <div className="grid gap-4 md:grid-cols-2">
                  <Card>
                    <CardHeader>
                      <CardTitle>การสตรีมตามแพลตฟอร์ม</CardTitle>
                      <CardDescription>
                        สัดส่วนการสตรีมแยกตามแพลตฟอร์ม
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="h-80 p-6">
                      {isLoading ? (
                        <div className="h-full w-full flex items-center justify-center">
                          <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
                        </div>
                      ) : analyticsData?.streamsByPlatform && analyticsData.streamsByPlatform.length > 0 ? (
                        <div className="h-full w-full flex items-center justify-center">
                          <PieChart className="h-24 w-24 text-muted-foreground opacity-50" />
                        </div>
                      ) : (
                        <div className="h-full w-full flex items-center justify-center">
                          <p className="text-center text-muted-foreground">
                            ไม่มีข้อมูลการสตรีมตามแพลตฟอร์ม
                          </p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader>
                      <CardTitle>รายได้ตามแพลตฟอร์ม</CardTitle>
                      <CardDescription>
                        สัดส่วนรายได้แยกตามแพลตฟอร์ม
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="h-80 p-6">
                      {isLoadingRevenue ? (
                        <div className="h-full w-full flex items-center justify-center">
                          <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
                        </div>
                      ) : revenueData?.revenueByPlatform && revenueData.revenueByPlatform.length > 0 ? (
                        <div className="h-full w-full flex items-center justify-center">
                          <PieChart className="h-24 w-24 text-muted-foreground opacity-50" />
                        </div>
                      ) : (
                        <div className="h-full w-full flex items-center justify-center">
                          <p className="text-center text-muted-foreground">
                            ไม่มีข้อมูลรายได้ตามแพลตฟอร์ม
                          </p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>
    </div>
  );
}