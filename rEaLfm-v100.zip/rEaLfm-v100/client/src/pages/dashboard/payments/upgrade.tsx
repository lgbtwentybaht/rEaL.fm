import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { DashboardNav } from "@/components/dashboard/DashboardNav";
import { DashboardHeader } from "@/components/dashboard/DashboardHeader";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Check,
  Music,
  RadioTower,
  Clock,
  HeartHandshake,
  Trophy,
  Headphones,
  Download,
  ChevronRight,
  ArrowRight,
  MapPin,
  Users,
  BarChart4,
  BadgeCheck,
  Loader2,
  Shield,
} from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";

export default function UpgradePage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [selectedPlan, setSelectedPlan] = useState<"basic" | "pro" | null>(null);
  const [discountCode, setDiscountCode] = useState("");
  const currentPackage = user?.packageType || "free";

  // Upgrade mutation
  const upgradeMutation = useMutation({
    mutationFn: async (newPackage: string) => {
      return await apiRequest("POST", "/api/payments/upgrade", { 
        packageType: newPackage,
        discountCode: discountCode || undefined
      });
    },
    onSuccess: () => {
      toast({
        title: "อัพเกรดแพ็คเกจสำเร็จ",
        description: "แพ็คเกจของคุณถูกอัพเกรดเรียบร้อยแล้ว",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
      navigate("/dashboard");
    },
    onError: (error: Error) => {
      toast({
        title: "ไม่สามารถอัพเกรดแพ็คเกจได้",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Confirm upgrade
  const confirmUpgrade = () => {
    if (!selectedPlan) return;
    
    if (currentPackage === selectedPlan) {
      toast({
        title: "คุณกำลังใช้แพ็คเกจนี้อยู่แล้ว",
        description: "กรุณาเลือกแพ็คเกจอื่น",
        variant: "destructive",
      });
      return;
    }
    
    upgradeMutation.mutate(selectedPlan);
  };

  const isCurrentPlan = (plan: string) => currentPackage === plan;

  // Basic plan features
  const basicFeatures = [
    { icon: Music, text: "อัพโหลดได้สูงสุด 30 เพลง" },
    { icon: RadioTower, text: "กระจายเพลงไปยัง 5 แพลตฟอร์ม" },
    { icon: Clock, text: "การประมวลผลเพลงภายใน 48 ชั่วโมง" },
    { icon: HeartHandshake, text: "รายได้ 70% จากยอดสตรีม" },
    { icon: Trophy, text: "การวิเคราะห์ข้อมูลพื้นฐาน" },
    { icon: Download, text: "บาร์โค้ด ISRC และ UPC ฟรี" },
  ];

  // Pro plan features
  const proFeatures = [
    { icon: Music, text: "อัพโหลดได้ไม่จำกัดจำนวนเพลง" },
    { icon: RadioTower, text: "กระจายเพลงไปยัง 15+ แพลตฟอร์ม" },
    { icon: Clock, text: "การประมวลผลเพลงด่วน (24 ชั่วโมง)" },
    { icon: HeartHandshake, text: "รายได้ 85% จากยอดสตรีม" },
    { icon: Trophy, text: "การวิเคราะห์ข้อมูลขั้นสูง" },
    { icon: Download, text: "บาร์โค้ด ISRC และ UPC ฟรี" },
    { icon: MapPin, text: "การโปรโมทเพลงในพื้นที่เฉพาะ" },
    { icon: Users, text: "จัดการทีมงานและนักดนตรีร่วม" },
    { icon: BarChart4, text: "รายงานข้อมูลเชิงลึกประจำเดือน" },
    { icon: BadgeCheck, text: "สิทธิ์พิเศษสำหรับศิลปิน Pro" },
  ];

  // Calculate usage percentage
  const getUsagePercentage = () => {
    if (!user) return 0;
    
    const tracksUploaded = 5; // This should come from API
    
    switch (currentPackage) {
      case "free":
        return Math.min(100, (tracksUploaded / 5) * 100);
      case "basic":
        return Math.min(100, (tracksUploaded / 30) * 100);
      case "pro":
        return 0; // Unlimited
      default:
        return 0;
    }
  };

  return (
    <div className="flex min-h-screen bg-background">
      <DashboardNav />
      
      <div className="flex-1">
        <DashboardHeader user={user || undefined} />
        
        <main className="flex-1 p-6">
          <div className="mx-auto max-w-6xl space-y-8">
            <div className="text-center space-y-3">
              <h1 className="text-3xl font-bold">อัพเกรดแพ็คเกจของคุณ</h1>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                เพิ่มประสิทธิภาพในการกระจายเพลงและการจัดการผลงานของคุณด้วยแพ็คเกจที่เหมาะกับความต้องการของคุณ
              </p>
            </div>
            
            <div className="bg-gradient-to-r from-indigo-50 to-blue-50 border rounded-xl p-6 flex items-center justify-between">
              <div className="space-y-2">
                <div className="flex items-center">
                  <Shield className="mr-2 h-5 w-5 text-indigo-600" />
                  <h3 className="font-semibold text-lg">แพ็คเกจปัจจุบัน: {currentPackage === 'free' ? 'ฟรี' : currentPackage === 'basic' ? 'พื้นฐาน' : 'โปร'}</h3>
                </div>
                <p className="text-sm text-muted-foreground">
                  การใช้งานปัจจุบันของคุณ
                </p>
                
                <div className="w-80 space-y-1">
                  <div className="flex justify-between text-xs">
                    <span>จำนวนเพลงที่อัพโหลด</span>
                    <span>
                      5 / {currentPackage === 'free' ? '5' : 
                            currentPackage === 'basic' ? '30' : 
                            'ไม่จำกัด'}
                    </span>
                  </div>
                  <Progress value={getUsagePercentage()} className="h-2" />
                </div>
              </div>
              
              {currentPackage !== 'pro' && (
                <Button onClick={() => navigate("/dashboard/payments/history")}>
                  ดูประวัติการชำระเงิน
                  <ChevronRight className="ml-1 h-4 w-4" />
                </Button>
              )}
            </div>
            
            <Tabs defaultValue={currentPackage === 'pro' ? 'pro' : 'basic'} className="w-full">
              <TabsList className="mx-auto mb-8 grid w-64 grid-cols-2">
                <TabsTrigger value="basic">พื้นฐาน</TabsTrigger>
                <TabsTrigger value="pro">โปร</TabsTrigger>
              </TabsList>
              
              <TabsContent value="basic">
                <div className="grid md:grid-cols-2 gap-6">
                  <Card className={`border-2 ${isCurrentPlan('basic') ? 'border-primary' : ''}`}>
                    <CardHeader>
                      <CardTitle className="flex justify-between items-center">
                        <span>แพ็คเกจพื้นฐาน</span>
                        <span className="text-2xl font-bold">
                          299฿<span className="text-sm font-normal text-muted-foreground">/เดือน</span>
                        </span>
                      </CardTitle>
                      <CardDescription>
                        เหมาะสำหรับศิลปินหน้าใหม่หรือผู้ที่เริ่มต้น
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <ul className="space-y-3">
                        {basicFeatures.map((feature, i) => {
                          const Icon = feature.icon;
                          return (
                            <li key={i} className="flex items-start">
                              <div className="mr-2 mt-0.5 h-5 w-5 rounded-full bg-primary/10 flex items-center justify-center">
                                <Check className="h-3 w-3 text-primary" />
                              </div>
                              <div className="flex items-center">
                                <Icon className="mr-2 h-4 w-4 text-primary" />
                                <span>{feature.text}</span>
                              </div>
                            </li>
                          );
                        })}
                      </ul>
                    </CardContent>
                    <CardFooter>
                      {isCurrentPlan('basic') ? (
                        <Button className="w-full" disabled>
                          แพ็คเกจปัจจุบันของคุณ
                        </Button>
                      ) : (
                        <Button 
                          className="w-full" 
                          onClick={() => setSelectedPlan('basic')}
                          variant={selectedPlan === 'basic' ? 'default' : 'outline'}
                        >
                          {selectedPlan === 'basic' ? 'เลือกแล้ว ✓' : 'เลือกแพ็คเกจนี้'}
                        </Button>
                      )}
                    </CardFooter>
                  </Card>
                  
                  <Card className="rounded-xl border-dashed border-2 bg-muted/50">
                    <CardHeader>
                      <CardTitle>ฟีเจอร์เด่นแพ็คเกจพื้นฐาน</CardTitle>
                      <CardDescription>
                        สิ่งที่คุณจะได้รับจากการอัพเกรดเป็นแพ็คเกจพื้นฐาน
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div className="space-y-2">
                        <h4 className="font-medium flex items-center">
                          <Headphones className="mr-2 h-4 w-4 text-primary" />
                          กระจายเพลงได้มากขึ้น
                        </h4>
                        <p className="text-sm text-muted-foreground">
                          สามารถกระจายเพลงไปยัง 5 แพลตฟอร์มชั้นนำ เพิ่มโอกาสการเข้าถึงผู้ฟังทั่วโลก
                        </p>
                      </div>
                      
                      <div className="space-y-2">
                        <h4 className="font-medium flex items-center">
                          <ArrowRight className="mr-2 h-4 w-4 text-primary" />
                          ส่วนแบ่งรายได้ที่สูงขึ้น
                        </h4>
                        <p className="text-sm text-muted-foreground">
                          รับส่วนแบ่งรายได้จากการสตรีมสูงถึง 70% โดยไม่มีค่าธรรมเนียมซ่อนเร้น
                        </p>
                      </div>
                      
                      <div className="space-y-2">
                        <h4 className="font-medium flex items-center">
                          <BarChart4 className="mr-2 h-4 w-4 text-primary" />
                          การวิเคราะห์ข้อมูลเชิงลึก
                        </h4>
                        <p className="text-sm text-muted-foreground">
                          เข้าถึงข้อมูลสถิติการฟังเพลงของคุณ พร้อมรายงานสรุปประจำเดือน
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
              
              <TabsContent value="pro">
                <div className="grid md:grid-cols-2 gap-6">
                  <Card className={`border-2 ${isCurrentPlan('pro') ? 'border-primary' : ''}`}>
                    <CardHeader>
                      <div className="flex items-center mb-2">
                        <span className="bg-gradient-to-r from-purple-600 to-blue-500 text-white text-xs px-2 py-0.5 rounded-full">
                          แนะนำ
                        </span>
                      </div>
                      <CardTitle className="flex justify-between items-center">
                        <span>แพ็คเกจโปร</span>
                        <span className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-blue-500">
                          599฿<span className="text-sm font-normal text-muted-foreground">/เดือน</span>
                        </span>
                      </CardTitle>
                      <CardDescription>
                        เหมาะสำหรับศิลปินมืออาชีพและผลงานที่ต้องการเติบโต
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <ul className="space-y-3">
                        {proFeatures.map((feature, i) => {
                          const Icon = feature.icon;
                          return (
                            <li key={i} className="flex items-start">
                              <div className="mr-2 mt-0.5 h-5 w-5 rounded-full bg-primary/10 flex items-center justify-center">
                                <Check className="h-3 w-3 text-primary" />
                              </div>
                              <div className="flex items-center">
                                <Icon className="mr-2 h-4 w-4 text-primary" />
                                <span>{feature.text}</span>
                              </div>
                            </li>
                          );
                        })}
                      </ul>
                    </CardContent>
                    <CardFooter>
                      {isCurrentPlan('pro') ? (
                        <Button className="w-full" disabled>
                          แพ็คเกจปัจจุบันของคุณ
                        </Button>
                      ) : (
                        <Button 
                          className="w-full" 
                          onClick={() => setSelectedPlan('pro')}
                          variant={selectedPlan === 'pro' ? 'default' : 'outline'}
                        >
                          {selectedPlan === 'pro' ? 'เลือกแล้ว ✓' : 'เลือกแพ็คเกจนี้'}
                        </Button>
                      )}
                    </CardFooter>
                  </Card>
                  
                  <Card className="rounded-xl border-dashed border-2 bg-muted/50">
                    <CardHeader>
                      <CardTitle>ฟีเจอร์เด่นแพ็คเกจโปร</CardTitle>
                      <CardDescription>
                        สิ่งที่คุณจะได้รับจากการอัพเกรดเป็นแพ็คเกจโปร
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div className="space-y-2">
                        <h4 className="font-medium flex items-center">
                          <Music className="mr-2 h-4 w-4 text-primary" />
                          ไม่จำกัดจำนวนการอัพโหลด
                        </h4>
                        <p className="text-sm text-muted-foreground">
                          อัพโหลดเพลงได้ไม่จำกัดจำนวน ไม่มีข้อจำกัดในการเผยแพร่ผลงานของคุณ
                        </p>
                      </div>
                      
                      <div className="space-y-2">
                        <h4 className="font-medium flex items-center">
                          <RadioTower className="mr-2 h-4 w-4 text-primary" />
                          การเข้าถึงระดับโลก
                        </h4>
                        <p className="text-sm text-muted-foreground">
                          กระจายเพลงไปยัง 15+ แพลตฟอร์มชั้นนำทั่วโลก เพิ่มโอกาสในการเติบโตและเข้าถึงผู้ฟังทั่วโลก
                        </p>
                      </div>
                      
                      <div className="space-y-2">
                        <h4 className="font-medium flex items-center">
                          <HeartHandshake className="mr-2 h-4 w-4 text-primary" />
                          ส่วนแบ่งรายได้สูงสุด
                        </h4>
                        <p className="text-sm text-muted-foreground">
                          รับส่วนแบ่งรายได้จากการสตรีมสูงถึง 85% คุ้มค่าที่สุดสำหรับศิลปินที่ต้องการเติบโต
                        </p>
                      </div>
                      
                      <div className="space-y-2">
                        <h4 className="font-medium flex items-center">
                          <Users className="mr-2 h-4 w-4 text-primary" />
                          การจัดการทีมแบบมืออาชีพ
                        </h4>
                        <p className="text-sm text-muted-foreground">
                          เชิญและจัดการทีมงานและผู้ร่วมสร้างสรรค์ผลงาน พร้อมกำหนดบทบาทและสิทธิ์ต่างๆ
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
            </Tabs>
            
            <div className="mt-8 text-center">
              {selectedPlan && !isCurrentPlan(selectedPlan) && (
                <div className="space-y-4 max-w-md mx-auto">
                  <Button 
                    size="lg" 
                    className="w-full"
                    onClick={confirmUpgrade}
                    disabled={upgradeMutation.isPending}
                  >
                    {upgradeMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        กำลังดำเนินการ...
                      </>
                    ) : (
                      <>
                        ยืนยันการอัพเกรดเป็นแพ็คเกจ {selectedPlan === 'basic' ? 'พื้นฐาน' : 'โปร'}
                      </>
                    )}
                  </Button>
                  <p className="text-sm text-muted-foreground">
                    คุณจะถูกเรียกเก็บเงินสำหรับแพ็คเกจที่อัพเกรดทันที
                  </p>
                </div>
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}