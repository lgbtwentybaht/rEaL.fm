import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { CreditCard, Download, Plus, ArrowUpRight } from "lucide-react";
import { DashboardHeader } from "@/components/dashboard/DashboardHeader";
import { DashboardNav } from "@/components/dashboard/DashboardNav";
import { useAuth } from "@/hooks/use-auth";

// Sample payment history interface
interface PaymentHistory {
  id: number;
  date: string;
  amount: number;
  description: string;
  status: "success" | "pending" | "failed";
}

// Sample payment methods interface
interface PaymentMethod {
  id: number;
  type: "card" | "bank";
  last4: string;
  expiry?: string;
  isDefault: boolean;
}

export default function PaymentsPage() {
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<string>("overview");

  // Fetch payment history (placeholder query)
  const { data: paymentHistory, isLoading: isLoadingHistory } = useQuery({
    queryKey: ['/api/payments/history'],
    queryFn: () => {
      // For now, return empty array as this endpoint doesn't exist yet
      return [];
    },
    // Disable automatic refetching to avoid errors
    enabled: false
  });

  // Fetch payment methods (placeholder query)
  const { data: paymentMethods, isLoading: isLoadingMethods } = useQuery({
    queryKey: ['/api/payments/methods'],
    queryFn: () => {
      // For now, return empty array as this endpoint doesn't exist yet
      return [];
    },
    // Disable automatic refetching to avoid errors
    enabled: false
  });

  // Get package details
  const getPackageDetails = () => {
    const packageType = user?.packageType || 'free';
    
    switch (packageType) {
      case 'pro':
        return {
          name: 'Pro',
          price: '฿1,999',
          period: 'ต่อปี',
          features: [
            'เผยแพร่เพลงไม่จำกัดจำนวน',
            'เผยแพร่ไปยังทุกแพลตฟอร์ม',
            'คุณภาพเสียง 320kbps',
            'แดชบอร์ดวิเคราะห์ขั้นสูง',
            'ตั้งค่า ISRC เอง',
            'รับเงินรายได้ 100%',
          ]
        };
      case 'basic':
        return {
          name: 'Basic',
          price: '฿799',
          period: 'ต่อปี',
          features: [
            'เผยแพร่เพลงสูงสุด 50 เพลงต่อปี',
            'เผยแพร่ไปยังแพลตฟอร์มหลัก',
            'คุณภาพเสียง 192kbps',
            'แดชบอร์ดวิเคราะห์พื้นฐาน',
            'ตั้งค่า ISRC เอง',
            'รับเงินรายได้ 90%',
          ]
        };
      case 'free':
      default:
        return {
          name: 'Free',
          price: '฿0',
          period: '',
          features: [
            'เผยแพร่เพลงสูงสุด 2 เพลงต่อปี',
            'เผยแพร่ไปยังแพลตฟอร์มจำกัด',
            'คุณภาพเสียงพื้นฐาน 128kbps',
            'แดชบอร์ดวิเคราะห์พื้นฐาน',
            'รับเงินรายได้ 80%',
          ]
        };
    }
  };

  const packageDetails = getPackageDetails();

  return (
    <div className="flex min-h-screen bg-background">
      {/* Sidebar */}
      <DashboardNav />

      {/* Main content */}
      <div className="flex-1 overflow-hidden">
        <DashboardHeader user={user} />

        <main className="flex-1 overflow-y-auto p-6">
          <div className="mx-auto max-w-6xl space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-3xl font-bold tracking-tight">การชำระเงิน</h1>
                <p className="text-muted-foreground">
                  จัดการแผนการใช้งานและข้อมูลการชำระเงินของคุณ
                </p>
              </div>
              
              <Button
                onClick={() => navigate("/pricing")}
                className="flex items-center gap-2 shrink-0"
              >
                <ArrowUpRight className="h-4 w-4" />
                อัพเกรดแผนการใช้งาน
              </Button>
            </div>

            <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="overview">ภาพรวม</TabsTrigger>
                <TabsTrigger value="history">ประวัติการชำระเงิน</TabsTrigger>
                <TabsTrigger value="methods">วิธีการชำระเงิน</TabsTrigger>
              </TabsList>
              
              {/* Overview Tab */}
              <TabsContent value="overview">
                <div className="grid gap-4 md:grid-cols-2">
                  <Card>
                    <CardHeader>
                      <CardTitle>แผนปัจจุบัน</CardTitle>
                      <CardDescription>
                        แผนการใช้งานและสิทธิประโยชน์ของคุณ
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="mt-2 mb-4">
                        <div className="flex items-baseline">
                          <span className="text-3xl font-bold">{packageDetails.price}</span>
                          <span className="ml-1 text-muted-foreground">{packageDetails.period}</span>
                        </div>
                        <Badge variant="outline" className="mt-2">
                          แผน {packageDetails.name}
                        </Badge>
                      </div>
                      
                      <div className="space-y-2">
                        {packageDetails.features.map((feature, index) => (
                          <div key={index} className="flex items-center">
                            <div className="mr-2 h-4 w-4 text-primary">
                              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" />
                              </svg>
                            </div>
                            <p className="text-sm">{feature}</p>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                    <CardFooter>
                      <Button
                        variant="outline"
                        onClick={() => navigate("/pricing")}
                        className="w-full"
                      >
                        เปรียบเทียบแผนการใช้งาน
                      </Button>
                    </CardFooter>
                  </Card>
                  
                  <Card>
                    <CardHeader>
                      <CardTitle>ใบแจ้งหนี้ถัดไป</CardTitle>
                      <CardDescription>
                        รายละเอียดการชำระเงินของคุณ
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {user?.packageType === 'free' ? (
                        <div className="py-8 text-center">
                          <p className="text-muted-foreground">คุณกำลังใช้แผน Free ไม่มีค่าใช้จ่าย</p>
                        </div>
                      ) : (
                        <>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">วันชำระเงินครั้งถัดไป</span>
                            <span>1 มกราคม 2025</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">จำนวนเงิน</span>
                            <span>{packageDetails.price}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">แผนการใช้งาน</span>
                            <span>แผน {packageDetails.name} รายปี</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">สถานะ</span>
                            <Badge variant="outline" className="bg-green-50 text-green-700 hover:bg-green-50">
                              ชำระแล้ว
                            </Badge>
                          </div>
                        </>
                      )}
                    </CardContent>
                    <CardFooter>
                      <Button
                        variant="outline"
                        onClick={() => setActiveTab("history")}
                        className="w-full"
                      >
                        ดูประวัติการชำระเงิน
                      </Button>
                    </CardFooter>
                  </Card>
                </div>
              </TabsContent>
              
              {/* History Tab */}
              <TabsContent value="history">
                <Card>
                  <CardHeader>
                    <CardTitle>ประวัติการชำระเงิน</CardTitle>
                    <CardDescription>
                      ประวัติการชำระเงินและใบเสร็จทั้งหมดของคุณ
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {isLoadingHistory ? (
                      <div className="flex justify-center py-8">
                        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
                      </div>
                    ) : !paymentHistory || paymentHistory.length === 0 ? (
                      <div className="py-8 text-center">
                        <CreditCard className="mx-auto h-12 w-12 text-muted-foreground" />
                        <p className="mt-4 text-lg font-medium">ยังไม่มีประวัติการชำระเงิน</p>
                        <p className="mt-1 text-sm text-muted-foreground">
                          คุณยังไม่มีประวัติการชำระเงินหรือใบเสร็จใด ๆ
                        </p>
                      </div>
                    ) : (
                      <Table>
                        <TableCaption>ประวัติการชำระเงินทั้งหมด</TableCaption>
                        <TableHeader>
                          <TableRow>
                            <TableHead>วันที่</TableHead>
                            <TableHead>คำอธิบาย</TableHead>
                            <TableHead>สถานะ</TableHead>
                            <TableHead className="text-right">จำนวนเงิน</TableHead>
                            <TableHead></TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {paymentHistory.map((payment: PaymentHistory) => (
                            <TableRow key={payment.id}>
                              <TableCell>{new Date(payment.date).toLocaleDateString('th-TH')}</TableCell>
                              <TableCell>{payment.description}</TableCell>
                              <TableCell>
                                <Badge variant={
                                  payment.status === 'success' ? 'default' : 
                                  payment.status === 'pending' ? 'outline' : 'destructive'
                                }>
                                  {payment.status === 'success' ? 'สำเร็จ' : 
                                   payment.status === 'pending' ? 'รอดำเนินการ' : 'ล้มเหลว'}
                                </Badge>
                              </TableCell>
                              <TableCell className="text-right">
                                ฿{payment.amount.toFixed(2)}
                              </TableCell>
                              <TableCell>
                                <Button variant="ghost" size="sm">
                                  <Download className="h-4 w-4" />
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
              
              {/* Payment Methods Tab */}
              <TabsContent value="methods">
                <Card>
                  <CardHeader>
                    <div className="flex justify-between items-center">
                      <div>
                        <CardTitle>วิธีการชำระเงิน</CardTitle>
                        <CardDescription>
                          จัดการบัตรเครดิตและวิธีการชำระเงินของคุณ
                        </CardDescription>
                      </div>
                      <Button size="sm" className="flex items-center gap-2">
                        <Plus className="h-4 w-4" />
                        เพิ่มวิธีการชำระเงิน
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    {isLoadingMethods ? (
                      <div className="flex justify-center py-8">
                        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
                      </div>
                    ) : !paymentMethods || paymentMethods.length === 0 ? (
                      <div className="py-8 text-center">
                        <CreditCard className="mx-auto h-12 w-12 text-muted-foreground" />
                        <p className="mt-4 text-lg font-medium">ยังไม่มีวิธีการชำระเงิน</p>
                        <p className="mt-1 text-sm text-muted-foreground">
                          เพิ่มวิธีการชำระเงินเพื่อให้การต่ออายุสมาชิกเป็นไปโดยอัตโนมัติ
                        </p>
                        <Button className="mt-4">
                          <Plus className="mr-2 h-4 w-4" /> เพิ่มวิธีการชำระเงิน
                        </Button>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {paymentMethods.map((method: PaymentMethod) => (
                          <div
                            key={method.id}
                            className="flex items-center justify-between rounded-lg border p-4"
                          >
                            <div className="flex items-center gap-4">
                              <div className="rounded-md bg-muted p-2">
                                <CreditCard className="h-5 w-5" />
                              </div>
                              <div>
                                <p className="font-medium">
                                  {method.type === 'card' ? 'บัตรเครดิต' : 'บัญชีธนาคาร'} ****{method.last4}
                                </p>
                                {method.expiry && (
                                  <p className="text-sm text-muted-foreground">
                                    หมดอายุ: {method.expiry}
                                  </p>
                                )}
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              {method.isDefault && (
                                <Badge variant="outline" className="mr-2">
                                  ค่าเริ่มต้น
                                </Badge>
                              )}
                              <Button variant="ghost" size="sm">
                                แก้ไข
                              </Button>
                              <Button variant="ghost" size="sm" className="text-destructive">
                                ลบ
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>
    </div>
  );
}