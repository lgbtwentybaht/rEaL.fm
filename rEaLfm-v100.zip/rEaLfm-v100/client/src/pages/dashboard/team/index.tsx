import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Users, UserPlus, Mail, Phone, Edit, Trash2, Shield } from "lucide-react";
import { DashboardHeader } from "@/components/dashboard/DashboardHeader";
import { DashboardNav } from "@/components/dashboard/DashboardNav";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";

// Team member schema
const teamMemberSchema = z.object({
  email: z.string().email({
    message: "อีเมลไม่ถูกต้อง",
  }),
  role: z.string({
    required_error: "กรุณาเลือกบทบาท",
  }),
  permissions: z.array(z.string()).optional(),
});

type TeamMemberFormValues = z.infer<typeof teamMemberSchema>;

// Team member interface
interface TeamMember {
  id: number;
  name: string;
  email: string;
  role: string;
  status: "active" | "invited" | "declined";
  avatar?: string;
  permissions: string[];
}

export default function TeamPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [openAddDialog, setOpenAddDialog] = useState(false);
  const [selectedMember, setSelectedMember] = useState<TeamMember | null>(null);
  
  // Default available team roles
  const teamRoles = [
    { value: "admin", label: "ผู้ดูแลระบบ" },
    { value: "manager", label: "ผู้จัดการ" },
    { value: "editor", label: "ผู้แก้ไข" },
    { value: "viewer", label: "ผู้ชม" },
  ];
  
  // Permission options
  const permissionOptions = [
    { value: "upload", label: "อัพโหลดเพลง" },
    { value: "edit", label: "แก้ไขเพลง" },
    { value: "distribute", label: "เผยแพร่เพลง" },
    { value: "finance", label: "ดูข้อมูลการเงิน" },
    { value: "invite", label: "เชิญสมาชิก" },
  ];
  
  // Fetch team members (placeholder query)
  const { data: teamMembers, isLoading } = useQuery({
    queryKey: ['/api/team/members'],
    queryFn: () => {
      // For now, return empty array as this endpoint doesn't exist yet
      return [];
    },
    // Disable automatic refetching to avoid errors
    enabled: false
  });
  
  // Add team member mutation (placeholder)
  const addMemberMutation = useMutation({
    mutationFn: async (data: TeamMemberFormValues) => {
      // For now just return mock data since the API doesn't exist
      toast({
        title: "ส่งคำเชิญสำเร็จ",
        description: `คำเชิญได้ถูกส่งไปยัง ${data.email}`,
      });
      
      return data;
    },
    onSuccess: () => {
      // Close dialog and reset form
      setOpenAddDialog(false);
      form.reset();
    },
  });
  
  // Remove team member mutation (placeholder)
  const removeMemberMutation = useMutation({
    mutationFn: async (memberId: number) => {
      // For now just show a success toast since the API doesn't exist
      toast({
        title: "ลบสมาชิกสำเร็จ",
        description: "สมาชิกทีมได้ถูกลบออกแล้ว",
      });
      
      return { id: memberId };
    },
  });
  
  // Create form with validation
  const form = useForm<TeamMemberFormValues>({
    resolver: zodResolver(teamMemberSchema),
    defaultValues: {
      email: "",
      role: "",
      permissions: [],
    },
  });
  
  // Handle form submission
  const onSubmit = (data: TeamMemberFormValues) => {
    addMemberMutation.mutate(data);
  };
  
  // Handle member removal
  const handleRemoveMember = (memberId: number) => {
    if (confirm("คุณต้องการลบสมาชิกนี้ออกจากทีมหรือไม่?")) {
      removeMemberMutation.mutate(memberId);
    }
  };
  
  // Check if user has team management permission based on package
  const canManageTeam = user?.packageType === 'pro' || user?.packageType === 'basic';
  
  // Get member limit based on package
  const getMemberLimit = () => {
    switch (user?.packageType) {
      case 'pro':
        return 10;
      case 'basic':
        return 3;
      case 'free':
      default:
        return 0;
    }
  };
  
  const memberLimit = getMemberLimit();
  const currentMemberCount = teamMembers?.length || 0;
  
  return (
    <div className="flex min-h-screen bg-background">
      {/* Sidebar */}
      <DashboardNav />

      {/* Main content */}
      <div className="flex-1 overflow-hidden">
        <DashboardHeader user={user} />

        <main className="flex-1 overflow-y-auto p-6">
          <div className="mx-auto max-w-6xl space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-3xl font-bold tracking-tight">ทีมของฉัน</h1>
                <p className="text-muted-foreground">
                  จัดการทีมงานและสิทธิ์การใช้งาน
                </p>
              </div>
              
              {canManageTeam && currentMemberCount < memberLimit && (
                <Dialog open={openAddDialog} onOpenChange={setOpenAddDialog}>
                  <DialogTrigger asChild>
                    <Button className="flex items-center gap-2 shrink-0">
                      <UserPlus className="h-4 w-4" />
                      เพิ่มสมาชิกใหม่
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-[500px]">
                    <DialogHeader>
                      <DialogTitle>เพิ่มสมาชิกทีม</DialogTitle>
                      <DialogDescription>
                        เชิญสมาชิกใหม่เข้าร่วมทีมของคุณ
                      </DialogDescription>
                    </DialogHeader>
                    <Form {...form}>
                      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                        <FormField
                          control={form.control}
                          name="email"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>อีเมล</FormLabel>
                              <FormControl>
                                <Input placeholder="อีเมลของสมาชิกที่ต้องการเชิญ" {...field} />
                              </FormControl>
                              <FormDescription>
                                คำเชิญจะถูกส่งไปยังอีเมลนี้
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="role"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>บทบาท</FormLabel>
                              <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="เลือกบทบาท" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  {teamRoles.map((role) => (
                                    <SelectItem key={role.value} value={role.value}>{role.label}</SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <FormDescription>
                                บทบาทจะกำหนดสิทธิ์การใช้งานของสมาชิก
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <div className="flex justify-between items-center py-2">
                          <span className="text-sm font-medium">การอนุญาต</span>
                          <span className="text-xs text-muted-foreground">
                            ตามบทบาทที่เลือก
                          </span>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          {permissionOptions.map((permission) => (
                            <div key={permission.value} className="flex items-center space-x-2 rounded-md border p-2">
                              <Badge variant="outline" className={
                                (form.watch('role') === 'admin' || form.watch('role') === 'manager') ? 'bg-primary/10' : ''
                              }>
                                {(form.watch('role') === 'admin' || form.watch('role') === 'manager') ? '✓' : '⨯'}
                              </Badge>
                              <span className="text-sm">{permission.label}</span>
                            </div>
                          ))}
                        </div>
                        <DialogFooter className="pt-4">
                          <Button
                            type="button"
                            variant="outline"
                            onClick={() => setOpenAddDialog(false)}
                          >
                            ยกเลิก
                          </Button>
                          <Button 
                            type="submit"
                            disabled={addMemberMutation.isPending}
                          >
                            {addMemberMutation.isPending ? (
                              <span className="flex items-center gap-2">
                                <div className="h-4 w-4 animate-spin rounded-full border-2 border-background border-t-transparent"></div>
                                กำลังส่งคำเชิญ...
                              </span>
                            ) : (
                              "ส่งคำเชิญ"
                            )}
                          </Button>
                        </DialogFooter>
                      </form>
                    </Form>
                  </DialogContent>
                </Dialog>
              )}
            </div>

            <Card>
              <CardHeader>
                <CardTitle>สมาชิกทีม</CardTitle>
                <CardDescription>
                  สมาชิกทีมทั้งหมดและสิทธิ์การใช้งาน ({currentMemberCount}/{memberLimit} คน)
                </CardDescription>
              </CardHeader>
              <CardContent>
                {!canManageTeam ? (
                  <div className="rounded-lg border p-6 text-center">
                    <Shield className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                    <h3 className="text-lg font-medium mb-2">คุณไม่สามารถจัดการทีมได้</h3>
                    <p className="text-muted-foreground mb-6">อัพเกรดเป็นแผน Basic หรือ Pro เพื่อเข้าถึงฟีเจอร์การจัดการทีม</p>
                    <Button onClick={() => window.location.href = "/pricing"}>
                      อัพเกรดแผนการใช้งาน
                    </Button>
                  </div>
                ) : isLoading ? (
                  <div className="flex justify-center py-8">
                    <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
                  </div>
                ) : !teamMembers || teamMembers.length === 0 ? (
                  <div className="py-8 text-center">
                    <Users className="mx-auto h-12 w-12 text-muted-foreground" />
                    <p className="mt-4 text-lg font-medium">ยังไม่มีสมาชิกทีม</p>
                    <p className="mt-1 text-sm text-muted-foreground">
                      เชิญสมาชิกเข้าร่วมทีมของคุณเพื่อทำงานร่วมกัน
                    </p>
                    <Button className="mt-4" onClick={() => setOpenAddDialog(true)}>
                      <UserPlus className="mr-2 h-4 w-4" /> เพิ่มสมาชิกใหม่
                    </Button>
                  </div>
                ) : (
                  <>
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>ชื่อ</TableHead>
                            <TableHead>บทบาท</TableHead>
                            <TableHead>สถานะ</TableHead>
                            <TableHead>การติดต่อ</TableHead>
                            <TableHead className="text-right">การจัดการ</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {/* Owner row - always shown */}
                          <TableRow>
                            <TableCell>
                              <div className="flex items-center gap-3">
                                <Avatar>
                                  <AvatarImage src={user?.profilePicture || undefined} alt={user?.fullName} />
                                  <AvatarFallback>{user?.fullName?.slice(0, 2).toUpperCase() || "U"}</AvatarFallback>
                                </Avatar>
                                <div>
                                  <div className="font-medium">{user?.fullName || user?.username} <span className="text-xs text-muted-foreground">(คุณ)</span></div>
                                  <div className="text-sm text-muted-foreground">{user?.email}</div>
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge variant="default" className="bg-primary text-primary-foreground">เจ้าของ</Badge>
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline" className="bg-green-50 text-green-700 hover:bg-green-50">
                                ใช้งานอยู่
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <Button variant="ghost" size="icon" className="h-8 w-8">
                                  <Mail className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                            <TableCell className="text-right">
                              <Button variant="ghost" size="sm" disabled>
                                จัดการ
                              </Button>
                            </TableCell>
                          </TableRow>
                          
                          {/* Team members */}
                          {teamMembers.map((member: TeamMember) => (
                            <TableRow key={member.id}>
                              <TableCell>
                                <div className="flex items-center gap-3">
                                  <Avatar>
                                    <AvatarImage src={member.avatar} alt={member.name} />
                                    <AvatarFallback>{member.name.slice(0, 2).toUpperCase()}</AvatarFallback>
                                  </Avatar>
                                  <div>
                                    <div className="font-medium">{member.name}</div>
                                    <div className="text-sm text-muted-foreground">{member.email}</div>
                                  </div>
                                </div>
                              </TableCell>
                              <TableCell>
                                <Badge variant="outline">
                                  {member.role === 'admin' ? 'ผู้ดูแลระบบ' :
                                   member.role === 'manager' ? 'ผู้จัดการ' :
                                   member.role === 'editor' ? 'ผู้แก้ไข' : 'ผู้ชม'}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                <Badge variant={
                                  member.status === 'active' ? 'outline' : 
                                  member.status === 'invited' ? 'secondary' : 'destructive'
                                } className={
                                  member.status === 'active' ? 'bg-green-50 text-green-700 hover:bg-green-50' : ''
                                }>
                                  {member.status === 'active' ? 'ใช้งานอยู่' :
                                   member.status === 'invited' ? 'รอการตอบรับ' : 'ปฏิเสธ'}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                <div className="flex items-center gap-2">
                                  <Button variant="ghost" size="icon" className="h-8 w-8">
                                    <Mail className="h-4 w-4" />
                                  </Button>
                                  <Button variant="ghost" size="icon" className="h-8 w-8">
                                    <Phone className="h-4 w-4" />
                                  </Button>
                                </div>
                              </TableCell>
                              <TableCell className="text-right">
                                <div className="flex justify-end gap-2">
                                  <Button variant="ghost" size="icon" className="h-8 w-8">
                                    <Edit className="h-4 w-4" />
                                  </Button>
                                  <Button 
                                    variant="ghost" 
                                    size="icon" 
                                    className="h-8 w-8 text-destructive"
                                    onClick={() => handleRemoveMember(member.id)}
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </div>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                    
                    {currentMemberCount >= memberLimit && (
                      <div className="mt-4 rounded-lg border p-4 bg-muted/50">
                        <p className="text-sm text-center">
                          คุณได้ใช้โควต้าสมาชิกทีมหมดแล้ว ({currentMemberCount}/{memberLimit}) <br />
                          <a href="/pricing" className="text-primary underline">อัพเกรดแผนการใช้งาน</a> เพื่อเพิ่มสมาชิกมากขึ้น
                        </p>
                      </div>
                    )}
                  </>
                )}
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}