import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { z } from "zod";
import { User } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { DashboardHeader } from "@/components/dashboard/DashboardHeader";
import { DashboardNav } from "@/components/dashboard/DashboardNav";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { ArrowRight, Shield, UserCircle, CreditCard } from "lucide-react";

// User profile update schema
const profileSchema = z.object({
  fullName: z.string().min(2, {
    message: "ชื่อเต็มต้องมีอย่างน้อย 2 ตัวอักษร",
  }),
  artistName: z.string().min(2, {
    message: "ชื่อศิลปินต้องมีอย่างน้อย 2 ตัวอักษร",
  }),
  email: z.string().email({
    message: "อีเมลไม่ถูกต้อง",
  }),
});

// Password update schema
const passwordSchema = z.object({
  currentPassword: z.string().min(6, {
    message: "รหัสผ่านปัจจุบันต้องมีอย่างน้อย 6 ตัวอักษร",
  }),
  newPassword: z.string().min(8, {
    message: "รหัสผ่านใหม่ต้องมีอย่างน้อย 8 ตัวอักษร",
  }),
  confirmPassword: z.string(),
}).refine((data) => data.newPassword === data.confirmPassword, {
  message: "รหัสผ่านใหม่และยืนยันรหัสผ่านไม่ตรงกัน",
  path: ["confirmPassword"],
});

type ProfileFormValues = z.infer<typeof profileSchema>;
type PasswordFormValues = z.infer<typeof passwordSchema>;

export default function SettingsPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState<string>("profile");

  // Profile update form
  const profileForm = useForm<ProfileFormValues>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      fullName: user?.fullName || "",
      artistName: user?.artistName || "",
      email: user?.email || "",
    },
  });

  // Password update form
  const passwordForm = useForm<PasswordFormValues>({
    resolver: zodResolver(passwordSchema),
    defaultValues: {
      currentPassword: "",
      newPassword: "",
      confirmPassword: "",
    },
  });

  // Update profile mutation
  const updateProfileMutation = useMutation({
    mutationFn: async (data: ProfileFormValues) => {
      return await apiRequest<User>({
        url: "/api/auth/profile",
        method: "PATCH",
        body: data,
      });
    },
    onSuccess: (data) => {
      toast({
        title: "บันทึกการเปลี่ยนแปลงสำเร็จ",
        description: "ข้อมูลโปรไฟล์ของคุณได้รับการอัปเดตแล้ว",
      });
      queryClient.setQueryData(["/api/auth/me"], data);
    },
    onError: (error) => {
      toast({
        title: "เกิดข้อผิดพลาด",
        description: error instanceof Error ? error.message : "ไม่สามารถอัปเดตโปรไฟล์ได้",
        variant: "destructive",
      });
    },
  });

  // Update password mutation
  const updatePasswordMutation = useMutation({
    mutationFn: async (data: PasswordFormValues) => {
      return await apiRequest({
        url: "/api/auth/password",
        method: "PATCH",
        body: {
          currentPassword: data.currentPassword,
          newPassword: data.newPassword,
        },
      });
    },
    onSuccess: () => {
      toast({
        title: "เปลี่ยนรหัสผ่านสำเร็จ",
        description: "รหัสผ่านของคุณได้รับการอัปเดตแล้ว",
      });
      passwordForm.reset({
        currentPassword: "",
        newPassword: "",
        confirmPassword: "",
      });
    },
    onError: (error) => {
      toast({
        title: "เกิดข้อผิดพลาด",
        description: error instanceof Error ? error.message : "ไม่สามารถเปลี่ยนรหัสผ่านได้",
        variant: "destructive",
      });
    },
  });

  // Handle profile form submission
  const onProfileSubmit = (data: ProfileFormValues) => {
    updateProfileMutation.mutate(data);
  };

  // Handle password form submission
  const onPasswordSubmit = (data: PasswordFormValues) => {
    updatePasswordMutation.mutate(data);
  };

  return (
    <div className="flex min-h-screen bg-background">
      {/* Sidebar */}
      <DashboardNav />

      {/* Main content */}
      <div className="flex-1 overflow-hidden">
        <DashboardHeader user={user} />

        <main className="flex-1 overflow-y-auto p-6">
          <div className="mx-auto max-w-4xl space-y-6">
            <div>
              <h1 className="text-3xl font-bold tracking-tight">การตั้งค่า</h1>
              <p className="text-muted-foreground">
                จัดการบัญชีและความปลอดภัยของคุณ
              </p>
            </div>

            <Tabs defaultValue="profile" value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full md:w-auto grid-cols-3">
                <TabsTrigger value="profile" className="flex gap-2 items-center">
                  <UserCircle className="h-4 w-4" />
                  <span className="hidden md:inline">โปรไฟล์</span>
                </TabsTrigger>
                <TabsTrigger value="security" className="flex gap-2 items-center">
                  <Shield className="h-4 w-4" />
                  <span className="hidden md:inline">ความปลอดภัย</span>
                </TabsTrigger>
                <TabsTrigger value="billing" className="flex gap-2 items-center">
                  <CreditCard className="h-4 w-4" />
                  <span className="hidden md:inline">การชำระเงิน</span>
                </TabsTrigger>
              </TabsList>
              
              {/* Profile Tab */}
              <TabsContent value="profile">
                <Card>
                  <CardHeader>
                    <CardTitle>ข้อมูลโปรไฟล์</CardTitle>
                    <CardDescription>
                      อัปเดตข้อมูลส่วนตัวและข้อมูลของคุณที่นี่
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...profileForm}>
                      <form onSubmit={profileForm.handleSubmit(onProfileSubmit)} className="space-y-4">
                        <FormField
                          control={profileForm.control}
                          name="fullName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>ชื่อเต็ม</FormLabel>
                              <FormControl>
                                <Input placeholder="ชื่อจริง นามสกุล" {...field} />
                              </FormControl>
                              <FormDescription>
                                ชื่อเต็มของคุณสำหรับการติดต่อและการชำระเงิน
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={profileForm.control}
                          name="artistName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>ชื่อศิลปิน</FormLabel>
                              <FormControl>
                                <Input placeholder="ชื่อที่ใช้ในการเผยแพร่ผลงาน" {...field} />
                              </FormControl>
                              <FormDescription>
                                ชื่อที่จะแสดงบนแพลตฟอร์มสตรีมมิง
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={profileForm.control}
                          name="email"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>อีเมล</FormLabel>
                              <FormControl>
                                <Input type="email" placeholder="your-email@example.com" {...field} />
                              </FormControl>
                              <FormDescription>
                                อีเมลที่ใช้ในการติดต่อและแจ้งเตือน
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <Button 
                          type="submit" 
                          className="w-full md:w-auto"
                          disabled={updateProfileMutation.isPending}
                        >
                          {updateProfileMutation.isPending ? (
                            <span className="flex items-center gap-2">
                              <div className="h-4 w-4 animate-spin rounded-full border-2 border-background border-t-transparent"></div>
                              กำลังบันทึก...
                            </span>
                          ) : (
                            "บันทึกการเปลี่ยนแปลง"
                          )}
                        </Button>
                      </form>
                    </Form>
                  </CardContent>
                </Card>
              </TabsContent>
              
              {/* Security Tab */}
              <TabsContent value="security">
                <Card>
                  <CardHeader>
                    <CardTitle>ความปลอดภัย</CardTitle>
                    <CardDescription>
                      จัดการความปลอดภัยของบัญชีและเปลี่ยนรหัสผ่าน
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...passwordForm}>
                      <form onSubmit={passwordForm.handleSubmit(onPasswordSubmit)} className="space-y-4">
                        <FormField
                          control={passwordForm.control}
                          name="currentPassword"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>รหัสผ่านปัจจุบัน</FormLabel>
                              <FormControl>
                                <Input type="password" placeholder="••••••••" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={passwordForm.control}
                          name="newPassword"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>รหัสผ่านใหม่</FormLabel>
                              <FormControl>
                                <Input type="password" placeholder="••••••••" {...field} />
                              </FormControl>
                              <FormDescription>
                                รหัสผ่านควรมีความยาวอย่างน้อย 8 ตัวอักษร
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={passwordForm.control}
                          name="confirmPassword"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>ยืนยันรหัสผ่านใหม่</FormLabel>
                              <FormControl>
                                <Input type="password" placeholder="••••••••" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <Button 
                          type="submit" 
                          className="w-full md:w-auto"
                          disabled={updatePasswordMutation.isPending}
                        >
                          {updatePasswordMutation.isPending ? (
                            <span className="flex items-center gap-2">
                              <div className="h-4 w-4 animate-spin rounded-full border-2 border-background border-t-transparent"></div>
                              กำลังเปลี่ยนรหัสผ่าน...
                            </span>
                          ) : (
                            "เปลี่ยนรหัสผ่าน"
                          )}
                        </Button>
                      </form>
                    </Form>
                  </CardContent>
                </Card>
              </TabsContent>
              
              {/* Billing Tab */}
              <TabsContent value="billing">
                <Card>
                  <CardHeader>
                    <CardTitle>แผนการใช้งานและการชำระเงิน</CardTitle>
                    <CardDescription>
                      จัดการแผนการใช้งานและข้อมูลการชำระเงินของคุณ
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="rounded-lg border p-4">
                      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                        <div>
                          <h3 className="text-lg font-medium">
                            แผนปัจจุบัน: <span className="text-primary">{user?.packageType === 'pro' ? 'Pro' : user?.packageType === 'basic' ? 'Basic' : 'Free'}</span>
                          </h3>
                          <p className="text-sm text-muted-foreground">
                            {user?.packageType === 'pro' ? 'แผน Pro รองรับการเผยแพร่เพลงไม่จำกัดจำนวน' :
                             user?.packageType === 'basic' ? 'แผน Basic รองรับการเผยแพร่เพลงสูงสุด 50 เพลงต่อปี' :
                             'แผน Free รองรับการเผยแพร่เพลงสูงสุด 2 เพลงต่อปี'}
                          </p>
                        </div>
                        <Button className="shrink-0" onClick={() => window.location.href = "/pricing"}>
                          <span className="flex items-center gap-1">
                            อัพเกรดแผนการใช้งาน
                            <ArrowRight className="h-4 w-4" />
                          </span>
                        </Button>
                      </div>
                    </div>
                    
                    <div className="rounded-lg border p-4">
                      <h3 className="text-lg font-medium mb-4">ประวัติการชำระเงิน</h3>
                      <div className="text-center py-6 text-muted-foreground">
                        <p>ยังไม่มีประวัติการชำระเงิน</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>
    </div>
  );
}