import { useState } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest } from "@/lib/queryClient";
import { Track } from "@shared/schema";
import { DashboardHeader } from "@/components/dashboard/DashboardHeader";
import { DashboardNav } from "@/components/dashboard/DashboardNav";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowLeft, BarChart2, Copy, Download, Globe, Info, Link, Music, Share2, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { 
  StreamingPlatformLogo, 
  StreamingPlatformDetails, 
  type StreamingPlatform 
} from "@/components/streaming-platform-logos";

export default function TrackDetails() {
  const { id } = useParams();
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("overview");

  // Fetch track details
  const { data: track, isLoading: isLoadingTrack } = useQuery({
    queryKey: [`/api/tracks/${id}`],
    queryFn: () => apiRequest<Track>({ url: `/api/tracks/${id}`, method: "GET" }),
    enabled: !!id,
  });

  // Fetch streaming stats
  const { data: streamingStats, isLoading: isLoadingStats } = useQuery({
    queryKey: [`/api/tracks/${id}/stats`],
    queryFn: () => apiRequest<any>({ 
      url: `/api/tracks/${id}/stats?period=month`, 
      method: "GET"
    }),
    enabled: !!id && !!track,
  });

  // Fetch revenue data
  const { data: revenueData, isLoading: isLoadingRevenue } = useQuery({
    queryKey: [`/api/tracks/${id}/revenue`],
    queryFn: () => apiRequest<any>({ 
      url: `/api/tracks/${id}/revenue?period=month`, 
      method: "GET"
    }),
    enabled: !!id && !!track,
  });

  // Set loading state based on all queries
  const isLoading = isLoadingTrack || isLoadingStats || isLoadingRevenue;

  // Map platforms to streaming platform types
  const platformToType: Record<string, StreamingPlatform> = {
    "Spotify": "spotify",
    "Apple Music": "appleMusic",
    "YouTube Music": "youtubeMusic",
    "Joox": "joox",
    "TIDAL": "tidal",
  };
  
  // Generate platform data from streaming stats or fallback to sample data
  const platforms = streamingStats ? [
    {
      name: "Spotify",
      platformType: "spotify" as StreamingPlatform,
      streams: streamingStats.platformDistribution["Spotify"] || 0,
      revenue: parseFloat(revenueData?.platformBreakdown?.spotify?.revenue?.thb || "0"),
      status: track?.status === "live" ? "live" : track?.status || "pending",
      link: "https://open.spotify.com/track/example",
    },
    {
      name: "Apple Music",
      platformType: "appleMusic" as StreamingPlatform,
      streams: streamingStats.platformDistribution["Apple Music"] || 0,
      revenue: parseFloat(revenueData?.platformBreakdown?.appleMusicMusic?.revenue?.thb || "0"),
      status: track?.status === "live" ? "live" : "processing",
      link: "https://music.apple.com/track/example",
    },
    {
      name: "YouTube Music",
      platformType: "youtubeMusic" as StreamingPlatform,
      streams: streamingStats.platformDistribution["YouTube Music"] || 0,
      revenue: parseFloat(revenueData?.platformBreakdown?.youtubeMusic?.revenue?.thb || "0"),
      status: track?.status === "live" ? "live" : "processing",
      link: "https://music.youtube.com/watch?v=example",
    },
    {
      name: "Joox",
      platformType: "joox" as StreamingPlatform,
      streams: streamingStats.platformDistribution["Joox"] || 0,
      revenue: parseFloat(revenueData?.platformBreakdown?.joox?.revenue?.thb || "0"),
      status: track?.status === "live" ? "live" : "processing",
      link: "",
    },
    {
      name: "Others",
      platformType: null,
      icon: "🌐",
      streams: streamingStats.platformDistribution["Others"] || 0,
      revenue: parseFloat(revenueData?.platformBreakdown?.others?.revenue?.thb || "0"),
      status: track?.status === "live" ? "live" : "processing",
      link: "",
    },
  ] : [
    { name: "Spotify", platformType: "spotify" as StreamingPlatform, streams: 0, revenue: 0, status: "pending", link: "" },
    { name: "Apple Music", platformType: "appleMusic" as StreamingPlatform, streams: 0, revenue: 0, status: "pending", link: "" },
    { name: "YouTube Music", platformType: "youtubeMusic" as StreamingPlatform, streams: 0, revenue: 0, status: "pending", link: "" },
    { name: "Joox", platformType: "joox" as StreamingPlatform, streams: 0, revenue: 0, status: "pending", link: "" },
    { name: "Others", platformType: null, icon: "🌐", streams: 0, revenue: 0, status: "pending", link: "" },
  ];

  // Total stats - calculated from actual data
  const totalStreams = streamingStats ? streamingStats.totalStreams : 0;
  const totalRevenue = revenueData ? parseFloat(revenueData.revenue.thb) : 0;
  
  // Query client for invalidating queries
  const queryClient = useQueryClient();

  // Mutation for distributing track to platforms
  const distributeTrackMutation = useMutation({
    mutationFn: () => apiRequest<any>({ 
      url: `/api/tracks/${id}/distribute`, 
      method: "POST" 
    }),
    onSuccess: () => {
      toast({
        title: "ส่งคำขอเผยแพร่เพลงเรียบร้อย",
        description: "เพลงของคุณกำลังถูกเผยแพร่ไปยังแพลตฟอร์มต่างๆ โปรดรอสักครู่",
      });
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: [`/api/tracks/${id}`] });
      queryClient.invalidateQueries({ queryKey: [`/api/tracks/${id}/stats`] });
      queryClient.invalidateQueries({ queryKey: [`/api/tracks/${id}/revenue`] });
    },
    onError: (error: Error) => {
      toast({
        title: "เกิดข้อผิดพลาด",
        description: "ไม่สามารถเผยแพร่เพลงได้: " + error.message,
        variant: "destructive",
      });
    }
  });

  // Handle copy share link
  const handleCopyLink = () => {
    const baseUrl = window.location.origin;
    const shareLink = `${baseUrl}/share/track/${id}`;
    
    navigator.clipboard.writeText(shareLink).then(
      () => {
        toast({
          title: "คัดลอกลิงค์เรียบร้อย",
          description: "ลิงค์ได้ถูกคัดลอกไปยังคลิปบอร์ดแล้ว",
        });
      },
      () => {
        toast({
          title: "ไม่สามารถคัดลอกลิงค์ได้",
          description: "กรุณาคัดลอกด้วยตนเอง",
          variant: "destructive",
        });
      }
    );
  };

  if (isLoading) {
    return (
      <div className="flex min-h-screen bg-background">
        <DashboardNav />
        <div className="flex-1 overflow-hidden">
          <DashboardHeader user={user} />
          <main className="flex-1 overflow-y-auto p-6">
            <div className="mx-auto max-w-5xl">
              <div className="flex justify-center items-center h-64">
                <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
              </div>
            </div>
          </main>
        </div>
      </div>
    );
  }

  if (!track) {
    return (
      <div className="flex min-h-screen bg-background">
        <DashboardNav />
        <div className="flex-1 overflow-hidden">
          <DashboardHeader user={user} />
          <main className="flex-1 overflow-y-auto p-6">
            <div className="mx-auto max-w-5xl">
              <Card className="text-center p-6">
                <CardHeader>
                  <CardTitle>ไม่พบเพลง</CardTitle>
                  <CardDescription>
                    ไม่พบข้อมูลเพลงที่ต้องการ หรือคุณอาจไม่มีสิทธิ์ในการเข้าถึง
                  </CardDescription>
                </CardHeader>
                <CardFooter className="justify-center">
                  <Button onClick={() => navigate("/dashboard")}>
                    กลับไปยังแดชบอร์ด
                  </Button>
                </CardFooter>
              </Card>
            </div>
          </main>
        </div>
      </div>
    );
  }

  // Get status display info
  const getStatusInfo = (status: string | undefined) => {
    switch (status) {
      case "live":
        return { color: "text-green-500", text: "ออนไลน์", bg: "bg-green-50" };
      case "pending":
        return { color: "text-yellow-500", text: "รอการตรวจสอบ", bg: "bg-yellow-50" };
      case "processing":
        return { color: "text-blue-500", text: "กำลังประมวลผล", bg: "bg-blue-50" };
      case "distributing":
        return { color: "text-purple-500", text: "กำลังเผยแพร่", bg: "bg-purple-50" };
      case "rejected":
        return { color: "text-red-500", text: "ถูกปฏิเสธ", bg: "bg-red-50" };
      default:
        return { color: "text-gray-500", text: "ไม่ทราบสถานะ", bg: "bg-gray-50" };
    }
  };

  const statusInfo = getStatusInfo(track.status);

  return (
    <div className="flex min-h-screen bg-background">
      <DashboardNav />
      <div className="flex-1 overflow-hidden">
        <DashboardHeader user={user} />
        <main className="flex-1 overflow-y-auto p-6">
          <div className="mx-auto max-w-5xl space-y-6">
            {/* Header */}
            <div>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => navigate("/dashboard")}
                className="mb-4"
              >
                <ArrowLeft className="mr-2 h-4 w-4" />
                กลับไปยังแดชบอร์ด
              </Button>
              
              <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                <div>
                  <h1 className="text-3xl font-bold">{track.title}</h1>
                  <div className="mt-1 flex items-center">
                    <span className={`inline-flex rounded-full px-2 py-0.5 text-xs font-medium ${statusInfo.bg} ${statusInfo.color}`}>
                      {statusInfo.text}
                    </span>
                    <span className="ml-2 text-sm text-muted-foreground">
                      อัปโหลดเมื่อ {new Date(track.createdAt).toLocaleDateString('th-TH')}
                    </span>
                  </div>
                </div>
                
                <div className="mt-4 flex space-x-2 md:mt-0">
                  {/* เผยแพร่ไปยังแพลตฟอร์ม */}
                  {track.status === "pending" && (
                    <Button
                      size="sm"
                      variant="default"
                      onClick={() => distributeTrackMutation.mutate()}
                      disabled={distributeTrackMutation.isPending}
                    >
                      {distributeTrackMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          กำลังเผยแพร่...
                        </>
                      ) : (
                        <>
                          <Globe className="mr-2 h-4 w-4" />
                          เผยแพร่เพลง
                        </>
                      )}
                    </Button>
                  )}

                  <Button
                    size="sm"
                    variant="outline"
                    onClick={handleCopyLink}
                  >
                    <Copy className="mr-2 h-4 w-4" />
                    คัดลอกลิงค์
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => window.open(`/uploads/${track.audioFile}`, '_blank')}
                    disabled={!track.audioFile}
                  >
                    <Download className="mr-2 h-4 w-4" />
                    ดาวน์โหลด
                  </Button>
                </div>
              </div>
            </div>

            {/* Main content */}
            <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
              {/* Left column - Track info */}
              <div>
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center text-lg">
                      <Music className="mr-2 h-5 w-5" />
                      ข้อมูลเพลง
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="aspect-square bg-gray-100 relative flex items-center justify-center">
                      <div className="absolute inset-0 flex items-center justify-center bg-black/5">
                        <Music className="h-16 w-16 text-gray-400" />
                      </div>
                      <Button 
                        size="sm" 
                        variant="secondary" 
                        className="absolute bottom-2 right-2 opacity-90"
                        onClick={() => window.open(`/uploads/${track.audioFile}`, '_blank')}
                      >
                        ฟังเพลง
                      </Button>
                    </div>
                    
                    <div className="pt-3 space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">ความยาว</span>
                        <span className="text-sm font-medium">
                          {Math.floor(track.duration / 60)}:{(track.duration % 60).toString().padStart(2, '0')}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">แนวเพลง</span>
                        <span className="text-sm font-medium">{track.genre}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">วันที่เผยแพร่</span>
                        <span className="text-sm font-medium">
                          {new Date(track.releaseDate).toLocaleDateString('th-TH')}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">ISRC</span>
                        <span className="text-sm font-medium">{track.isrc || "ไม่มี"}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Right column - Statistics and platforms */}
              <div className="md:col-span-2">
                <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab}>
                  <TabsList>
                    <TabsTrigger value="overview">ภาพรวม</TabsTrigger>
                    <TabsTrigger value="analytics">สถิติ</TabsTrigger>
                    <TabsTrigger value="platforms">แพลตฟอร์ม</TabsTrigger>
                    {track.lyrics && <TabsTrigger value="lyrics">เนื้อเพลง</TabsTrigger>}
                  </TabsList>
                  
                  {/* Overview tab */}
                  <TabsContent value="overview" className="space-y-4">
                    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                      <Card>
                        <CardHeader className="pb-2">
                          <CardDescription>การสตรีมทั้งหมด</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="text-2xl font-bold">{totalStreams.toLocaleString()}</div>
                          <p className="text-xs text-green-500">
                            +12.5% จากเดือนที่แล้ว
                          </p>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardHeader className="pb-2">
                          <CardDescription>รายได้ทั้งหมด</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="text-2xl font-bold">฿{totalRevenue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
                          <p className="text-xs text-green-500">
                            +8.3% จากเดือนที่แล้ว
                          </p>
                        </CardContent>
                      </Card>
                    </div>
                    
                    <Card>
                      <CardHeader>
                        <CardTitle>แพลตฟอร์มยอดนิยม</CardTitle>
                        <CardDescription>
                          แพลตฟอร์มที่มีผู้ฟังเพลงของคุณมากที่สุด
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          {platforms.slice(0, 3).map((platform) => (
                            <div key={platform.name} className="flex items-center justify-between space-y-1">
                              <div className="flex items-center">
                                {platform.platformType ? (
                                  <StreamingPlatformLogo 
                                    platform={platform.platformType} 
                                    size="md" 
                                    className="mr-2" 
                                  />
                                ) : (
                                  <div className="mr-2 text-xl">{platform.icon}</div>
                                )}
                                <div>
                                  <p className="text-sm font-medium">{platform.name}</p>
                                  <p className="text-xs text-muted-foreground">
                                    {platform.streams.toLocaleString()} การสตรีม
                                  </p>
                                </div>
                              </div>
                              <div className="text-right">
                                <p className="text-sm font-medium">฿{platform.revenue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                                <p className="text-xs text-muted-foreground">
                                  {((platform.revenue / totalRevenue) * 100).toFixed(1)}% ของรายได้
                                </p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                      <CardFooter>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="w-full"
                          onClick={() => setActiveTab("platforms")}
                        >
                          ดูทั้งหมด
                        </Button>
                      </CardFooter>
                    </Card>
                  </TabsContent>
                  
                  {/* Analytics tab */}
                  <TabsContent value="analytics" className="space-y-4">
                    <Card>
                      <CardHeader>
                        <CardTitle>ข้อมูลสถิติ</CardTitle>
                        <CardDescription>
                          ข้อมูลการสตรีมและรายได้ในช่วง 30 วันที่ผ่านมา
                        </CardDescription>
                      </CardHeader>
                      <CardContent className="h-80 flex items-center justify-center">
                        <div className="text-center">
                          <BarChart2 className="mx-auto h-16 w-16 text-muted-foreground" />
                          <p className="mt-2 text-sm text-muted-foreground">
                            กราฟแสดงสถิติจะปรากฏที่นี่เมื่อเพลงของคุณมีข้อมูลการสตรีม
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>
                  
                  {/* Platforms tab */}
                  <TabsContent value="platforms" className="space-y-4">
                    <Card>
                      <CardHeader>
                        <CardTitle>สถานะบนแพลตฟอร์ม</CardTitle>
                        <CardDescription>
                          สถานะและสถิติของเพลงบนแพลตฟอร์มต่าง ๆ
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          {platforms.map((platform) => (
                            <div key={platform.name} className="border-b pb-4 last:border-b-0 last:pb-0">
                              <div className="flex items-center justify-between mb-2">
                                <div className="flex items-center">
                                  {platform.platformType ? (
                                    <StreamingPlatformLogo 
                                      platform={platform.platformType} 
                                      size="md" 
                                      className="mr-2" 
                                    />
                                  ) : (
                                    <div className="mr-2 text-xl">{platform.icon}</div>
                                  )}
                                  <div>
                                    <p className="font-medium">{platform.name}</p>
                                    <div className="flex items-center mt-1">
                                      <span className={`inline-flex rounded-full px-2 py-0.5 text-xs font-medium ${
                                        platform.status === 'live' 
                                          ? 'bg-green-50 text-green-500' 
                                          : platform.status === 'processing' 
                                            ? 'bg-blue-50 text-blue-500' 
                                            : 'bg-gray-50 text-gray-500'
                                      }`}>
                                        {platform.status === 'live' 
                                          ? 'ออนไลน์' 
                                          : platform.status === 'processing' 
                                            ? 'กำลังประมวลผล' 
                                            : 'รอดำเนินการ'}
                                      </span>
                                    </div>
                                  </div>
                                </div>
                                <div className="text-right">
                                  <p className="font-medium">฿{platform.revenue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                                  <p className="text-xs text-muted-foreground">
                                    {platform.streams.toLocaleString()} การสตรีม
                                  </p>
                                </div>
                              </div>
                              
                              {platform.status === 'live' && platform.link && (
                                <div className="flex items-center mt-2">
                                  <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    className="h-8 gap-1 text-xs"
                                    onClick={() => window.open(platform.link, '_blank')}
                                  >
                                    <Link className="h-3.5 w-3.5" />
                                    ดูบนแพลตฟอร์ม
                                  </Button>
                                  <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    className="h-8 gap-1 text-xs"
                                    onClick={() => {
                                      navigator.clipboard.writeText(platform.link);
                                      toast({
                                        title: "คัดลอกลิงก์แล้ว",
                                        description: `ลิงก์เพลงบน ${platform.name} ถูกคัดลอกไปยังคลิปบอร์ดแล้ว`,
                                      });
                                    }}
                                  >
                                    <Copy className="h-3.5 w-3.5" />
                                    คัดลอกลิงก์
                                  </Button>
                                  <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    className="h-8 gap-1 text-xs"
                                    onClick={() => {
                                      window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(platform.link)}`, '_blank');
                                    }}
                                  >
                                    <Share2 className="h-3.5 w-3.5" />
                                    แชร์
                                  </Button>
                                </div>
                              )}
                              
                              {platform.status === 'processing' && (
                                <div className="mt-2">
                                  <div className="flex items-center justify-between mb-1">
                                    <span className="text-xs text-muted-foreground">กำลังประมวลผล</span>
                                    <span className="text-xs text-muted-foreground">65%</span>
                                  </div>
                                  <Progress value={65} className="h-1.5" />
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>
                  
                  {/* Lyrics tab */}
                  {track.lyrics && (
                    <TabsContent value="lyrics">
                      <Card>
                        <CardHeader>
                          <CardTitle>เนื้อเพลง</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="whitespace-pre-line font-mono text-sm">
                            {track.lyrics}
                          </div>
                        </CardContent>
                      </Card>
                    </TabsContent>
                  )}
                </Tabs>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}