import { useState, useEffect } from "react";
import { DashboardHeader } from "@/components/dashboard/DashboardHeader";
import { DashboardNav } from "@/components/dashboard/DashboardNav";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useMutation, useQuery } from "@tanstack/react-query";
import { 
  Loader2, Mail, Phone, Globe, Users, Camera, Instagram, Facebook, Twitter, 
  Plus, Music, Edit, Trash2, BadgePlus, Check, CreditCard, Package, Star 
} from "lucide-react";
import { StreamingPlatformLogo } from "@/components/streaming-platform-logos";
import { useToast } from "@/hooks/use-toast";
import { Separator } from "@/components/ui/separator";
import { 
  profileFormSchema, ProfileFormValues, 
  managedArtistFormSchema, ManagedArtistFormValues,
  ManagedArtist
} from "@shared/schema";
import { useLocation } from "wouter";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export default function ProfilePage() {
  const { user, isLoading } = useAuth();
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState("profile");
  const [uploadingImage, setUploadingImage] = useState(false);

  if (isLoading) {
    return (
      <div className="flex min-h-screen bg-background">
        <DashboardNav />
        <div className="flex-1 md:ml-[240px]">
          <DashboardHeader user={undefined} />
          <main className="flex-1 p-6 flex items-center justify-center">
            <div className="text-center">
              <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent mx-auto mb-4"></div>
              <p className="text-muted-foreground">กำลังโหลดข้อมูล...</p>
            </div>
          </main>
        </div>
      </div>
    );
  }
  
  // Update form values when user data changes
  useEffect(() => {
    if (user) {
      profileForm.reset({
        username: user.username || "",
        artistName: user.artistName || "",
        email: user.email || "",
        bio: user.bio || "",
        website: user.website || "",
        phone: user.phone || "",
        location: user.location || "",
        instagram: user.instagram || "",
        facebook: user.facebook || "",
        twitter: user.twitter || "",
        profilePicture: user.profilePicture || "",
      });
    }
  }, [user]);

  // Profile form
  const profileForm = useForm<ProfileFormValues>({
    resolver: zodResolver(profileFormSchema),
    defaultValues: {
      username: user?.username || "",
      artistName: user?.artistName || "",
      email: user?.email || "",
      bio: user?.bio || "",
      website: user?.website || "",
      phone: user?.phone || "",
      location: user?.location || "",
      instagram: user?.instagram || "",
      facebook: user?.facebook || "",
      twitter: user?.twitter || "",
      profilePicture: user?.profilePicture || "",
    },
  });

  // Profile update mutation
  const updateProfileMutation = useMutation({
    mutationFn: async (data: ProfileFormValues) => {
      return await apiRequest({
        url: "/api/users/profile",
        method: "PATCH",
        body: data,
      });
    },
    onSuccess: (data) => {
      toast({
        title: "อัปเดตโปรไฟล์สำเร็จ",
        description: "ข้อมูลโปรไฟล์ของคุณได้รับการอัปเดตเรียบร้อยแล้ว",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
    },
    onError: (error) => {
      toast({
        title: "เกิดข้อผิดพลาด",
        description: "ไม่สามารถอัปเดตโปรไฟล์ได้: " + error.message,
        variant: "destructive",
      });
    },
  });
  
  // Get managed artists
  const { data: managedArtists = [], isLoading: isLoadingArtists } = useQuery<ManagedArtist[]>({
    queryKey: ['/api/artists/managed'],
    enabled: user !== undefined,
  });
  
  // Artist form
  const artistForm = useForm<ManagedArtistFormValues>({
    resolver: zodResolver(managedArtistFormSchema),
    defaultValues: {
      artistName: "",
      fullName: "",
      bio: "",
      profilePicture: "",
      spotifyUrl: "",
      appleMusicUrl: "",
    },
  });
  
  // Create artist mutation
  const createArtistMutation = useMutation({
    mutationFn: async (data: ManagedArtistFormValues) => {
      return await apiRequest({
        url: "/api/artists/managed",
        method: "POST",
        body: data,
      });
    },
    onSuccess: () => {
      toast({
        title: "เพิ่มศิลปินสำเร็จ",
        description: "ข้อมูลศิลปินได้รับการเพิ่มเรียบร้อยแล้ว",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/artists/managed"] });
      artistForm.reset();
      setArtistDialogOpen(false);
    },
    onError: (error) => {
      toast({
        title: "เกิดข้อผิดพลาด",
        description: "ไม่สามารถเพิ่มศิลปินได้: " + error.message,
        variant: "destructive",
      });
    },
  });
  
  // Set primary artist mutation
  const setPrimaryArtistMutation = useMutation({
    mutationFn: async (artistId: number) => {
      return await apiRequest({
        url: `/api/artists/managed/${artistId}/primary`,
        method: "PATCH",
      });
    },
    onSuccess: () => {
      toast({
        title: "ตั้งค่าศิลปินหลักสำเร็จ",
        description: "ศิลปินหลักได้รับการตั้งค่าเรียบร้อยแล้ว",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/artists/managed"] });
    },
    onError: (error) => {
      toast({
        title: "เกิดข้อผิดพลาด",
        description: "ไม่สามารถตั้งค่าศิลปินหลักได้: " + error.message,
        variant: "destructive",
      });
    },
  });
  
  // Update artist mutation
  const updateArtistMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number, data: ManagedArtistFormValues }) => {
      return await apiRequest({
        url: `/api/artists/managed/${id}`,
        method: "PATCH",
        body: data,
      });
    },
    onSuccess: () => {
      toast({
        title: "แก้ไขศิลปินสำเร็จ",
        description: "ข้อมูลศิลปินได้รับการแก้ไขเรียบร้อยแล้ว",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/artists/managed"] });
      setArtistDialogOpen(false);
    },
    onError: (error) => {
      toast({
        title: "เกิดข้อผิดพลาด",
        description: "ไม่สามารถแก้ไขศิลปินได้: " + error.message,
        variant: "destructive",
      });
    },
  });
  
  // Delete artist mutation
  const deleteArtistMutation = useMutation({
    mutationFn: async (artistId: number) => {
      return await apiRequest({
        url: `/api/artists/managed/${artistId}`,
        method: "DELETE",
      });
    },
    onSuccess: () => {
      toast({
        title: "ลบศิลปินสำเร็จ",
        description: "ข้อมูลศิลปินได้รับการลบเรียบร้อยแล้ว",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/artists/managed"] });
    },
    onError: (error) => {
      toast({
        title: "เกิดข้อผิดพลาด",
        description: "ไม่สามารถลบศิลปินได้: " + error.message,
        variant: "destructive",
      });
    },
  });
  
  // Package upgrade mutation
  const upgradePackageMutation = useMutation({
    mutationFn: async (packageType: string) => {
      return await apiRequest({
        url: "/api/payments/upgrade",
        method: "POST",
        body: { packageType },
      });
    },
    onSuccess: () => {
      toast({
        title: "อัปเกรดแพ็คเกจสำเร็จ",
        description: "แพ็คเกจของคุณได้รับการอัปเกรดเรียบร้อยแล้ว",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
    },
    onError: (error) => {
      toast({
        title: "เกิดข้อผิดพลาด",
        description: "ไม่สามารถอัปเกรดแพ็คเกจได้: " + error.message,
        variant: "destructive",
      });
    },
  });

  // Artist image upload state
  const [uploadingArtistImage, setUploadingArtistImage] = useState(false);
  const [artistDialogOpen, setArtistDialogOpen] = useState(false);
  const [currentArtist, setCurrentArtist] = useState<ManagedArtist | null>(null);
  const [confirmDeleteDialogOpen, setConfirmDeleteDialogOpen] = useState(false);

  function onProfileSubmit(data: ProfileFormValues) {
    updateProfileMutation.mutate(data);
  }
  
  function onArtistSubmit(data: ManagedArtistFormValues) {
    if (currentArtist) {
      // Update artist
      updateArtistMutation.mutate({
        id: currentArtist.id,
        data
      });
    } else {
      // Create new artist
      createArtistMutation.mutate(data);
    }
  }
  
  // Handle artist image upload
  const handleArtistImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0 || !currentArtist) return;
    const file = e.target.files[0];
    
    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast({
        title: "ไฟล์ไม่ถูกต้อง",
        description: "กรุณาอัพโหลดไฟล์รูปภาพเท่านั้น",
        variant: "destructive",
      });
      return;
    }
    
    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "ไฟล์ขนาดใหญ่เกินไป",
        description: "ขนาดไฟล์ต้องไม่เกิน 5MB",
        variant: "destructive",
      });
      return;
    }
    
    try {
      setUploadingArtistImage(true);
      
      // Create FormData for file upload
      const formData = new FormData();
      formData.append('profileImage', file);
      
      // Upload image directly to the server
      const response = await fetch(`/api/artists/managed/${currentArtist.id}/image`, {
        method: 'POST',
        body: formData,
        credentials: 'include',
      });
      
      if (!response.ok) {
        throw new Error('ไม่สามารถอัพโหลดรูปภาพได้');
      }
      
      const data = await response.json();
      
      // Update artist form with new image URL
      artistForm.setValue('profilePicture', data.imageUrl);
      
      // Update artist data
      queryClient.invalidateQueries({ queryKey: ["/api/artists/managed"] });
      
      toast({
        title: "อัพโหลดสำเร็จ",
        description: "รูปโปรไฟล์ศิลปินถูกอัพเดตเรียบร้อยแล้ว",
      });
    } catch (error) {
      toast({
        title: "เกิดข้อผิดพลาด",
        description: error instanceof Error ? error.message : "ไม่สามารถอัพโหลดรูปภาพได้",
        variant: "destructive",
      });
    } finally {
      setUploadingArtistImage(false);
    }
  };
  
  // Handle profile image upload
  const handleProfileImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    const file = e.target.files[0];
    
    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast({
        title: "ไฟล์ไม่ถูกต้อง",
        description: "กรุณาอัพโหลดไฟล์รูปภาพเท่านั้น",
        variant: "destructive",
      });
      return;
    }
    
    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "ไฟล์ขนาดใหญ่เกินไป",
        description: "ขนาดไฟล์ต้องไม่เกิน 5MB",
        variant: "destructive",
      });
      return;
    }
    
    try {
      setUploadingImage(true);
      
      // Create FormData for file upload
      const formData = new FormData();
      formData.append('profileImage', file);
      
      // Upload image using apiRequest
      // ส่งไปยัง API โดยตรงแทนการใช้ apiRequest เนื่องจากต้องส่ง FormData
      const response = await fetch('/api/users/profile/image', {
        method: 'POST',
        body: formData,
        credentials: 'include',
        // ไม่ต้องกำหนด Content-Type เพราะ FormData จะกำหนดเอง (multipart/form-data)
      });
      
      if (!response.ok) {
        throw new Error('ไม่สามารถอัพโหลดรูปภาพได้');
      }
      
      const data = await response.json();
      
      // Update profile form with new image URL
      profileForm.setValue('profilePicture', data.imageUrl);
      
      // Update user data in auth context
      queryClient.invalidateQueries({ queryKey: ['/api/auth/me'] });
      
      toast({
        title: "อัพโหลดสำเร็จ",
        description: "รูปโปรไฟล์ถูกอัพเดตเรียบร้อยแล้ว",
      });
    } catch (error) {
      toast({
        title: "เกิดข้อผิดพลาด",
        description: error instanceof Error ? error.message : "ไม่สามารถอัพโหลดรูปภาพได้",
        variant: "destructive",
      });
    } finally {
      setUploadingImage(false);
    }
  };

  if (!user) {
    return (
      <div className="flex min-h-screen bg-background">
        <DashboardNav />
        <div className="flex-1 md:ml-[240px]">
          <DashboardHeader user={undefined} />
          <main className="flex-1 p-6 flex items-center justify-center">
            <div className="text-center">
              <Loader2 className="h-12 w-12 animate-spin mx-auto mb-4 text-primary" />
              <p className="text-muted-foreground">กำลังโหลดข้อมูล...</p>
            </div>
          </main>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-background">
      <DashboardNav />
      <div className="flex-1 md:ml-[240px]">
        <DashboardHeader user={user} />
        <main className="flex-1 p-6 lg:p-8">
          <div className="space-y-6">
            <div>
              <h1 className="text-3xl font-bold tracking-tight">โปรไฟล์ของฉัน</h1>
              <p className="text-muted-foreground">
                จัดการข้อมูลส่วนตัวและโปรไฟล์ศิลปินของคุณ
              </p>
            </div>
            
            <div className="flex flex-col md:flex-row gap-4 md:gap-8">
              {/* Left column - User Profile Card */}
              <div className="w-full md:w-[280px] flex flex-col gap-4">
                <Card>
                  <CardContent className="p-6 flex flex-col items-center gap-4">
                    <Avatar className="h-24 w-24 border-4 border-primary/10">
                      <AvatarImage src={user?.profilePicture || ""} alt={user?.artistName || user?.username || ""} />
                      <AvatarFallback className="text-2xl">
                        {user?.artistName ? user.artistName.charAt(0).toUpperCase() : user?.username ? user.username.charAt(0).toUpperCase() : "U"}
                      </AvatarFallback>
                    </Avatar>
                    <div className="text-center">
                      <h2 className="text-xl font-bold">{user?.artistName || user?.username || "ผู้ใช้"}</h2>
                      <p className="text-sm text-muted-foreground">@{user?.username || "user"}</p>
                    </div>
                    <label htmlFor="profile-upload" className={`cursor-pointer ${uploadingImage ? 'opacity-70 pointer-events-none' : ''}`}>
                      <Button variant="outline" type="button" className="w-full gap-2" disabled={uploadingImage}>
                        {uploadingImage ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <Camera className="h-4 w-4" />
                        )}
                        {uploadingImage ? 'กำลังอัพโหลด...' : 'เปลี่ยนรูปภาพ'}
                      </Button>
                      <input 
                        id="profile-upload" 
                        type="file" 
                        accept="image/*" 
                        className="hidden" 
                        onChange={(e) => handleProfileImageUpload(e)}
                        disabled={uploadingImage}
                      />
                    </label>
                  </CardContent>
                  <Separator />
                  <CardContent className="p-6">
                    <div className="space-y-3">
                      <div className="flex items-center text-sm">
                        <Mail className="mr-2 h-4 w-4 text-muted-foreground" />
                        <span>{user?.email || ""}</span>
                      </div>
                      {user?.phone && (
                        <div className="flex items-center text-sm">
                          <Phone className="mr-2 h-4 w-4 text-muted-foreground" />
                          <span>{user.phone}</span>
                        </div>
                      )}
                      {user?.website && (
                        <div className="flex items-center text-sm">
                          <Globe className="mr-2 h-4 w-4 text-muted-foreground" />
                          <a href={user.website} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">{user.website}</a>
                        </div>
                      )}
                      {user?.location && (
                        <div className="flex items-center text-sm">
                          <Users className="mr-2 h-4 w-4 text-muted-foreground" />
                          <span>{user.location}</span>
                        </div>
                      )}
                    </div>
                  </CardContent>
                  <Separator />
                  <CardContent className="p-6">
                    <div className="flex justify-between">
                      {user?.instagram && (
                        <a href={`https://instagram.com/${user.instagram}`} target="_blank" rel="noopener noreferrer">
                          <Instagram className="h-5 w-5 text-muted-foreground hover:text-primary" />
                        </a>
                      )}
                      {user?.facebook && (
                        <a href={`https://facebook.com/${user.facebook}`} target="_blank" rel="noopener noreferrer">
                          <Facebook className="h-5 w-5 text-muted-foreground hover:text-primary" />
                        </a>
                      )}
                      {user?.twitter && (
                        <a href={`https://twitter.com/${user.twitter}`} target="_blank" rel="noopener noreferrer">
                          <Twitter className="h-5 w-5 text-muted-foreground hover:text-primary" />
                        </a>
                      )}
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>แพ็คเกจปัจจุบัน</CardTitle>
                    <CardDescription>แพ็คเกจของคุณและวันหมดอายุ</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-semibold">{user?.packageType === "free" ? "ฟรี" : user?.packageType === "basic" ? "พื้นฐาน" : "โปร"}</div>
                        <div className="text-sm text-muted-foreground">
                          {user?.packageType === "free" 
                            ? "ไม่มีวันหมดอายุ" 
                            : "หมดอายุ: 31 ธ.ค. 2566"}
                        </div>
                      </div>
                      <Button variant="outline" className="text-xs" onClick={() => navigate("/dashboard/payments/upgrade")}>
                        อัปเกรด
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              {/* Right column - Forms */}
              <div className="flex-1">
                <Tabs value={activeTab} onValueChange={setActiveTab}>
                  <TabsList>
                    <TabsTrigger value="profile">ข้อมูลโปรไฟล์</TabsTrigger>
                    <TabsTrigger value="artists">จัดการศิลปิน</TabsTrigger>
                    <TabsTrigger value="package">อัปเกรดแพ็คเกจ</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="profile" className="mt-6">
                    <Card>
                      <CardHeader>
                        <CardTitle>ข้อมูลโปรไฟล์</CardTitle>
                        <CardDescription>
                          แก้ไขข้อมูลส่วนตัวและรายละเอียดผู้ใช้ของคุณ
                        </CardDescription>
                      </CardHeader>
                      <Form {...profileForm}>
                        <form onSubmit={profileForm.handleSubmit(onProfileSubmit)}>
                          <CardContent className="space-y-4">
                            <div className="flex flex-col md:flex-row gap-4">
                              <FormField
                                control={profileForm.control}
                                name="username"
                                render={({ field }) => (
                                  <FormItem className="flex-1">
                                    <FormLabel>ชื่อผู้ใช้ <span className="text-red-500">*</span></FormLabel>
                                    <FormControl>
                                      <Input placeholder="ชื่อผู้ใช้" {...field} />
                                    </FormControl>
                                    <FormDescription>
                                      ชื่อผู้ใช้สำหรับการเข้าสู่ระบบ
                                    </FormDescription>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              <FormField
                                control={profileForm.control}
                                name="artistName"
                                render={({ field }) => (
                                  <FormItem className="flex-1">
                                    <FormLabel>ชื่อศิลปิน <span className="text-red-500">*</span></FormLabel>
                                    <FormControl>
                                      <Input placeholder="ชื่อที่ใช้แสดง" {...field} />
                                    </FormControl>
                                    <FormDescription>
                                      ชื่อที่แสดงให้ผู้ฟังเห็น
                                    </FormDescription>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                            </div>
                            
                            <FormField
                              control={profileForm.control}
                              name="email"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>อีเมล <span className="text-red-500">*</span></FormLabel>
                                  <FormControl>
                                    <Input placeholder="อีเมล" {...field} />
                                  </FormControl>
                                  <FormDescription>
                                    อีเมลสำหรับติดต่อและรับข่าวสาร
                                  </FormDescription>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={profileForm.control}
                              name="bio"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>ประวัติศิลปิน</FormLabel>
                                  <FormControl>
                                    <Textarea placeholder="เกี่ยวกับตัวคุณหรือผลงาน..." className="resize-none min-h-[120px]" {...field} value={field.value || ""} />
                                  </FormControl>
                                  <FormDescription>
                                    ข้อมูลสั้นๆ เกี่ยวกับคุณและผลงานของคุณ
                                  </FormDescription>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <FormField
                                control={profileForm.control}
                                name="phone"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>เบอร์โทรศัพท์</FormLabel>
                                    <FormControl>
                                      <Input placeholder="เบอร์โทรศัพท์" {...field} value={field.value || ""} />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              
                              <FormField
                                control={profileForm.control}
                                name="location"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>สถานที่</FormLabel>
                                    <FormControl>
                                      <Input placeholder="เมือง, จังหวัด" {...field} value={field.value || ""} />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                            </div>
                            
                            <FormField
                              control={profileForm.control}
                              name="website"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>เว็บไซต์</FormLabel>
                                  <FormControl>
                                    <Input placeholder="https://yourwebsite.com" {...field} value={field.value || ""} />
                                  </FormControl>
                                  <FormDescription>
                                    เว็บไซต์หรือลิงก์สำหรับแฟนๆ ของคุณ
                                  </FormDescription>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <div className="space-y-4">
                              <h3 className="text-lg font-medium">โซเชียลมีเดีย</h3>
                              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <FormField
                                  control={profileForm.control}
                                  name="instagram"
                                  render={({ field }) => (
                                    <FormItem>
                                      <FormLabel>Instagram</FormLabel>
                                      <FormControl>
                                        <div className="relative">
                                          <Instagram className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                                          <Input className="pl-8" placeholder="username" {...field} value={field.value || ""} />
                                        </div>
                                      </FormControl>
                                      <FormMessage />
                                    </FormItem>
                                  )}
                                />
                                
                                <FormField
                                  control={profileForm.control}
                                  name="facebook"
                                  render={({ field }) => (
                                    <FormItem>
                                      <FormLabel>Facebook</FormLabel>
                                      <FormControl>
                                        <div className="relative">
                                          <Facebook className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                                          <Input className="pl-8" placeholder="username" {...field} value={field.value || ""} />
                                        </div>
                                      </FormControl>
                                      <FormMessage />
                                    </FormItem>
                                  )}
                                />
                                
                                <FormField
                                  control={profileForm.control}
                                  name="twitter"
                                  render={({ field }) => (
                                    <FormItem>
                                      <FormLabel>Twitter</FormLabel>
                                      <FormControl>
                                        <div className="relative">
                                          <Twitter className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                                          <Input className="pl-8" placeholder="username" {...field} value={field.value || ""} />
                                        </div>
                                      </FormControl>
                                      <FormMessage />
                                    </FormItem>
                                  )}
                                />
                              </div>
                            </div>
                          </CardContent>
                          <CardFooter className="border-t px-6 py-4">
                            <Button type="submit" disabled={updateProfileMutation.isPending} className="ml-auto">
                              {updateProfileMutation.isPending && (
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                              )}
                              บันทึกข้อมูล
                            </Button>
                          </CardFooter>
                        </form>
                      </Form>
                    </Card>
                  </TabsContent>
                  
                  {/* Artists Tab */}
                  <TabsContent value="artists" className="mt-6">
                    <Card>
                      <CardHeader className="flex flex-row items-center justify-between">
                        <div>
                          <CardTitle>จัดการศิลปิน</CardTitle>
                          <CardDescription>
                            เพิ่มและจัดการบัญชีศิลปินที่คุณดูแล
                          </CardDescription>
                        </div>
                        <Button onClick={() => {
                          setCurrentArtist(null);
                          artistForm.reset({
                            artistName: "",
                            fullName: "",
                            bio: "",
                            profilePicture: "",
                          });
                          setArtistDialogOpen(true);
                        }}>
                          <Plus className="mr-2 h-4 w-4" />
                          เพิ่มศิลปิน
                        </Button>
                      </CardHeader>
                      <CardContent>
                        {isLoadingArtists ? (
                          <div className="py-12 flex items-center justify-center">
                            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                          </div>
                        ) : (managedArtists as ManagedArtist[]).length === 0 ? (
                          <div className="py-12 flex flex-col items-center justify-center text-center">
                            <Music className="h-12 w-12 text-muted-foreground mb-4" />
                            <h3 className="text-lg font-medium mb-1">ยังไม่มีศิลปินที่คุณดูแล</h3>
                            <p className="text-sm text-muted-foreground mb-4 max-w-md">
                              คุณสามารถเพิ่มศิลปินที่คุณดูแล หรือสร้างตัวตนทางดนตรีหลายคนสำหรับผลงานต่างประเภทได้
                            </p>
                            <Button onClick={() => {
                              setCurrentArtist(null);
                              artistForm.reset({
                                artistName: "",
                                fullName: "",
                                bio: "",
                                profilePicture: "",
                              });
                              setArtistDialogOpen(true);
                            }}>
                              <Plus className="mr-2 h-4 w-4" />
                              เพิ่มศิลปินแรกของคุณ
                            </Button>
                          </div>
                        ) : (
                          <div className="divide-y">
                            {(managedArtists as ManagedArtist[]).map((artist) => (
                              <div key={artist.id} className="py-4 flex items-center gap-4">
                                <Avatar className="h-12 w-12">
                                  <AvatarImage src={artist.profilePicture || ""} alt={artist.artistName} />
                                  <AvatarFallback>
                                    {artist.artistName.charAt(0).toUpperCase()}
                                  </AvatarFallback>
                                </Avatar>
                                <div className="flex-1 min-w-0">
                                  <div className="flex items-center gap-2">
                                    <h3 className="font-medium">{artist.artistName}</h3>
                                    {artist.isPrimary && (
                                      <div className="bg-primary/10 text-primary rounded-full px-2 py-0.5 text-xs font-medium">
                                        หลัก
                                      </div>
                                    )}
                                  </div>
                                  <p className="text-sm text-muted-foreground truncate">{artist.fullName}</p>
                                </div>
                                <div className="flex gap-2">
                                  {!artist.isPrimary && (
                                    <Button 
                                      variant="outline" 
                                      size="icon"
                                      onClick={() => setPrimaryArtistMutation.mutate(artist.id)}
                                      disabled={setPrimaryArtistMutation.isPending}
                                    >
                                      <BadgePlus className="h-4 w-4" />
                                    </Button>
                                  )}
                                  <Button 
                                    variant="outline" 
                                    size="icon"
                                    onClick={() => {
                                      setCurrentArtist(artist);
                                      artistForm.reset({
                                        artistName: artist.artistName,
                                        fullName: artist.fullName,
                                        bio: artist.bio || "",
                                        profilePicture: artist.profilePicture || "",
                                        spotifyUrl: artist.spotifyUrl || "",
                                        appleMusicUrl: artist.appleMusicUrl || "",
                                      });
                                      setArtistDialogOpen(true);
                                    }}
                                  >
                                    <Edit className="h-4 w-4" />
                                  </Button>
                                  <Button 
                                    variant="outline" 
                                    size="icon"
                                    onClick={() => {
                                      setCurrentArtist(artist);
                                      setConfirmDeleteDialogOpen(true);
                                    }}
                                    disabled={artist.isPrimary || deleteArtistMutation.isPending}
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </TabsContent>

                  {/* Package Upgrade Tab */}
                  <TabsContent value="package" className="mt-6">
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <Package className="h-5 w-5" />
                          อัปเกรดแพ็คเกจ
                        </CardTitle>
                        <CardDescription>
                          เลือกแพ็คเกจที่เหมาะกับความต้องการของคุณ
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          {/* Free Package */}
                          <Card className={`border-2 ${user?.packageType === 'free' ? 'border-primary' : 'border-transparent'}`}>
                            <CardHeader>
                              <CardTitle className="flex items-center justify-between">
                                <span>ฟรี</span>
                                {user?.packageType === 'free' && <Check className="h-5 w-5 text-primary" />}
                              </CardTitle>
                              <CardDescription>
                                เริ่มต้นใช้งานฟรี
                              </CardDescription>
                            </CardHeader>
                            <CardContent>
                              <div className="text-3xl font-bold mb-4">฿0<span className="text-sm font-normal text-muted-foreground">/เดือน</span></div>
                              <ul className="space-y-2 mb-6">
                                <li className="flex items-center text-sm">
                                  <Check className="h-4 w-4 mr-2 text-primary" />
                                  <span>อัปโหลดได้ 2 เพลง/ปี</span>
                                </li>
                                <li className="flex items-center text-sm">
                                  <Check className="h-4 w-4 mr-2 text-primary" />
                                  <span>คุณภาพเพลง 128 kbps</span>
                                </li>
                                <li className="flex items-center text-sm">
                                  <Check className="h-4 w-4 mr-2 text-primary" />
                                  <span>กระจายเพลงใน 3 แพลตฟอร์มหลัก</span>
                                </li>
                                <li className="flex items-center text-sm">
                                  <Check className="h-4 w-4 mr-2 text-primary" />
                                  <span>ส่วนแบ่งรายได้ 80%</span>
                                </li>
                              </ul>
                              <Button 
                                className="w-full" 
                                variant={user?.packageType === 'free' ? 'outline' : 'default'}
                                disabled={user?.packageType === 'free' || upgradePackageMutation.isPending}
                                onClick={() => upgradePackageMutation.mutate('free')}
                              >
                                {user?.packageType === 'free' ? 'แพ็คเกจปัจจุบัน' : 'เลือกแพ็คเกจนี้'}
                              </Button>
                            </CardContent>
                          </Card>
                          
                          {/* Basic Package */}
                          <Card className={`border-2 ${user?.packageType === 'basic' ? 'border-primary' : 'border-transparent'}`}>
                            <CardHeader>
                              <CardTitle className="flex items-center justify-between">
                                <span>พื้นฐาน</span>
                                {user?.packageType === 'basic' && <Check className="h-5 w-5 text-primary" />}
                              </CardTitle>
                              <CardDescription>
                                สำหรับศิลปินที่เริ่มต้น
                              </CardDescription>
                            </CardHeader>
                            <CardContent>
                              <div className="text-3xl font-bold mb-4">฿299<span className="text-sm font-normal text-muted-foreground">/เดือน</span></div>
                              <ul className="space-y-2 mb-6">
                                <li className="flex items-center text-sm">
                                  <Check className="h-4 w-4 mr-2 text-primary" />
                                  <span>อัปโหลดได้ 50 เพลง/ปี</span>
                                </li>
                                <li className="flex items-center text-sm">
                                  <Check className="h-4 w-4 mr-2 text-primary" />
                                  <span>คุณภาพเพลง 192 kbps</span>
                                </li>
                                <li className="flex items-center text-sm">
                                  <Check className="h-4 w-4 mr-2 text-primary" />
                                  <span>กระจายเพลงใน 8 แพลตฟอร์มหลัก</span>
                                </li>
                                <li className="flex items-center text-sm">
                                  <Check className="h-4 w-4 mr-2 text-primary" />
                                  <span>ส่วนแบ่งรายได้ 90%</span>
                                </li>
                              </ul>
                              <Button 
                                className="w-full" 
                                variant={user?.packageType === 'basic' ? 'outline' : 'default'}
                                disabled={user?.packageType === 'basic' || upgradePackageMutation.isPending}
                                onClick={() => upgradePackageMutation.mutate('basic')}
                              >
                                {user?.packageType === 'basic' ? 'แพ็คเกจปัจจุบัน' : 'เลือกแพ็คเกจนี้'}
                              </Button>
                            </CardContent>
                          </Card>
                          
                          {/* Pro Package */}
                          <Card className={`border-2 ${user?.packageType === 'pro' ? 'border-primary' : 'border-transparent'}`}>
                            <CardHeader>
                              <div className="absolute -top-3 right-4 bg-primary text-primary-foreground text-xs px-3 py-1 rounded-full font-medium">
                                แนะนำ
                              </div>
                              <CardTitle className="flex items-center justify-between">
                                <span>โปร</span>
                                {user?.packageType === 'pro' && <Check className="h-5 w-5 text-primary" />}
                              </CardTitle>
                              <CardDescription>
                                สำหรับศิลปินมืออาชีพ
                              </CardDescription>
                            </CardHeader>
                            <CardContent>
                              <div className="text-3xl font-bold mb-4">฿599<span className="text-sm font-normal text-muted-foreground">/เดือน</span></div>
                              <ul className="space-y-2 mb-6">
                                <li className="flex items-center text-sm">
                                  <Check className="h-4 w-4 mr-2 text-primary" />
                                  <span>อัปโหลดได้ไม่จำกัด</span>
                                </li>
                                <li className="flex items-center text-sm">
                                  <Check className="h-4 w-4 mr-2 text-primary" />
                                  <span>คุณภาพเพลง 320 kbps</span>
                                </li>
                                <li className="flex items-center text-sm">
                                  <Check className="h-4 w-4 mr-2 text-primary" />
                                  <span>กระจายเพลงในทุกแพลตฟอร์ม</span>
                                </li>
                                <li className="flex items-center text-sm">
                                  <Check className="h-4 w-4 mr-2 text-primary" />
                                  <span>ส่วนแบ่งรายได้ 100%</span>
                                </li>
                                <li className="flex items-center text-sm">
                                  <Check className="h-4 w-4 mr-2 text-primary" />
                                  <span>แดชบอร์ดวิเคราะห์ขั้นสูง</span>
                                </li>
                                <li className="flex items-center text-sm">
                                  <Check className="h-4 w-4 mr-2 text-primary" />
                                  <span>จัดการศิลปินได้ไม่จำกัด</span>
                                </li>
                              </ul>
                              <Button 
                                className="w-full" 
                                variant={user?.packageType === 'pro' ? 'outline' : 'default'}
                                disabled={user?.packageType === 'pro' || upgradePackageMutation.isPending}
                                onClick={() => upgradePackageMutation.mutate('pro')}
                              >
                                {upgradePackageMutation.isPending ? (
                                  <div className="flex items-center gap-2">
                                    <Loader2 className="h-4 w-4 animate-spin" />
                                    <span>กำลังดำเนินการ...</span>
                                  </div>
                                ) : (
                                  user?.packageType === 'pro' ? 'แพ็คเกจปัจจุบัน' : 'เลือกแพ็คเกจนี้'
                                )}
                              </Button>
                            </CardContent>
                          </Card>
                        </div>
                        
                        <div className="mt-6 text-sm text-muted-foreground bg-muted p-4 rounded-lg">
                          <p>* การคิดค่าบริการจะเริ่มทันทีหลังจากเลือกแพ็คเกจ</p>
                          <p>* คุณสามารถยกเลิกได้ตลอดเวลา แต่จะไม่ได้รับเงินคืนสำหรับรอบการชำระเงินปัจจุบัน</p>
                          <p>* จำนวนเพลงเริ่มต้นใหม่ในวันครบรอบการสมัคร 1 ปี</p>
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>
                </Tabs>
              </div>
            </div>
          </div>
        </main>
      </div>
      
      {/* Artist Dialog */}
      <Dialog open={artistDialogOpen} onOpenChange={setArtistDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>{currentArtist ? 'แก้ไขศิลปิน' : 'เพิ่มศิลปิน'}</DialogTitle>
            <DialogDescription>
              {currentArtist ? 'แก้ไขข้อมูลศิลปินที่คุณดูแลอยู่' : 'เพิ่มบัญชีศิลปินใหม่ที่คุณดูแล'}
            </DialogDescription>
          </DialogHeader>
          <Form {...artistForm}>
            <form onSubmit={artistForm.handleSubmit(onArtistSubmit)} className="space-y-4">
              <FormField
                control={artistForm.control}
                name="artistName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>ชื่อศิลปิน <span className="text-red-500">*</span></FormLabel>
                    <FormControl>
                      <Input placeholder="ชื่อที่แสดงให้ผู้ฟังเห็น" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={artistForm.control}
                name="fullName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>ชื่อจริง <span className="text-red-500">*</span></FormLabel>
                    <FormControl>
                      <Input placeholder="ชื่อจริงของศิลปิน" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={artistForm.control}
                name="bio"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>ประวัติศิลปิน</FormLabel>
                    <FormControl>
                      <Textarea placeholder="เกี่ยวกับศิลปินหรือผลงาน..." className="resize-none min-h-[100px]" {...field} value={field.value || ""} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              {currentArtist && (
                <div className="py-2">
                  <FormLabel>รูปโปรไฟล์ศิลปิน</FormLabel>
                  <div className="flex items-center gap-4 mt-2">
                    <Avatar className="h-16 w-16">
                      <AvatarImage 
                        src={artistForm.watch('profilePicture') || ""} 
                        alt={artistForm.watch('artistName')} 
                      />
                      <AvatarFallback>
                        {artistForm.watch('artistName')?.charAt(0).toUpperCase() || "A"}
                      </AvatarFallback>
                    </Avatar>
                    <label 
                      htmlFor="artist-image-upload" 
                      className={`cursor-pointer ${uploadingArtistImage ? 'opacity-70 pointer-events-none' : ''}`}
                    >
                      <Button variant="outline" type="button" className="gap-2" disabled={uploadingArtistImage}>
                        {uploadingArtistImage ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <Camera className="h-4 w-4" />
                        )}
                        {uploadingArtistImage ? 'กำลังอัพโหลด...' : 'เปลี่ยนรูปภาพ'}
                      </Button>
                      <input 
                        id="artist-image-upload" 
                        type="file" 
                        accept="image/*" 
                        className="hidden" 
                        onChange={(e) => handleArtistImageUpload(e)}
                        disabled={uploadingArtistImage}
                      />
                    </label>
                  </div>
                </div>
              )
              
              }
              <FormField
                control={artistForm.control}
                name="spotifyUrl"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>ลิงก์ Spotify</FormLabel>
                    <FormControl>
                      <Input placeholder="https://open.spotify.com/artist/..." {...field} value={field.value || ""} />
                    </FormControl>
                    <FormDescription>
                      ลิงก์ของศิลปินบน Spotify
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={artistForm.control}
                name="appleMusicUrl"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>ลิงก์ Apple Music</FormLabel>
                    <FormControl>
                      <Input placeholder="https://music.apple.com/artist/..." {...field} value={field.value || ""} />
                    </FormControl>
                    <FormDescription>
                      ลิงก์ของศิลปินบน Apple Music
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="pt-4">
                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setArtistDialogOpen(false)}>ยกเลิก</Button>
                  <Button type="submit" disabled={createArtistMutation.isPending}>
                    {createArtistMutation.isPending && (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    )}
                    {currentArtist ? 'บันทึกการแก้ไข' : 'เพิ่มศิลปิน'}
                  </Button>
                </DialogFooter>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
      
      {/* Confirm Delete Dialog */}
      <Dialog open={confirmDeleteDialogOpen} onOpenChange={setConfirmDeleteDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>ยืนยันการลบศิลปิน</DialogTitle>
            <DialogDescription>
              คุณแน่ใจหรือไม่ที่จะลบ "{currentArtist?.artistName}"? การกระทำนี้ไม่สามารถย้อนกลับได้
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="mt-4">
            <Button type="button" variant="outline" onClick={() => setConfirmDeleteDialogOpen(false)}>ยกเลิก</Button>
            <Button 
              variant="destructive" 
              disabled={deleteArtistMutation.isPending}
              onClick={() => {
                if (currentArtist) {
                  deleteArtistMutation.mutate(currentArtist.id);
                  setConfirmDeleteDialogOpen(false);
                }
              }}
            >
              {deleteArtistMutation.isPending && (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              )}
              ลบศิลปิน
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}