import { useState, useRef, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useLocation } from "wouter";
import { uploadTrackSchema, type UploadTrackData } from "@shared/schema";
import { DashboardHeader } from "@/components/dashboard/DashboardHeader";
import { DashboardNav } from "@/components/dashboard/DashboardNav";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Switch } from "@/components/ui/switch";
import { Music, Upload, ArrowLeft, Globe, Search, Plus, X, Youtube, Package, Image as ImageIcon, Copyright, Building } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { StreamingPlatformLogo, type StreamingPlatform } from "@/components/streaming-platform-logos";

// List of genres for selection
const genres = [
  "pop",
  "rock",
  "hip-hop",
  "rap",
  "r-n-b",
  "country",
  "folk",
  "jazz",
  "blues",
  "electronic",
  "dance",
  "reggae",
  "classical",
  "metal",
  "alternative",
  "indie",
  "soul",
  "funk",
  "punk",
  "world",
  "latin",
  "k-pop",
  "j-pop",
  "t-pop",
];

// List of distribution platforms
const platforms = [
  { name: "Spotify", logo: "spotify" },
  { name: "Apple Music", logo: "appleMusic" },
  { name: "YouTube Music", logo: "youtubeMusic" },
  { name: "Joox", logo: "joox" },
  { name: "Tidal", logo: "tidal" },
  { name: "Amazon Music", logo: "amazonMusic" },
  { name: "Deezer", logo: "deezer" },
  { name: "Pandora", logo: "pandora" },
  { name: "SoundCloud", logo: "soundcloud" },
  { name: "iHeartRadio", logo: "iheartradio" },
];

export default function UploadTrack() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { user } = useAuth();
  const [audioFile, setAudioFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);

  // Create form with validation
  // ข้อมูลศิลปินที่ค้นหาจาก Spotify
  type SpotifyArtist = {
    id: string;
    name: string;
    images: { url: string }[];
    genres: string[];
    popularity: number;
  };

  // สำหรับการค้นหาศิลปิน
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<SpotifyArtist[]>([]);
  const [selectedArtists, setSelectedArtists] = useState<SpotifyArtist[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [searchDialogOpen, setSearchDialogOpen] = useState(false);
  const [mainArtist, setMainArtist] = useState<SpotifyArtist | null>(null);
  const [featuringArtists, setFeaturingArtists] = useState<SpotifyArtist[]>([]);
  const searchTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // สำหรับการเชื่อมต่อกับ YouTube
  const [youtubeAccountLinked, setYoutubeAccountLinked] = useState(false);
  const [youtubeChannelName, setYoutubeChannelName] = useState("");
  const [youtubeChannelUrl, setYoutubeChannelUrl] = useState("");
  const [showYoutubeDialog, setShowYoutubeDialog] = useState(false);
  
  // สำหรับการอัพโหลดภาพปกเพลง
  const [coverImage, setCoverImage] = useState<File | null>(null);
  const [coverImagePreview, setCoverImagePreview] = useState<string | null>(null);

  // ข้อมูลลิขสิทธิ์และค่ายเพลง
  const [copyrightHolder, setCopyrightHolder] = useState("");
  const [recordLabel, setRecordLabel] = useState("");
  const [publishYear, setPublishYear] = useState<number>(new Date().getFullYear());
  
  // ข้อมูลศิลปินที่ใส่เอง (สำหรับกรณีไม่พบใน Spotify)
  const [customMainArtist, setCustomMainArtist] = useState("");
  const [customFeaturingArtists, setCustomFeaturingArtists] = useState<string[]>([]);
  const [useCustomArtist, setUseCustomArtist] = useState(false);

  // แบบฟอร์มสำหรับการอัปโหลดเพลง
  const form = useForm<UploadTrackData>({
    resolver: zodResolver(uploadTrackSchema),
    defaultValues: {
      title: "",
      releaseDate: new Date().toISOString().split("T")[0],
      genre: "",
      lyrics: "",
      explicit: false,
      isrc: "",
      distributionPlatforms: []
    },
  });

  // Handle file selection
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files[0]) {
      const file = files[0];
      // Check file type
      if (!file.type.includes("audio/")) {
        toast({
          title: "รูปแบบไฟล์ไม่ถูกต้อง",
          description: "กรุณาเลือกไฟล์เสียงประเภท MP3, WAV, FLAC เท่านั้น",
          variant: "destructive",
        });
        return;
      }

      // Check file size
      if (file.size > 100 * 1024 * 1024) { // 100MB
        toast({
          title: "ไฟล์ขนาดใหญ่เกินไป",
          description: "ขนาดไฟล์ต้องไม่เกิน 100MB",
          variant: "destructive",
        });
        return;
      }

      setAudioFile(file);
    }
  };
  
  // Handle cover image upload
  const handleCoverImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files[0]) {
      const file = files[0];
      
      // Check file type
      if (!file.type.includes("image/")) {
        toast({
          title: "รูปแบบไฟล์ไม่ถูกต้อง",
          description: "กรุณาเลือกไฟล์ภาพประเภท JPG, PNG, หรือ WEBP เท่านั้น",
          variant: "destructive",
        });
        return;
      }
      
      // Check file size
      if (file.size > 5 * 1024 * 1024) { // 5MB
        toast({
          title: "ไฟล์ขนาดใหญ่เกินไป",
          description: "ขนาดไฟล์ภาพต้องไม่เกิน 5MB",
          variant: "destructive",
        });
        return;
      }
      
      // Create preview URL
      const previewUrl = URL.createObjectURL(file);
      setCoverImagePreview(previewUrl);
      setCoverImage(file);
    }
  };

  // Simulate upload progress
  const simulateUploadProgress = () => {
    setIsUploading(true);
    setUploadProgress(0);
    const interval = setInterval(() => {
      setUploadProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }
        return prev + 5;
      });
    }, 300);

    return () => clearInterval(interval);
  };

  // Submit track upload
  const uploadMutation = useMutation({
    mutationFn: async (data: UploadTrackData) => {
      // Simulate upload progress
      const cleanup = simulateUploadProgress();

      try {
        // Create FormData for file upload
        const formData = new FormData();
        
        // Add all form fields to FormData
        Object.entries(data).forEach(([key, value]) => {
          if (key !== "audioFile" && value !== undefined) {
            if (Array.isArray(value)) {
              // Handle arrays (like distributionPlatforms)
              value.forEach(item => formData.append(`distributionPlatforms`, String(item)));
            } else if (key === "explicit") {
              // Convert boolean to string
              formData.append(key, value ? "true" : "false");
            } else {
              formData.append(key, String(value));
            }
          }
        });
        
        // Add the file if it exists
        if (audioFile) {
          formData.append("audioFile", audioFile);
        }
        
        // Add cover image if it exists
        if (coverImage) {
          formData.append("coverImage", coverImage);
        }

        // Debugging: log FormData contents
        console.log("FormData entries:");
        for (const pair of (formData as any).entries()) {
          console.log(`${pair[0]}: ${pair[1]}`);
        }

        // Use fetch directly for FormData to avoid issues with apiRequest function
        const response = await fetch("/api/tracks", {
          method: "POST",
          body: formData,
          credentials: "include",
          // Don't set Content-Type, the browser will set it with the correct boundary
        });

        if (!response.ok) {
          const errorData = await response.json().catch(() => ({ message: response.statusText }));
          throw new Error(errorData.message || response.statusText);
        }

        const result = await response.json();
        
        // Cleanup the progress simulation
        cleanup();
        
        // Set upload as completed
        setUploadProgress(100);
        setIsUploading(false);
        
        return result;
      } catch (error) {
        // Cleanup the progress simulation
        cleanup();
        setIsUploading(false);
        throw error;
      }
    },
    onSuccess: (data) => {
      // Show success message
      toast({
        title: "อัปโหลดเรียบร้อย",
        description: data.message || "เพลงของคุณได้รับการอัปโหลดเรียบร้อยแล้ว",
      });
      
      // Invalidate track list cache to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/tracks'] });
      
      // Navigate to track details or back to dashboard
      setTimeout(() => {
        navigate("/dashboard");
      }, 1500);
    },
    onError: (error) => {
      toast({
        title: "เกิดข้อผิดพลาด",
        description: error instanceof Error ? error.message : "ไม่สามารถอัปโหลดเพลงได้ โปรดลองอีกครั้ง",
        variant: "destructive",
      });
    },
  });

  // ฟังก์ชันค้นหาศิลปินจาก Spotify API
  const handleSearchArtists = async () => {
    if (!searchQuery.trim()) return;
    
    setIsSearching(true);
    try {
      const response = await fetch(`/api/spotify/search/artists?query=${encodeURIComponent(searchQuery)}`);
      if (!response.ok) {
        throw new Error('ไม่สามารถค้นหาศิลปินได้');
      }
      
      const artists = await response.json();
      setSearchResults(artists);
    } catch (error) {
      console.error('Error searching artists:', error);
      toast({
        title: "เกิดข้อผิดพลาด",
        description: error instanceof Error ? error.message : "ไม่สามารถค้นหาศิลปินได้",
        variant: "destructive",
      });
    } finally {
      setIsSearching(false);
    }
  };

  // รับข้อมูลศิลปินจาก Spotify เมื่อพิมพ์
  useEffect(() => {
    if (searchTimeoutRef.current) {
      clearTimeout(searchTimeoutRef.current);
    }
    
    if (searchQuery.trim().length > 2) {
      searchTimeoutRef.current = setTimeout(() => {
        handleSearchArtists();
      }, 500);
    }
    
    return () => {
      if (searchTimeoutRef.current) {
        clearTimeout(searchTimeoutRef.current);
      }
    };
  }, [searchQuery]);

  // เลือกศิลปินหลัก
  const selectMainArtist = (artist: SpotifyArtist) => {
    setMainArtist(artist);
    setSearchDialogOpen(false);
  };

  // เพิ่มศิลปินฟีทเจอริ่ง
  const addFeaturingArtist = (artist: SpotifyArtist) => {
    // ตรวจสอบว่าไม่ใช่ศิลปินหลักหรือมีอยู่แล้ว
    if (mainArtist?.id === artist.id || featuringArtists.some(a => a.id === artist.id)) {
      return;
    }
    setFeaturingArtists([...featuringArtists, artist]);
    setSearchDialogOpen(false);
  };

  // ลบศิลปินฟีทเจอริ่ง
  const removeFeaturingArtist = (artistId: string) => {
    setFeaturingArtists(featuringArtists.filter(artist => artist.id !== artistId));
  };

  // เชื่อมบัญชี YouTube (จำลองการทำงาน)
  const handleLinkYouTubeAccount = () => {
    // ในเวอร์ชันการใช้งานจริง นี่จะต้องเป็นการเชื่อมต่อกับ YouTube API
    // เพื่อความเรียบง่าย เราจะจำลองการเชื่อมต่อโดยใช้ค่าที่กรอก
    
    const channelName = youtubeChannelName.trim();
    const channelUrl = youtubeChannelUrl.trim();
    
    if (!channelName || !channelUrl) {
      toast({
        title: "ข้อมูลไม่ครบถ้วน",
        description: "กรุณากรอกชื่อช่องและ URL ช่อง YouTube ของคุณ",
        variant: "destructive",
      });
      return;
    }
    
    // ตรวจสอบรูปแบบ URL อย่างง่าย
    if (!channelUrl.includes('youtube.com/') && !channelUrl.includes('youtu.be/')) {
      toast({
        title: "URL ไม่ถูกต้อง",
        description: "กรุณากรอก URL ช่อง YouTube ที่ถูกต้อง",
        variant: "destructive",
      });
      return;
    }
    
    // จำลองการเชื่อมต่อ YouTube API
    setYoutubeAccountLinked(true);
    setShowYoutubeDialog(false);
    
    toast({
      title: "เชื่อมต่อบัญชีสำเร็จ",
      description: `เชื่อมต่อกับช่อง ${channelName} เรียบร้อยแล้ว`,
    });
  };

  // Handle form submission
  const onSubmit = (data: UploadTrackData) => {
    if (!audioFile) {
      toast({
        title: "ไฟล์เพลงไม่ถูกต้อง",
        description: "กรุณาเลือกไฟล์เพลงที่ต้องการอัปโหลด",
        variant: "destructive",
      });
      return;
    }

    if (!coverImage) {
      toast({
        title: "ภาพปกเพลงไม่ถูกต้อง",
        description: "กรุณาเลือกภาพปกเพลงสำหรับการอัปโหลด",
        variant: "destructive",
      });
      return;
    }

    // เพิ่มข้อมูลศิลปิน ไฟล์ และรายละเอียดอื่นๆ ในการส่งข้อมูล
    const submitData = {
      ...data,
      audioFile: audioFile.name,
      coverImage: coverImage.name,
      // ข้อมูลศิลปินจาก Spotify หรือที่ผู้ใช้กรอกเอง
      mainArtistId: useCustomArtist ? null : (mainArtist?.id || null),
      customMainArtist: useCustomArtist ? customMainArtist : null,
      featuringArtistIds: useCustomArtist ? [] : featuringArtists.map(artist => artist.id),
      customFeaturingArtists: useCustomArtist ? customFeaturingArtists : [],
      // ข้อมูล YouTube
      youtubeChannelName: youtubeAccountLinked ? youtubeChannelName : null,
      youtubeChannelUrl: youtubeAccountLinked ? youtubeChannelUrl : null,
      // ข้อมูลลิขสิทธิ์
      copyrightHolder: copyrightHolder || (user?.artistName || user?.username || ""),
      recordLabel: recordLabel || "อิสระ",
      publishYear: publishYear || new Date().getFullYear(),
    };

    // Submit the form
    uploadMutation.mutate(submitData);
  };

  // Get package restrictions based on user's package type
  const getPackageRestrictions = () => {
    const packageType = user?.packageType || 'free';
    
    switch (packageType) {
      case 'pro':
        return {
          trackLimit: 'ไม่จำกัด',
          platforms: 'ทุกแพลตฟอร์ม',
          audioQuality: 'คุณภาพสูงสุด (320kbps)',
          isrc: true,
          customRelease: true,
        };
      case 'basic':
        return {
          trackLimit: '50 เพลงต่อปี',
          platforms: 'แพลตฟอร์มหลัก',
          audioQuality: 'คุณภาพสูง (192kbps)',
          isrc: true,
          customRelease: true,
        };
      case 'free':
      default:
        return {
          trackLimit: '2 เพลงต่อปี',
          platforms: 'แพลตฟอร์มจำกัด',
          audioQuality: 'คุณภาพมาตรฐาน (128kbps)',
          isrc: false,
          customRelease: false,
        };
    }
  };

  const packageRestrictions = getPackageRestrictions();

  return (
    <div className="flex min-h-screen bg-background">
      {/* Sidebar */}
      <DashboardNav />

      {/* Main content */}
      <div className="flex-1 overflow-hidden">
        <DashboardHeader user={user || undefined} />

        <main className="flex-1 overflow-y-auto p-6">
          <div className="mx-auto max-w-3xl space-y-6">
            <div className="flex items-center">
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => navigate("/dashboard")}
                className="mr-2"
              >
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold tracking-tight">อัพโหลดเพลงใหม่</h1>
                <p className="text-sm text-muted-foreground">
                  กรุณากรอกข้อมูลเพลงให้ครบถ้วนเพื่อเผยแพร่ไปยังแพลตฟอร์มต่าง ๆ
                </p>
              </div>
            </div>

            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Music className="h-5 w-5" />
                      ข้อมูลเพลง
                    </CardTitle>
                    <CardDescription>
                      กรอกข้อมูลพื้นฐานของเพลงที่ต้องการอัพโหลด
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Title */}
                    <FormField
                      control={form.control}
                      name="title"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>ชื่อเพลง</FormLabel>
                          <FormControl>
                            <Input placeholder="กรอกชื่อเพลง" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Release Date */}
                    <FormField
                      control={form.control}
                      name="releaseDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>วันที่เผยแพร่</FormLabel>
                          <FormControl>
                            <Input 
                              type="date" 
                              {...field}
                              disabled={!packageRestrictions.customRelease}
                            />
                          </FormControl>
                          {!packageRestrictions.customRelease && (
                            <FormDescription>
                              อัพเกรดเป็นแพคเกจ Basic หรือ Pro เพื่อกำหนดวันที่เผยแพร่
                            </FormDescription>
                          )}
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Genre */}
                    <FormField
                      control={form.control}
                      name="genre"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>แนวเพลง</FormLabel>
                          <Select 
                            onValueChange={field.onChange} 
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="เลือกแนวเพลง" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {genres.map((genre) => (
                                <SelectItem key={genre} value={genre}>
                                  {genre}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Explicit */}
                    <FormField
                      control={form.control}
                      name="explicit"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                          <div className="space-y-0.5">
                            <FormLabel className="text-base">
                              เนื้อหาสำหรับผู้ใหญ่
                            </FormLabel>
                            <FormDescription>
                              เพลงนี้มีเนื้อหาไม่เหมาะสมสำหรับเด็กและเยาวชน
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />

                    {/* ISRC */}
                    <FormField
                      control={form.control}
                      name="isrc"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>ISRC (ถ้ามี)</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="เช่น THUM72000001" 
                              {...field}
                              disabled={!packageRestrictions.isrc}
                            />
                          </FormControl>
                          <FormDescription>
                            รหัสสากลสำหรับระบุเพลงของคุณ {!packageRestrictions.isrc && "อัพเกรดเป็นแพคเกจ Basic หรือ Pro เพื่อเพิ่ม ISRC"}
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Lyrics */}
                    <FormField
                      control={form.control}
                      name="lyrics"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>เนื้อเพลง</FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="กรอกเนื้อเพลงที่นี่"
                              className="min-h-32"
                              {...field}
                            />
                          </FormControl>
                          <FormDescription>
                            เนื้อเพลงจะถูกแสดงบนแพลตฟอร์มที่รองรับ
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Upload className="h-5 w-5" />
                      ไฟล์เพลง
                    </CardTitle>
                    <CardDescription>
                      อัปโหลดไฟล์เพลงของคุณ รองรับไฟล์รูปแบบ MP3, WAV, FLAC
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div 
                        className="rounded-lg border border-dashed p-10 text-center"
                        onDragOver={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          e.currentTarget.classList.add('border-primary');
                        }}
                        onDragLeave={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          e.currentTarget.classList.remove('border-primary');
                        }}
                        onDrop={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          e.currentTarget.classList.remove('border-primary');
                          
                          if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
                            const file = e.dataTransfer.files[0];
                            if (!file.type.includes("audio/")) {
                              toast({
                                title: "รูปแบบไฟล์ไม่ถูกต้อง",
                                description: "กรุณาเลือกไฟล์เสียงประเภท MP3, WAV, FLAC เท่านั้น",
                                variant: "destructive",
                              });
                              return;
                            }
                            
                            if (file.size > 100 * 1024 * 1024) { // 100MB
                              toast({
                                title: "ไฟล์ขนาดใหญ่เกินไป",
                                description: "ขนาดไฟล์ต้องไม่เกิน 100MB",
                                variant: "destructive",
                              });
                              return;
                            }
                            
                            setAudioFile(file);
                          }
                        }}
                      >
                        {audioFile ? (
                          <div className="space-y-2">
                            <Music className="mx-auto h-8 w-8 text-muted-foreground" />
                            <div className="text-sm font-medium">{audioFile.name}</div>
                            <div className="text-xs text-muted-foreground">
                              {(audioFile.size / (1024 * 1024)).toFixed(2)} MB
                            </div>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => setAudioFile(null)}
                            >
                              เปลี่ยนไฟล์
                            </Button>
                          </div>
                        ) : (
                          <>
                            <Music className="mx-auto h-8 w-8 text-muted-foreground" />
                            <div className="mt-2 text-sm font-medium">
                              ลากไฟล์เพลงมาวางที่นี่หรือ
                            </div>
                            <Input
                              id="audio-file"
                              type="file"
                              accept="audio/*"
                              className="hidden"
                              onChange={handleFileChange}
                            />
                            <Button
                              variant="outline"
                              size="sm"
                              className="mt-2"
                              onClick={() => document.getElementById("audio-file")?.click()}
                            >
                              เลือกไฟล์
                            </Button>
                            <div className="mt-2 text-xs text-muted-foreground">
                              รองรับไฟล์ MP3, WAV, FLAC ขนาดไม่เกิน 100MB
                            </div>
                          </>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <ImageIcon className="h-5 w-5" />
                      ภาพปกเพลง
                    </CardTitle>
                    <CardDescription>
                      อัปโหลดภาพปกเพลงของคุณ รองรับไฟล์รูปแบบ JPG, PNG, WEBP
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div 
                        className="rounded-lg border border-dashed p-10 text-center"
                        onDragOver={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          e.currentTarget.classList.add('border-primary');
                        }}
                        onDragLeave={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          e.currentTarget.classList.remove('border-primary');
                        }}
                        onDrop={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          e.currentTarget.classList.remove('border-primary');
                          
                          if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
                            const file = e.dataTransfer.files[0];
                            if (!file.type.includes("image/")) {
                              toast({
                                title: "รูปแบบไฟล์ไม่ถูกต้อง",
                                description: "กรุณาเลือกไฟล์ภาพประเภท JPG, PNG, WEBP เท่านั้น",
                                variant: "destructive",
                              });
                              return;
                            }
                            handleCoverImageChange({ target: { files: e.dataTransfer.files } } as any);
                          }
                        }}
                      >
                        {coverImagePreview ? (
                          <div className="flex flex-col items-center">
                            <img 
                              src={coverImagePreview} 
                              alt="Cover preview" 
                              className="mb-2 h-40 w-40 object-cover rounded-md" 
                            />
                            <Button 
                              type="button" 
                              variant="outline" 
                              onClick={() => {
                                setCoverImage(null);
                                setCoverImagePreview(null);
                              }}
                            >
                              เปลี่ยนภาพ
                            </Button>
                          </div>
                        ) : (
                          <>
                            <ImageIcon className="mx-auto h-8 w-8 text-muted-foreground" />
                            <div className="mt-2 text-sm font-medium">
                              ลากไฟล์ภาพมาวางที่นี่หรือ
                            </div>
                            <Input
                              id="cover-image"
                              type="file"
                              accept="image/*"
                              className="hidden"
                              onChange={handleCoverImageChange}
                            />
                            <Button
                              type="button"
                              variant="outline"
                              className="mt-2"
                              onClick={() => {
                                document.getElementById('cover-image')?.click();
                              }}
                            >
                              เลือกไฟล์ภาพ
                            </Button>
                          </>
                        )}
                      </div>
                      <FormDescription>
                        ภาพปกเพลงควรมีขนาด 3000 x 3000 พิกเซล หรืออัตราส่วน 1:1 (สี่เหลี่ยมจัตุรัส)
                      </FormDescription>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Globe className="h-5 w-5" />
                      การเผยแพร่
                    </CardTitle>
                    <CardDescription>
                      เลือกแพลตฟอร์มที่ต้องการเผยแพร่เพลงของคุณ
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <FormField
                        control={form.control}
                        name="distributionPlatforms"
                        render={({ field }) => (
                          <FormItem>
                            <div className="grid grid-cols-2 gap-2 md:grid-cols-3 lg:grid-cols-5">
                              {platforms.map((platform) => {
                                const isSelected = field.value?.includes(platform.name);
                                return (
                                  <div
                                    key={platform.name}
                                    className={`flex cursor-pointer flex-col items-center justify-center rounded-lg border p-3 text-center transition-colors ${
                                      isSelected ? "border-primary bg-primary/5" : "hover:bg-muted"
                                    }`}
                                    onClick={() => {
                                      // Toggle selection
                                      if (isSelected) {
                                        field.onChange(field.value?.filter(p => p !== platform.name));
                                      } else {
                                        field.onChange([...(field.value || []), platform.name]);
                                      }
                                    }}
                                  >
                                    <div className="h-8 flex items-center justify-center">
                                      <StreamingPlatformLogo 
                                        platform={platform.logo as StreamingPlatform}
                                        size={28}
                                      />
                                    </div>
                                    <div className="text-xs font-medium">{platform.name}</div>
                                  </div>
                                );
                              })}
                            </div>
                            {field.value?.length === 0 && (
                              <FormMessage>
                                กรุณาเลือกอย่างน้อย 1 แพลตฟอร์ม
                              </FormMessage>
                            )}
                          </FormItem>
                        )}
                      />
                    </div>
                  </CardContent>
                </Card>

                {/* Dialog สำหรับค้นหาศิลปิน */}
                <Dialog open={searchDialogOpen} onOpenChange={setSearchDialogOpen}>
                  <DialogContent className="sm:max-w-[500px]">
                    <DialogHeader>
                      <DialogTitle>ค้นหาศิลปินจาก Spotify</DialogTitle>
                      <DialogDescription>
                        ค้นหาศิลปินเพื่อเพิ่มเป็นศิลปินหลักหรือศิลปินร่วม
                      </DialogDescription>
                    </DialogHeader>
                    
                    <div className="space-y-4">
                      <div className="flex gap-2">
                        <Input
                          placeholder="พิมพ์ชื่อศิลปินเพื่อค้นหา"
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          className="flex-1"
                        />
                        <Button 
                          variant="outline" 
                          onClick={handleSearchArtists}
                          disabled={isSearching || searchQuery.trim().length < 2}
                        >
                          {isSearching ? '...' : 'ค้นหา'}
                        </Button>
                      </div>
                      
                      {isSearching ? (
                        <div className="py-8 text-center">
                          <div className="animate-spin w-6 h-6 border-2 border-primary border-t-transparent rounded-full mx-auto"></div>
                          <p className="mt-2 text-sm text-muted-foreground">กำลังค้นหา...</p>
                        </div>
                      ) : searchResults.length > 0 ? (
                        <div className="max-h-[300px] overflow-y-auto space-y-2">
                          {searchResults.map((artist) => {
                            const isMainArtist = mainArtist?.id === artist.id;
                            const isFeaturing = featuringArtists.some(a => a.id === artist.id);
                            
                            return (
                              <div 
                                key={artist.id} 
                                className={`flex items-center justify-between p-2 rounded-md ${isMainArtist || isFeaturing ? 'bg-primary/10' : 'hover:bg-muted'}`}
                              >
                                <div className="flex items-center gap-3">
                                  <Avatar className="h-10 w-10">
                                    <AvatarImage src={artist.images[0]?.url} alt={artist.name} />
                                    <AvatarFallback>{artist.name.substring(0, 2)}</AvatarFallback>
                                  </Avatar>
                                  <div>
                                    <div className="font-medium">{artist.name}</div>
                                    <div className="text-xs text-muted-foreground">
                                      {artist.genres?.slice(0, 2).join(', ') || 'ไม่ระบุแนว'}
                                    </div>
                                  </div>
                                </div>
                                <div className="flex gap-1">
                                  {isMainArtist ? (
                                    <Badge>ศิลปินหลัก</Badge>
                                  ) : isFeaturing ? (
                                    <Badge variant="outline">ฟีทเจอริ่ง</Badge>
                                  ) : (
                                    <>
                                      <Button 
                                        size="sm" 
                                        variant="outline"
                                        onClick={() => selectMainArtist(artist)}
                                        disabled={!!mainArtist}
                                      >
                                        เลือกเป็นศิลปินหลัก
                                      </Button>
                                      <Button 
                                        size="sm" 
                                        variant="ghost"
                                        onClick={() => addFeaturingArtist(artist)}
                                      >
                                        + ฟีท
                                      </Button>
                                    </>
                                  )}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      ) : searchQuery.trim().length > 0 ? (
                        <div className="py-6 text-center space-y-4">
                          <p className="text-muted-foreground">ไม่พบศิลปินที่ตรงกับคำค้นหา</p>
                          
                          <div className="p-4 border rounded-md">
                            <h4 className="font-medium mb-2">เพิ่มศิลปินเอง</h4>
                            <p className="text-sm text-muted-foreground mb-3">
                              หากไม่พบศิลปินในระบบ คุณสามารถเพิ่มข้อมูลด้วยตัวเองได้
                            </p>
                            
                            <div className="space-y-3">
                              <div className="space-y-1">
                                <Label htmlFor="custom-artist-name">ชื่อศิลปินหลัก</Label>
                                <Input 
                                  id="custom-artist-name" 
                                  placeholder="ระบุชื่อศิลปินหลัก" 
                                  value={customMainArtist}
                                  onChange={(e) => setCustomMainArtist(e.target.value)}
                                />
                              </div>
                              
                              <Button 
                                type="button" 
                                variant="outline" 
                                size="sm" 
                                className="w-full"
                                onClick={() => {
                                  if (customMainArtist.trim()) {
                                    setUseCustomArtist(true);
                                    setSearchDialogOpen(false);
                                    toast({
                                      title: "เพิ่มศิลปินเรียบร้อย",
                                      description: `เพิ่ม ${customMainArtist} เป็นศิลปินหลักเรียบร้อยแล้ว`,
                                    });
                                  } else {
                                    toast({
                                      title: "กรุณาระบุชื่อศิลปิน",
                                      description: "โปรดกรอกชื่อศิลปินหลักก่อนดำเนินการต่อ",
                                      variant: "destructive",
                                    });
                                  }
                                }}
                              >
                                เพิ่มเป็นศิลปินหลัก
                              </Button>
                            </div>
                          </div>
                        </div>
                      ) : null}
                    </div>
                    
                    <DialogFooter className="flex justify-end gap-2">
                      <Button variant="ghost" onClick={() => setSearchDialogOpen(false)}>
                        ปิด
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
                
                {/* Dialog สำหรับเชื่อมบัญชี YouTube */}
                <Dialog open={showYoutubeDialog} onOpenChange={setShowYoutubeDialog}>
                  <DialogContent className="sm:max-w-[500px]">
                    <DialogHeader>
                      <DialogTitle>เชื่อมต่อบัญชี YouTube</DialogTitle>
                      <DialogDescription>
                        เชื่อมต่อช่อง YouTube ของคุณเพื่อจัดการลิขสิทธิ์เพลงได้อย่างง่ายดาย
                      </DialogDescription>
                    </DialogHeader>
                    
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="channelName">ชื่อช่อง YouTube</Label>
                        <Input
                          id="channelName"
                          placeholder="ชื่อช่อง YouTube ของคุณ"
                          value={youtubeChannelName}
                          onChange={(e) => setYoutubeChannelName(e.target.value)}
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="channelUrl">URL ช่อง YouTube</Label>
                        <Input
                          id="channelUrl"
                          placeholder="https://youtube.com/c/your-channel"
                          value={youtubeChannelUrl}
                          onChange={(e) => setYoutubeChannelUrl(e.target.value)}
                        />
                      </div>
                    </div>
                    
                    <DialogFooter className="flex justify-end gap-2">
                      <Button variant="ghost" onClick={() => setShowYoutubeDialog(false)}>
                        ยกเลิก
                      </Button>
                      <Button onClick={handleLinkYouTubeAccount}>
                        เชื่อมต่อบัญชี
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
                
                {/* คอมโพเนนต์ศิลปิน */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Music className="h-5 w-5" />
                      ข้อมูลศิลปิน
                    </CardTitle>
                    <CardDescription>
                      ค้นหาและเลือกศิลปินจาก Spotify
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <div className="mb-4">
                        <h3 className="text-sm font-medium mb-2">ศิลปินหลัก</h3>
                        {useCustomArtist ? (
                          <div className="flex items-center gap-3 rounded-lg border p-3">
                            <Avatar className="h-10 w-10">
                              <AvatarFallback>{customMainArtist.substring(0, 2).toUpperCase()}</AvatarFallback>
                            </Avatar>
                            <div className="flex-1">
                              <div className="font-medium">{customMainArtist}</div>
                              <div className="text-xs text-muted-foreground">
                                <Badge variant="outline" className="mr-1">ศิลปินอิสระ</Badge>
                              </div>
                            </div>
                            <Button 
                              variant="ghost" 
                              size="icon"
                              onClick={() => {
                                setUseCustomArtist(false);
                                setCustomMainArtist("");
                              }}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        ) : mainArtist ? (
                          <div className="flex items-center gap-3 rounded-lg border p-3">
                            <Avatar className="h-10 w-10">
                              <AvatarImage src={mainArtist.images[0]?.url} alt={mainArtist.name} />
                              <AvatarFallback>{mainArtist.name.substring(0, 2)}</AvatarFallback>
                            </Avatar>
                            <div className="flex-1">
                              <div className="font-medium">{mainArtist.name}</div>
                              <div className="text-xs text-muted-foreground">
                                {mainArtist.genres.slice(0, 3).join(', ')}
                              </div>
                            </div>
                            <Button 
                              variant="ghost" 
                              size="icon"
                              onClick={() => setMainArtist(null)}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        ) : (
                          <div className="flex flex-col space-y-2">
                            <Button 
                              variant="outline" 
                              onClick={() => {
                                setSearchDialogOpen(true);
                                setSelectedArtists([]);
                              }}
                              className="w-full"
                            >
                              <Search className="mr-2 h-4 w-4" />
                              ค้นหาศิลปินหลักจาก Spotify
                            </Button>
                            
                            <div className="relative">
                              <div className="absolute inset-0 flex items-center">
                                <span className="w-full border-t" />
                              </div>
                              <div className="relative flex justify-center text-xs uppercase">
                                <span className="bg-background px-2 text-muted-foreground">
                                  หรือ
                                </span>
                              </div>
                            </div>
                            
                            <div className="flex gap-2">
                              <Input
                                placeholder="ระบุชื่อศิลปิน"
                                value={customMainArtist}
                                onChange={(e) => setCustomMainArtist(e.target.value)}
                                className="flex-1"
                              />
                              <Button
                                variant="outline"
                                onClick={() => {
                                  if (customMainArtist.trim()) {
                                    setUseCustomArtist(true);
                                    toast({
                                      title: "เพิ่มศิลปินเรียบร้อย",
                                      description: `เพิ่ม ${customMainArtist} เป็นศิลปินหลักเรียบร้อยแล้ว`,
                                    });
                                  } else {
                                    toast({
                                      title: "กรุณาระบุชื่อศิลปิน",
                                      description: "โปรดกรอกชื่อศิลปินหลักก่อนดำเนินการต่อ",
                                      variant: "destructive",
                                    });
                                  }
                                }}
                              >
                                ยืนยัน
                              </Button>
                            </div>
                          </div>
                        )}
                      </div>

                      <div>
                        <h3 className="text-sm font-medium mb-2">ฟีทเจอริ่ง (ถ้ามี)</h3>
                        
                        {/* แสดงศิลปินฟีทเจอริ่งจาก Spotify */}
                        {!useCustomArtist && featuringArtists.length > 0 && (
                          <div className="mb-3 flex flex-wrap gap-2">
                            {featuringArtists.map(artist => (
                              <Badge 
                                key={artist.id} 
                                className="flex items-center gap-1 pl-1"
                                variant="secondary"
                              >
                                <Avatar className="h-5 w-5">
                                  <AvatarImage src={artist.images[0]?.url} alt={artist.name} />
                                  <AvatarFallback>{artist.name.substring(0, 2)}</AvatarFallback>
                                </Avatar>
                                <span>{artist.name}</span>
                                <Button 
                                  variant="ghost" 
                                  size="icon" 
                                  className="h-5 w-5 ml-1"
                                  onClick={() => removeFeaturingArtist(artist.id)}
                                >
                                  <X className="h-3 w-3" />
                                </Button>
                              </Badge>
                            ))}
                          </div>
                        )}
                        
                        {/* แสดงศิลปินฟีทเจอริ่งที่ใส่เอง */}
                        {useCustomArtist && customFeaturingArtists.length > 0 && (
                          <div className="mb-3 flex flex-wrap gap-2">
                            {customFeaturingArtists.map((artist, index) => (
                              <Badge 
                                key={index} 
                                className="flex items-center gap-1 pl-1"
                                variant="secondary"
                              >
                                <Avatar className="h-5 w-5">
                                  <AvatarFallback>{artist.substring(0, 2).toUpperCase()}</AvatarFallback>
                                </Avatar>
                                <span>{artist}</span>
                                <Button 
                                  variant="ghost" 
                                  size="icon" 
                                  className="h-5 w-5 ml-1"
                                  onClick={() => {
                                    const newArtists = [...customFeaturingArtists];
                                    newArtists.splice(index, 1);
                                    setCustomFeaturingArtists(newArtists);
                                  }}
                                >
                                  <X className="h-3 w-3" />
                                </Button>
                              </Badge>
                            ))}
                          </div>
                        )}
                        
                        {/* ตัวเลือกเพิ่มศิลปิน */}
                        {useCustomArtist ? (
                          <div className="flex gap-2">
                            <Input
                              placeholder="ชื่อศิลปินฟีทเจอริ่ง"
                              value={customMainArtist}
                              onChange={(e) => setCustomMainArtist(e.target.value)}
                              className="flex-1"
                            />
                            <Button
                              variant="outline"
                              onClick={() => {
                                if (customMainArtist.trim()) {
                                  setCustomFeaturingArtists([...customFeaturingArtists, customMainArtist.trim()]);
                                  setCustomMainArtist("");
                                  toast({
                                    title: "เพิ่มศิลปินเรียบร้อย",
                                    description: `เพิ่ม ${customMainArtist} เป็นศิลปินฟีทเจอริ่งเรียบร้อยแล้ว`,
                                  });
                                }
                              }}
                            >
                              <Plus className="h-4 w-4" />
                            </Button>
                          </div>
                        ) : (
                          <Button 
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setSearchDialogOpen(true);
                              setSelectedArtists(featuringArtists);
                            }}
                            className="w-full"
                          >
                            <Plus className="mr-2 h-3 w-3" />
                            เพิ่มศิลปินฟีทเจอริ่ง
                          </Button>
                        )}
                      </div>
                    </div>

                    {/* YouTube Channel */}
                    <div className="pt-4 border-t mt-6">
                      <h3 className="text-sm font-medium mb-3">เชื่อมต่อบัญชี YouTube</h3>
                      {youtubeAccountLinked ? (
                        <div className="flex items-center gap-3 rounded-lg border p-3">
                          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-red-600">
                            <Youtube className="h-5 w-5 text-white" />
                          </div>
                          <div className="flex-1">
                            <div className="font-medium">{youtubeChannelName}</div>
                            <div className="text-xs text-muted-foreground truncate">
                              {youtubeChannelUrl}
                            </div>
                          </div>
                          <Button 
                            variant="ghost" 
                            size="icon"
                            onClick={() => setYoutubeAccountLinked(false)}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      ) : (
                        <div className="rounded-lg border border-dashed p-4 text-center">
                          <Youtube className="mx-auto h-8 w-8 text-muted-foreground mb-2" />
                          <p className="text-sm text-muted-foreground mb-3">
                            เชื่อมต่อกับบัญชี YouTube ของคุณเพื่อตรวจสอบลิขสิทธิ์โดยอัตโนมัติ
                          </p>
                          <Button 
                            variant="outline"
                            onClick={() => setShowYoutubeDialog(true)}
                          >
                            เชื่อมต่อบัญชี YouTube
                          </Button>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
                
                {/* ข้อมูลลิขสิทธิ์และค่ายเพลง */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Copyright className="h-5 w-5" />
                      ข้อมูลลิขสิทธิ์
                    </CardTitle>
                    <CardDescription>
                      กรอกข้อมูลผู้ถือลิขสิทธิ์และค่ายเพลง
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* ผู้ถือลิขสิทธิ์ */}
                    <div className="space-y-2">
                      <Label htmlFor="copyright-holder">ผู้ถือลิขสิทธิ์</Label>
                      <Input 
                        id="copyright-holder" 
                        placeholder="ชื่อผู้ถือลิขสิทธิ์" 
                        value={copyrightHolder}
                        onChange={(e) => setCopyrightHolder(e.target.value)}
                        defaultValue={user?.artistName || user?.username}
                      />
                      <p className="text-xs text-muted-foreground">
                        ผู้ถือลิขสิทธิ์คือบุคคลหรือนิติบุคคลที่เป็นเจ้าของลิขสิทธิ์เพลงนี้
                      </p>
                    </div>

                    {/* ค่ายเพลง */}
                    <div className="space-y-2">
                      <Label htmlFor="record-label">ค่ายเพลง</Label>
                      <Input 
                        id="record-label" 
                        placeholder="ชื่อค่ายเพลง" 
                        value={recordLabel}
                        onChange={(e) => setRecordLabel(e.target.value)}
                      />
                      <p className="text-xs text-muted-foreground">
                        ค่ายเพลงที่เป็นผู้ผลิตหรือจัดจำหน่ายเพลงนี้ (หากไม่มีให้ระบุว่า "อิสระ")
                      </p>
                    </div>

                    {/* ข้อมูลการเผยแพร่ */}
                    <div className="space-y-2 pt-2">
                      <div className="flex flex-col space-y-1.5">
                        <Label htmlFor="publish-year">ปีที่เผยแพร่</Label>
                        <Input 
                          id="publish-year" 
                          placeholder={new Date().getFullYear().toString()}
                          type="number"
                          value={publishYear}
                          onChange={(e) => setPublishYear(parseInt(e.target.value))}
                        />
                      </div>
                    </div>
                    
                    {/* ข้อความลิขสิทธิ์ */}
                    <div className="pt-2 border-t mt-2">
                      <Label className="mb-2 block">ข้อความลิขสิทธิ์</Label>
                      <div className="text-sm p-3 rounded-md bg-secondary">
                        ℗ {publishYear || new Date().getFullYear()} {recordLabel || 'อิสระ'}<br />
                        © {publishYear || new Date().getFullYear()} {copyrightHolder || (user?.artistName || user?.username || '')}
                      </div>
                      <p className="text-xs text-muted-foreground mt-2">
                        ข้อความลิขสิทธิ์นี้จะปรากฏในแพลตฟอร์มสตรีมมิงต่างๆ
                      </p>
                    </div>
                  </CardContent>
                </Card>

                {/* Submit button */}
                <div className="flex items-center gap-4">
                  <Button 
                    type="button" 
                    variant="outline"
                    onClick={() => navigate("/dashboard")}
                  >
                    ยกเลิก
                  </Button>
                  <Button 
                    type="submit" 
                    disabled={isUploading || uploadMutation.isPending}
                    className="flex-1"
                  >
                    {isUploading ? (
                      <div className="flex items-center gap-2">
                        <div className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent"></div>
                        <span>กำลังอัปโหลด... {uploadProgress}%</span>
                      </div>
                    ) : (
                      "อัปโหลดเพลง"
                    )}
                  </Button>
                </div>
              </form>
            </Form>
          </div>
        </main>
      </div>
    </div>
  );
}