import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Music, Plus, Search } from "lucide-react";
import { DashboardHeader } from "@/components/dashboard/DashboardHeader";
import { DashboardNav } from "@/components/dashboard/DashboardNav";
import { useAuth } from "@/hooks/use-auth";
import { Track } from "@shared/schema";

export default function TracksPage() {
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");

  // Fetch tracks data
  const { data: tracks, isLoading } = useQuery({
    queryKey: ['/api/tracks'],
    queryFn: () => apiRequest<Track[]>({ url: '/api/tracks', method: 'GET' })
  });

  // Filter tracks based on search query
  const filteredTracks = tracks?.filter(track => 
    track.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex min-h-screen bg-background">
      {/* Sidebar */}
      <DashboardNav />

      {/* Main content */}
      <div className="flex-1 overflow-hidden">
        <DashboardHeader user={user} />

        <main className="flex-1 overflow-y-auto p-6">
          <div className="mx-auto max-w-6xl space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-3xl font-bold tracking-tight">เพลงของฉัน</h1>
                <p className="text-muted-foreground">
                  จัดการเพลงทั้งหมดของคุณที่นี่
                </p>
              </div>
              
              <Button
                onClick={() => navigate("/dashboard/upload")}
                className="flex items-center gap-2 shrink-0"
              >
                <Plus className="h-4 w-4" />
                อัพโหลดเพลงใหม่
              </Button>
            </div>

            {/* Search bar */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="ค้นหาเพลง..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>

            {/* Tracks grid */}
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {isLoading && (
                <div className="col-span-full flex justify-center p-12">
                  <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
                </div>
              )}
              
              {!isLoading && filteredTracks && filteredTracks.length === 0 && (
                <Card className="col-span-full">
                  <CardHeader>
                    <CardTitle className="text-center">ยังไม่มีเพลง</CardTitle>
                    <CardDescription className="text-center">คุณยังไม่ได้อัพโหลดเพลงใด ๆ</CardDescription>
                  </CardHeader>
                  <CardFooter className="justify-center">
                    <Button onClick={() => navigate("/dashboard/upload")} className="flex items-center gap-2">
                      <Plus className="h-4 w-4" />
                      อัพโหลดเพลงแรกของคุณ
                    </Button>
                  </CardFooter>
                </Card>
              )}

              {!isLoading && filteredTracks && filteredTracks.map((track) => (
                <Card key={track.id} className="overflow-hidden">
                  <div className="aspect-square bg-gray-100 relative">
                    <div className="absolute inset-0 flex items-center justify-center bg-black/5">
                      <Music className="h-10 w-10 text-gray-400" />
                    </div>
                  </div>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg truncate">{track.title}</CardTitle>
                    <CardDescription>
                        สถานะ: <span className={`font-medium ${
                          track.status === 'live' ? 'text-green-500' :
                          track.status === 'pending' ? 'text-yellow-500' :
                          track.status === 'rejected' ? 'text-red-500' : 'text-blue-500'
                        }`}>
                          {track.status === 'live' ? 'ออนไลน์' :
                           track.status === 'pending' ? 'รอการตรวจสอบ' :
                           track.status === 'processing' ? 'กำลังประมวลผล' :
                           track.status === 'distributing' ? 'กำลังเผยแพร่' :
                           track.status === 'rejected' ? 'ถูกปฏิเสธ' : 'ไม่ทราบสถานะ'}
                        </span>
                    </CardDescription>
                  </CardHeader>
                  <CardFooter>
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full"
                      onClick={() => navigate(`/dashboard/tracks/${track.id}`)}
                    >
                      ดูรายละเอียด
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}