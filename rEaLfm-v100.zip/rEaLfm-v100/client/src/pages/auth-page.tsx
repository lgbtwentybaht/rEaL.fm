import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/hooks/use-auth";
import { signupSchema, loginSchema, type SignupFormData, type LoginFormData } from "@shared/schema";

export default function AuthPage() {
  const [, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState("login");
  const { user, loginMutation, registerMutation } = useAuth();
  
  // Redirect if already logged in
  useEffect(() => {
    if (user) {
      if (user.role === 'admin') {
        navigate("/admin/dashboard");
      } else {
        navigate("/dashboard");
      }
    }
  }, [user, navigate]);

  // Login form
  const loginForm = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: ""
    }
  });

  // Signup form
  const signupForm = useForm<SignupFormData>({
    resolver: zodResolver(signupSchema),
    defaultValues: {
      username: "",
      email: "",
      password: "",
      confirmPassword: "",
      artistName: "",
      fullName: "",
      acceptTerms: false
    }
  });

  // Form submission handlers
  const onLoginSubmit = (data: LoginFormData) => {
    loginMutation.mutate(data, {
      onSuccess: (response) => {
        const user = response.user;
        if (user.role === 'admin') {
          navigate("/admin/dashboard");
        } else {
          navigate("/dashboard");
        }
      }
    });
  };

  const onSignupSubmit = (data: SignupFormData) => {
    registerMutation.mutate(data, {
      onSuccess: () => {
        navigate("/dashboard");
      }
    });
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <div className="container flex-1 flex items-center justify-center py-12">
        <div className="grid w-full lg:grid-cols-2 gap-8 items-center max-w-6xl mx-auto">
          {/* Form Section */}
          <Card className="w-full max-w-md mx-auto">
            <CardHeader className="text-center">
              <CardTitle className="text-3xl font-bold">rEaL.fm</CardTitle>
              <CardDescription>
                แพลตฟอร์มกระจายเพลงสำหรับศิลปินไทย
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="login" value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="grid grid-cols-2 mb-6">
                  <TabsTrigger value="login">เข้าสู่ระบบ</TabsTrigger>
                  <TabsTrigger value="signup">สมัครสมาชิก</TabsTrigger>
                </TabsList>
                
                {/* Login Tab */}
                <TabsContent value="login">
                  <Form {...loginForm}>
                    <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-4">
                      <FormField
                        control={loginForm.control}
                        name="username"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>ชื่อผู้ใช้</FormLabel>
                            <FormControl>
                              <Input placeholder="username" {...field} autoComplete="username" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={loginForm.control}
                        name="password"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>รหัสผ่าน</FormLabel>
                            <FormControl>
                              <Input 
                                type="password" 
                                placeholder="••••••••" 
                                {...field} 
                                autoComplete="current-password" 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <Button 
                        type="submit" 
                        className="w-full" 
                        disabled={loginMutation.isPending}
                      >
                        {loginMutation.isPending ? (
                          <span className="flex items-center gap-2">
                            <span className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent"></span>
                            กำลังเข้าสู่ระบบ...
                          </span>
                        ) : (
                          "เข้าสู่ระบบ"
                        )}
                      </Button>
                    </form>
                  </Form>
                </TabsContent>
                
                {/* Signup Tab */}
                <TabsContent value="signup">
                  <Form {...signupForm}>
                    <form onSubmit={signupForm.handleSubmit(onSignupSubmit)} className="space-y-4">
                      <FormField
                        control={signupForm.control}
                        name="username"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>ชื่อผู้ใช้</FormLabel>
                            <FormControl>
                              <Input placeholder="username" {...field} autoComplete="username" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={signupForm.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>อีเมล</FormLabel>
                            <FormControl>
                              <Input 
                                type="email" 
                                placeholder="your@email.com" 
                                {...field} 
                                autoComplete="email" 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={signupForm.control}
                          name="fullName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>ชื่อ-นามสกุล</FormLabel>
                              <FormControl>
                                <Input placeholder="ชื่อจริง นามสกุล" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={signupForm.control}
                          name="artistName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>ชื่อศิลปิน</FormLabel>
                              <FormControl>
                                <Input placeholder="ชื่อที่ใช้แสดงผลงาน" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <FormField
                        control={signupForm.control}
                        name="password"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>รหัสผ่าน</FormLabel>
                            <FormControl>
                              <Input 
                                type="password" 
                                placeholder="••••••••" 
                                {...field} 
                                autoComplete="new-password" 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={signupForm.control}
                        name="confirmPassword"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>ยืนยันรหัสผ่าน</FormLabel>
                            <FormControl>
                              <Input 
                                type="password" 
                                placeholder="••••••••" 
                                {...field} 
                                autoComplete="new-password" 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={signupForm.control}
                        name="acceptTerms"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>
                                ฉันยอมรับ <a href="/terms" className="underline text-primary">ข้อกำหนดและเงื่อนไข</a> การใช้งาน
                              </FormLabel>
                              <FormMessage />
                            </div>
                          </FormItem>
                        )}
                      />
                      
                      <Button 
                        type="submit" 
                        className="w-full" 
                        disabled={registerMutation.isPending}
                      >
                        {registerMutation.isPending ? (
                          <span className="flex items-center gap-2">
                            <span className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent"></span>
                            กำลังสมัครสมาชิก...
                          </span>
                        ) : (
                          "สมัครสมาชิก"
                        )}
                      </Button>
                    </form>
                  </Form>
                </TabsContent>
              </Tabs>
            </CardContent>
            <CardFooter className="flex justify-center">
              <Button variant="link" onClick={() => navigate("/")}>
                กลับไปยังหน้าหลัก
              </Button>
            </CardFooter>
          </Card>
          
          {/* Hero Section */}
          <div className="hidden lg:flex flex-col space-y-6">
            <div>
              <h1 className="text-4xl font-bold">รวมทุกช่องทางการเผยแพร่เพลง</h1>
              <p className="text-xl text-muted-foreground mt-2">
                เผยแพร่ผลงานของคุณไปยังทุกแพลตฟอร์มดัง เช่น Spotify, Apple Music, Joox, YouTube Music และอีกมากกว่า 50 แพลตฟอร์มทั่วโลก
              </p>
            </div>
            
            <div className="grid grid-cols-2 gap-6">
              <div className="bg-primary/5 rounded-lg p-6">
                <h3 className="text-lg font-semibold mb-2">รายได้เป็นของคุณ 100%</h3>
                <p className="text-muted-foreground">
                  รับรายได้จากการสตรีมทั้งหมดโดยไม่มีการหักส่วนแบ่ง เพียงจ่ายค่าบริการรายปีเท่านั้น
                </p>
              </div>
              
              <div className="bg-primary/5 rounded-lg p-6">
                <h3 className="text-lg font-semibold mb-2">ไม่มีสัญญาผูกมัด</h3>
                <p className="text-muted-foreground">
                  คุณสามารถถอนเพลงหรือย้ายไปที่อื่นได้ตลอดเวลา ไม่มีสัญญาผูกมัดระยะยาว
                </p>
              </div>
              
              <div className="bg-primary/5 rounded-lg p-6">
                <h3 className="text-lg font-semibold mb-2">แนวเพลงทุกประเภท</h3>
                <p className="text-muted-foreground">
                  ไม่ว่าคุณจะทำเพลงแนวไหน เราพร้อมให้บริการและสนับสนุนศิลปินทุกรูปแบบ
                </p>
              </div>
              
              <div className="bg-primary/5 rounded-lg p-6">
                <h3 className="text-lg font-semibold mb-2">รายงานละเอียด</h3>
                <p className="text-muted-foreground">
                  ติดตามผลงานของคุณด้วยรายงานสถิติแบบเรียลไทม์ ดูว่าใครฟังเพลงคุณและที่ไหน
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}