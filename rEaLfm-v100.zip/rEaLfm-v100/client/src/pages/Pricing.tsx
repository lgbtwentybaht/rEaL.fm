import { Navbar } from "@/components/Navbar";
import { PricingSection } from "@/components/PricingSection";
import { Footer } from "@/components/Footer";
import { ContactSection } from "@/components/ContactSection";
import { WaitlistSection } from "@/components/WaitlistSection";

export default function Pricing() {
  return (
    <div className="min-h-screen bg-background text-foreground font-sans">
      <Navbar />
      <div className="pt-24 pb-12 md:pt-32 md:pb-16">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl md:text-5xl font-bold text-center mb-4">แพคเกจและราคา</h1>
          <p className="text-center text-muted-foreground text-lg mb-12 max-w-3xl mx-auto">
            เลือกแพคเกจที่เหมาะกับความต้องการของคุณ เพื่อเผยแพร่ผลงานเพลงของคุณไปยังแพลตฟอร์มสตรีมมิ่งทั่วโลก
          </p>
        </div>
      </div>
      <PricingSection />
      <WaitlistSection />
      <ContactSection />
      <Footer />
    </div>
  );
}