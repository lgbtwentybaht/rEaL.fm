import { motion } from "framer-motion";
import { Plus, Flag, BarChart } from "lucide-react";

export function AboutSection() {
  return (
    <section id="about" className="py-20 bg-white relative overflow-hidden">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <span className="text-primary font-semibold uppercase tracking-wider text-sm">เรื่องราวของเรา</span>
            <h2 className="text-3xl md:text-4xl font-bold my-4 text-gray-900">สร้างโดยนักดนตรี เพื่อนักดนตรี</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              เราเข้าใจความท้าทายที่ศิลปินอิสระต้องเผชิญในวงการดนตรียุคปัจจุบัน
            </p>
          </motion.div>
        </div>
        
        <div className="flex flex-col lg:flex-row items-center gap-12">
          <motion.div 
            className="lg:w-1/2"
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <div className="bg-white p-8 rounded-xl shadow-xl relative">
              <div className="absolute -top-3 -left-3 w-20 h-20 bg-primary/10 rounded-full"></div>
              <div className="relative z-10">
                <p className="text-gray-700 mb-6 leading-relaxed">
                  rEaL.fm ก่อตั้งโดยทีมนักดนตรี โปรดิวเซอร์ และผู้เชี่ยวชาญในวงการที่เบื่อหน่ายกับรูปแบบเดิมๆ ของการเผยแพร่เพลง เราเข้าใจความท้าทายที่ศิลปินอิสระต้องเผชิญในวงการดนตรียุคปัจจุบัน
                </p>
                <p className="text-gray-700 mb-6 leading-relaxed">
                  ภารกิจของเราคือการเสริมพลังให้ศิลปินด้วยเครื่องมือ ทรัพยากร และการสนับสนุนที่จำเป็นต่อความสำเร็จตามเงื่อนไขของพวกเขาเอง เราเชื่อในค่าตอบแทนที่เป็นธรรม แนวทางธุรกิจที่โปร่งใส และการให้ความสำคัญกับศิลปินเป็นอันดับแรก
                </p>
                <p className="text-gray-700 mb-8 leading-relaxed">
                  กับ SoundWave คุณไม่ได้รับเพียงแค่บริการเผยแพร่ – คุณกำลังเข้าร่วมชุมชนของผู้สร้างสรรค์ที่มีแนวคิดเดียวกันซึ่งกำลังเปลี่ยนแปลงอุตสาหกรรมดนตรีจากรากฐาน
                </p>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-10">
                  <div className="bg-gray-50 rounded-lg p-6 border border-gray-100">
                    <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center mb-4">
                      <Plus className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="text-2xl font-bold text-gray-900">10K+</h3>
                    <p className="text-sm text-gray-500">ศิลปินที่ให้บริการ</p>
                  </div>
                  
                  <div className="bg-gray-50 rounded-lg p-6 border border-gray-100">
                    <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center mb-4">
                      <Flag className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="text-2xl font-bold text-gray-900">150+</h3>
                    <p className="text-sm text-gray-500">แพลตฟอร์ม</p>
                  </div>
                  
                  <div className="bg-gray-50 rounded-lg p-6 border border-gray-100">
                    <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center mb-4">
                      <BarChart className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="text-2xl font-bold text-gray-900">$10M+</h3>
                    <p className="text-sm text-gray-500">ค่าลิขสิทธิ์ที่จ่ายแล้ว</p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
          
          <motion.div 
            className="lg:w-1/2"
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <img 
                  src="https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" 
                  alt="สตูดิโอดนตรี" 
                  className="rounded-lg shadow-md h-48 w-full object-cover" 
                />
                <img 
                  src="https://images.unsplash.com/photo-1470225620780-dba8ba36b745?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" 
                  alt="การแสดงของดีเจ" 
                  className="rounded-lg shadow-md h-64 w-full object-cover" 
                />
              </div>
              <div className="space-y-4 mt-8">
                <img 
                  src="https://images.unsplash.com/photo-1593697821252-0c9137d9fc45?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" 
                  alt="อุปกรณ์การผลิต" 
                  className="rounded-lg shadow-md h-64 w-full object-cover" 
                />
                <img 
                  src="https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" 
                  alt="ดนตรีสด" 
                  className="rounded-lg shadow-md h-48 w-full object-cover" 
                />
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      <div className="absolute top-0 right-0 w-1/3 h-1/3 bg-primary/5 rounded-full filter blur-[100px] -z-10"></div>
      <div className="absolute bottom-0 left-0 w-1/3 h-1/3 bg-sky-500/5 rounded-full filter blur-[100px] -z-10"></div>
    </section>
  );
}
