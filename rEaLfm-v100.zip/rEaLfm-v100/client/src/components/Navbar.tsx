import { useState, useEffect } from "react";
import { useLocation, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [location, navigate] = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleNavigation = (sectionId: string) => {
    setIsOpen(false);
    
    // หากอยู่ในหน้าแรก ให้เลื่อนไปยัง section
    if (location === "/") {
      const element = document.getElementById(sectionId);
      if (element) {
        element.scrollIntoView({ behavior: "smooth" });
      }
    } else {
      // หากอยู่ในหน้าอื่น ให้นำทางกลับหน้าแรกแล้วค่อยเลื่อน
      navigate("/");
      setTimeout(() => {
        const element = document.getElementById(sectionId);
        if (element) {
          element.scrollIntoView({ behavior: "smooth" });
        }
      }, 100);
    }
  };

  return (
    <nav className={`fixed w-full z-50 ${scrolled ? 'bg-white shadow-sm' : 'bg-transparent'} transition-all duration-200`}>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          <div className="flex items-center">
            <a href="#" className="flex-shrink-0" onClick={() => handleNavigation("hero")}>
              <span className="text-2xl font-['Prompt'] font-bold text-primary">rEaL.fm</span>
            </a>
          </div>
          
          <div className="hidden md:block">
            <div className="flex items-center space-x-8">
              <button onClick={() => handleNavigation("features")} className="text-gray-600 hover:text-primary font-medium transition-colors">คุณสมบัติ</button>
              <Link href="/pricing" className="text-gray-600 hover:text-primary font-medium transition-colors">ราคาแพลน</Link>
              <button onClick={() => handleNavigation("about")} className="text-gray-600 hover:text-primary font-medium transition-colors">เกี่ยวกับเรา</button>
              <button onClick={() => handleNavigation("faq")} className="text-gray-600 hover:text-primary font-medium transition-colors">คำถามที่พบบ่อย</button>
              <button onClick={() => handleNavigation("contact")} className="text-gray-600 hover:text-primary font-medium transition-colors">ติดต่อเรา</button>
              <Link href="/auth" className="text-gray-600 hover:text-primary font-medium transition-colors">เข้าสู่ระบบ</Link>
              <Button 
                onClick={() => navigate("/auth")}
                className="bg-primary hover:bg-primary/90 text-white font-medium px-6 py-2 rounded-md transition-all hover:shadow-md"
              >
                Client Login
              </Button>
            </div>
          </div>
          
          <div className="md:hidden">
            <button 
              onClick={() => setIsOpen(!isOpen)} 
              className="text-gray-600 hover:text-primary"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.2 }}
            className="md:hidden bg-white shadow-lg overflow-hidden"
          >
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
              <button onClick={() => handleNavigation("features")} className="block px-3 py-2 rounded-md text-base font-medium text-gray-600 hover:text-primary hover:bg-gray-50 w-full text-left">คุณสมบัติ</button>
              <Link href="/pricing" className="block px-3 py-2 rounded-md text-base font-medium text-gray-600 hover:text-primary hover:bg-gray-50 w-full text-left">ราคาแพลน</Link>
              <button onClick={() => handleNavigation("about")} className="block px-3 py-2 rounded-md text-base font-medium text-gray-600 hover:text-primary hover:bg-gray-50 w-full text-left">เกี่ยวกับเรา</button>
              <button onClick={() => handleNavigation("faq")} className="block px-3 py-2 rounded-md text-base font-medium text-gray-600 hover:text-primary hover:bg-gray-50 w-full text-left">คำถามที่พบบ่อย</button>
              <button onClick={() => handleNavigation("contact")} className="block px-3 py-2 rounded-md text-base font-medium text-gray-600 hover:text-primary hover:bg-gray-50 w-full text-left">ติดต่อเรา</button>
              <Link href="/auth" className="block px-3 py-2 rounded-md text-base font-medium text-gray-600 hover:text-primary hover:bg-gray-50 w-full text-left">เข้าสู่ระบบ</Link>
              <Link href="/auth" className="block px-3 py-2 rounded-md text-base font-medium bg-primary text-white w-full text-left">Client Login</Link>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
