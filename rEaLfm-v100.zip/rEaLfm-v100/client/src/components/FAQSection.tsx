import { useState } from "react";
import { motion } from "framer-motion";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

const faqItems = [
  {
    question: "ระบบลงทะเบียนรอทำงานอย่างไร?",
    answer: "เมื่อคุณเข้าร่วมบัญชีรายชื่อผู้รอใช้งานของเรา คุณจะได้รับสิทธิ์การเข้าถึง rEaL.fm ก่อนใครเมื่อเราเปิดตัว คุณจะเป็นหนึ่งในผู้ที่ได้สัมผัสประสบการณ์แพลตฟอร์มของเราเป็นกลุ่มแรก และคุณจะได้รับสิทธิประโยชน์พิเศษสำหรับสมาชิกผู้ก่อตั้ง"
  },
  {
    question: "ค่าธรรมเนียมการเผยแพร่ของคุณเป็นอย่างไร?",
    answer: "เราให้บริการหลายแผนที่ยืดหยุ่นตามความต้องการของคุณ แผนพื้นฐานของเราช่วยให้คุณรักษาค่าลิขสิทธิ์ได้ 100% โดยมีค่าธรรมเนียมรายปีเล็กน้อย ขณะที่แผนพรีเมียมของเรารวมบริการการตลาดและการส่งเสริมการขายเพิ่มเติม"
  },
  {
    question: "คุณเผยแพร่ไปยังแพลตฟอร์มใดบ้าง?",
    answer: "เราเผยแพร่ไปยังแพลตฟอร์มสตรีมมิ่งหลักทั้งหมด รวมถึง Spotify, Apple Music, Amazon Music, YouTube Music, TikTok, Instagram/Facebook และอีกกว่า 150 แพลตฟอร์มทั่วโลก"
  },
  {
    question: "เพลงของฉันจะพร้อมใช้งานเร็วแค่ไหน?",
    answer: "หลังจากส่งเพลงของคุณ โดยทั่วไปแล้วจะใช้เวลา 1-3 วันทำการสำหรับทีมของเราในการตรวจสอบ และจากนั้น 1-7 วันสำหรับการปรากฏบนทุกแพลตฟอร์ม มีตัวเลือกการจัดส่งด่วนสำหรับการเปิดตัวที่มีความอ่อนไหวด้านเวลา"
  },
  {
    question: "คุณมีการสนับสนุนด้านการตลาดหรือไม่?",
    answer: "ใช่! เรามีชุดเครื่องมือส่งเสริมการขายรวมถึงการนำเสนอเพลย์ลิสต์ การส่งเสริมโซเชียลมีเดีย การติดต่อสื่อมวลชน และการจัดการแคมเปญโฆษณา บริการเหล่านี้รวมอยู่ในแผนพรีเมียมของเราหรือมีให้บริการแบบแยกรายการ"
  }
];

export function FAQSection() {
  return (
    <section id="faq" className="py-20 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <span className="text-primary font-semibold uppercase tracking-wider text-sm">คำถามที่พบบ่อย</span>
            <h2 className="text-3xl md:text-4xl font-bold my-4 text-gray-900">คำถามทั่วไป</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">ทุกสิ่งที่คุณต้องรู้เกี่ยวกับบริการของเรา</p>
          </motion.div>
        </div>
        
        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="space-y-4">
            {faqItems.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
              >
                <AccordionItem 
                  value={`item-${index}`}
                  className="border border-gray-200 rounded-lg overflow-hidden bg-white shadow-sm"
                >
                  <AccordionTrigger className="p-5 text-left font-medium text-gray-900 hover:no-underline hover:bg-gray-50">
                    {item.question}
                  </AccordionTrigger>
                  <AccordionContent className="bg-white p-5 text-gray-700 border-t border-gray-100">
                    {item.answer}
                  </AccordionContent>
                </AccordionItem>
              </motion.div>
            ))}
          </Accordion>
        </div>
        
        <motion.div 
          className="mt-12 text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <p className="text-gray-600 mb-6">มีคำถามเพิ่มเติมหรือไม่?</p>
          <a 
            href="#contact" 
            className="inline-flex items-center text-primary font-medium hover:underline"
            onClick={(e) => {
              e.preventDefault();
              const element = document.getElementById("contact");
              if (element) {
                element.scrollIntoView({ behavior: "smooth" });
              }
            }}
          >
            ติดต่อทีมสนับสนุนของเรา
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-1" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M12.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-2.293-2.293a1 1 0 010-1.414z" clipRule="evenodd" />
            </svg>
          </a>
        </motion.div>
      </div>
    </section>
  );
}
