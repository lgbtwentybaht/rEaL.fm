import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

export function HeroSection() {
  const handleNavigation = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="hero" className="relative overflow-hidden bg-gradient-to-r from-sky-50 to-indigo-50 pt-32 pb-16 md:pt-36 md:pb-24">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col-reverse lg:flex-row items-center">
          <motion.div 
            className="lg:w-1/2 pt-8 lg:pt-0"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 font-['Prompt'] leading-tight text-gray-900">
              <span className="block">เปิดตัวเพลงของคุณ</span>
              <span className="text-primary">ไกลขึ้นและเร็วขึ้น</span>
            </h1>
            
            <p className="text-xl text-gray-600 mb-8 max-w-2xl">
              SoundWave กำลังปฏิวัติวิธีที่ศิลปินอิสระเผยแพร่และส่งเสริมเพลงของพวกเขาทั่วโลก ไม่มีคนกลาง ค่าลิขสิทธิ์สูงขึ้น และการวิเคราะห์ที่ทรงพลัง
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                onClick={() => handleNavigation("waitlist")}
                className="inline-flex justify-center items-center px-8 py-4 text-base font-medium rounded-md bg-primary hover:bg-primary/90 text-white transition-all hover:shadow-lg"
              >
                ลงทะเบียนรอใช้งาน
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z" clipRule="evenodd" />
                </svg>
              </Button>
              <Button 
                onClick={() => handleNavigation("features")}
                variant="outline"
                className="inline-flex justify-center items-center px-8 py-4 text-base font-medium rounded-md text-primary border-primary bg-transparent hover:bg-primary/5"
              >
                เรียนรู้เพิ่มเติม
              </Button>
            </div>
            
            <div className="mt-8 flex items-center">
              <div className="flex -space-x-2">
                <img className="w-8 h-8 rounded-full border-2 border-white" src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80" alt="User" />
                <img className="w-8 h-8 rounded-full border-2 border-white" src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80" alt="User" />
                <img className="w-8 h-8 rounded-full border-2 border-white" src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80" alt="User" />
              </div>
              <p className="ml-4 text-sm text-gray-500">ได้รับความไว้วางใจจากศิลปินกว่า 10,000 คนทั่วโลก</p>
            </div>
          </motion.div>
          
          <motion.div 
            className="lg:w-1/2"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <div className="relative">
              <div className="absolute -top-6 -right-6 w-64 h-64 bg-primary/10 rounded-full filter blur-2xl"></div>
              <div className="absolute -bottom-8 -left-8 w-40 h-40 bg-sky-400/20 rounded-full filter blur-2xl"></div>
              <img 
                src="https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80" 
                alt="Music studio" 
                className="relative rounded-xl shadow-2xl w-full h-auto"
              />
            </div>
          </motion.div>
        </div>
      </div>
      
      <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-white to-transparent"></div>
    </section>
  );
}
