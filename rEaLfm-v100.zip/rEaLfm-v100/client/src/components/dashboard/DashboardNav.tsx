import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useLocation, Link } from "wouter";
import {
  BarChart2,
  ChevronLeft,
  ChevronRight,
  CreditCard,
  HelpCircle,
  Home,
  Layers,
  Menu,
  MessageSquare,
  Music,
  Settings,
  Upload,
  Users,
  X,
  LogOut,
  User,
  ShieldCheck,
  Globe,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useIsMobile } from "@/hooks/use-mobile";
import { useAuth } from "@/hooks/use-auth";

interface NavLinkItem {
  title: string;
  icon: React.ElementType;
  href: string;
  type?: undefined;
}

interface NavDividerItem {
  type: 'divider';
  title?: undefined;
  icon?: undefined;
  href?: undefined;
}

type NavItem = NavLinkItem | NavDividerItem;

const getNavItems = (isAdmin: boolean): NavItem[] => {
  const artistNavItems: NavItem[] = [
    {
      title: "แดชบอร์ด",
      icon: Home,
      href: "/dashboard",
    },
    {
      title: "เพลงของฉัน",
      icon: Music,
      href: "/dashboard/tracks",
    },
    {
      title: "อัลบั้ม",
      icon: Layers,
      href: "/dashboard/albums",
    },
    {
      title: "อัพโหลดเพลง",
      icon: Upload,
      href: "/dashboard/upload",
    },
    {
      title: "สถิติและรายได้",
      icon: BarChart2,
      href: "/dashboard/analytics",
    },
    {
      title: "การชำระเงิน",
      icon: CreditCard,
      href: "/dashboard/payments",
    },
    {
      title: "ทีมของฉัน",
      icon: Users,
      href: "/dashboard/team",
    },
    {
      title: "โปรไฟล์",
      icon: User,
      href: "/dashboard/profile",
    },
    {
      title: "การตั้งค่า",
      icon: Settings,
      href: "/dashboard/settings",
    },
  ];

  const adminItems: NavItem[] = [
    {
      title: "แอดมินแพเนล",
      icon: ShieldCheck,
      href: "/admin",
    },
    {
      title: "จัดการผู้ใช้",
      icon: Users,
      href: "/admin/users",
    },
    {
      title: "จัดการเพลง",
      icon: Music,
      href: "/admin/tracks",
    },
    {
      title: "จัดการอัลบั้ม",
      icon: Layers,
      href: "/admin/albums",
    },
  ];

  return isAdmin ? [...artistNavItems, { type: 'divider' as const }, ...adminItems] : artistNavItems;
};

export function DashboardNav() {
  const [location, navigate] = useLocation();
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const isMobile = useIsMobile();
  const { user, logoutMutation } = useAuth();
  
  const isAdmin = user?.role === "admin";
  const navItems = getNavItems(isAdmin);

  const toggleSidebar = () => {
    if (isMobile) {
      setMobileOpen(!mobileOpen);
    } else {
      setCollapsed(!collapsed);
    }
  };

  const closeMobileSidebar = () => {
    if (isMobile) {
      setMobileOpen(false);
    }
  };
  
  const handleLogout = () => {
    logoutMutation.mutate(undefined, {
      onSuccess: () => {
        navigate("/auth");
      }
    });
  };

  return (
    <>
      {/* Mobile overlay */}
      {isMobile && mobileOpen && (
        <div 
          className="fixed inset-0 z-40 bg-black/50"
          onClick={closeMobileSidebar}
        />
      )}

      {/* Mobile menu button */}
      <Button
        variant="ghost"
        size="icon"
        className="fixed top-4 left-4 z-50 md:hidden"
        onClick={toggleSidebar}
      >
        {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
      </Button>

      {/* Sidebar */}
      <aside
        className={cn(
          "bg-background fixed inset-y-0 left-0 z-30 flex flex-col border-r transition-all duration-300 ease-in-out",
          collapsed ? "w-[70px]" : "w-[240px]",
          isMobile && !mobileOpen && "-translate-x-full",
          isMobile && mobileOpen && "translate-x-0",
          isMobile ? "w-[240px]" : ""
        )}
      >
        <div className="flex h-16 items-center justify-between px-4 border-b">
          <h1 className={cn("text-xl font-bold text-primary", collapsed && !isMobile && "hidden")}>
            rEaL.fm
          </h1>
          {!isMobile && (
            <Button variant="ghost" size="icon" onClick={toggleSidebar}>
              {collapsed ? <ChevronRight className="h-5 w-5" /> : <ChevronLeft className="h-5 w-5" />}
            </Button>
          )}
        </div>

        <nav className="flex-1 overflow-y-auto py-4">
          <ul className="space-y-1 px-2">
            {navItems.map((item, index) => {
              if ('type' in item && item.type === 'divider') {
                return (
                  <li key={`divider-${index}`} className="my-2">
                    <div className="border-t border-border mx-2"></div>
                    {!collapsed && !isMobile && (
                      <p className="text-xs font-medium text-muted-foreground mt-4 mb-2 px-3">
                        ระบบผู้ดูแล
                      </p>
                    )}
                  </li>
                );
              }
              
              // Now TypeScript knows this is a navigation item
              if ('href' in item) {
                return (
                  <li key={item.href}>
                    <Link
                      href={item.href}
                      onClick={() => closeMobileSidebar()}
                      className={cn(
                        "flex items-center gap-3 rounded-md px-3 py-2 text-sm transition-colors",
                        location === item.href
                          ? "bg-primary/10 text-primary"
                          : "text-muted-foreground hover:bg-muted hover:text-foreground"
                      )}
                    >
                      <item.icon className="h-5 w-5" />
                      <span className={cn(collapsed && !isMobile && "hidden")}>{item.title}</span>
                    </Link>
                  </li>
                );
              }
              
              return null;
            })}
          </ul>
        </nav>

        <div className="border-t p-4">
          <div className={cn("flex items-center gap-3", collapsed && !isMobile && "justify-center")}>
            <div className="flex items-center gap-2">
              <MessageSquare className="h-5 w-5 text-muted-foreground" />
              {!collapsed && !isMobile && <span className="text-sm text-muted-foreground">ช่วยเหลือ</span>}
            </div>
            
            <div className="flex items-center gap-2 ml-auto">
              <Button
                variant="ghost"
                size={collapsed && !isMobile ? "icon" : "sm"}
                className={collapsed && !isMobile ? "" : "gap-2"}
                onClick={handleLogout}
              >
                <LogOut className="h-4 w-4" />
                {!collapsed && !isMobile && <span>ออกจากระบบ</span>}
              </Button>
              
              {!collapsed && !isMobile && (
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => window.open("/help", "_blank")}
                >
                  <HelpCircle className="h-5 w-5" />
                </Button>
              )}
            </div>
          </div>
        </div>
      </aside>
    </>
  );
}