import { useEffect, useState } from "react";
import { 
  Sheet, 
  SheetContent, 
  SheetHeader, 
  SheetTitle, 
  SheetTrigger 
} from "@/components/ui/sheet";
import { Bell } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Separator } from "@/components/ui/separator";
import { Link } from "wouter";

type Notification = {
  id: number;
  userId: number;
  type: 'system' | 'track' | 'payment' | 'distribution';
  title: string;
  message: string;
  isRead: boolean;
  linkUrl: string | null;
  relatedId: number | null;
  createdAt: string;
};

export function NotificationPanel() {
  const [isOpen, setIsOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // การเรียกข้อมูลการแจ้งเตือน
  const { data: notifications = [], isLoading } = useQuery({
    queryKey: ['/api/notifications'],
    queryFn: () => apiRequest<Notification[]>({ url: '/api/notifications', method: 'GET' }),
    enabled: isOpen,
  });

  // การเรียกจำนวนการแจ้งเตือนที่ยังไม่ได้อ่าน
  const { data: unreadData, refetch: refetchUnreadCount } = useQuery({
    queryKey: ['/api/notifications/unread/count'],
    queryFn: () => apiRequest<{ count: number }>({ url: '/api/notifications/unread/count', method: 'GET' }),
  });

  // การมาร์คการแจ้งเตือนเป็นอ่านแล้ว
  const markAsReadMutation = useMutation({
    mutationFn: (id: number) => {
      return apiRequest({
        url: `/api/notifications/${id}/read`,
        method: 'PATCH'
      });
    },
    onSuccess: () => {
      // อัพเดท cache
      queryClient.invalidateQueries({ queryKey: ['/api/notifications'] });
      queryClient.invalidateQueries({ queryKey: ['/api/notifications/unread/count'] });
    },
  });

  // การมาร์คการแจ้งเตือนทั้งหมดเป็นอ่านแล้ว
  const markAllAsReadMutation = useMutation({
    mutationFn: () => {
      return apiRequest({
        url: `/api/notifications/read-all`,
        method: 'PATCH'
      });
    },
    onSuccess: () => {
      toast({
        title: "อ่านการแจ้งเตือนทั้งหมดแล้ว",
        description: "ทำเครื่องหมายการแจ้งเตือนทั้งหมดเป็นอ่านแล้ว",
      });
      // อัพเดท cache
      queryClient.invalidateQueries({ queryKey: ['/api/notifications'] });
      queryClient.invalidateQueries({ queryKey: ['/api/notifications/unread/count'] });
    },
  });

  const handleMarkAsRead = (id: number) => {
    markAsReadMutation.mutate(id);
  };

  const handleMarkAllAsRead = () => {
    markAllAsReadMutation.mutate();
  };

  useEffect(() => {
    if (isOpen) {
      // รีเฟรชข้อมูลเมื่อเปิดพาเนล
      queryClient.invalidateQueries({ queryKey: ['/api/notifications'] });
    }
  }, [isOpen, queryClient]);

  // ฟังก์ชันเพื่อแปลงวันที่เป็นรูปแบบที่อ่านง่าย
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('th-TH', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  // ฟังก์ชันกำหนดสีไอคอนตามประเภทการแจ้งเตือน
  const getTypeColor = (type: string) => {
    switch(type) {
      case 'system': return 'bg-blue-100 text-blue-600';
      case 'track': return 'bg-green-100 text-green-600';
      case 'payment': return 'bg-purple-100 text-purple-600';
      case 'distribution': return 'bg-orange-100 text-orange-600';
      default: return 'bg-gray-100 text-gray-600';
    }
  };

  // ฟังก์ชันแปลประเภทการแจ้งเตือนเป็นภาษาไทย
  const getTypeText = (type: string) => {
    switch(type) {
      case 'system': return 'ระบบ';
      case 'track': return 'เพลง';
      case 'payment': return 'การชำระเงิน';
      case 'distribution': return 'การเผยแพร่';
      default: return '';
    }
  };

  const unreadCount = unreadData?.count || 0;

  return (
    <Sheet open={isOpen} onOpenChange={setIsOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon" className="relative">
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <span className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-primary text-[10px] text-white">
              {unreadCount > 99 ? '99+' : unreadCount}
            </span>
          )}
        </Button>
      </SheetTrigger>
      <SheetContent side="right" className="sm:max-w-md w-full">
        <SheetHeader className="flex flex-row items-center justify-between">
          <SheetTitle>การแจ้งเตือน</SheetTitle>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={handleMarkAllAsRead}
            disabled={notifications.length === 0 || notifications.every(n => n.isRead)}
          >
            อ่านทั้งหมด
          </Button>
        </SheetHeader>
        <Separator className="my-4" />
        <ScrollArea className="h-[calc(100vh-8rem)] pr-4">
          {isLoading ? (
            <div className="flex justify-center items-center h-20">
              <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
            </div>
          ) : notifications.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              คุณไม่มีการแจ้งเตือนในขณะนี้
            </div>
          ) : (
            <div className="space-y-4">
              {notifications.map((notification) => (
                <div
                  key={notification.id}
                  className={cn(
                    "flex flex-col p-4 border rounded-lg space-y-2 transition-colors",
                    !notification.isRead ? "bg-muted/50" : "bg-card"
                  )}
                >
                  <div className="flex justify-between items-start">
                    <div className="flex items-center space-x-2">
                      <span className={cn("text-xs px-2 py-1 rounded-full", getTypeColor(notification.type))}>
                        {getTypeText(notification.type)}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {formatDate(notification.createdAt)}
                      </span>
                    </div>
                    {!notification.isRead && (
                      <Button variant="ghost" size="sm" className="h-6 px-2 text-xs" onClick={() => handleMarkAsRead(notification.id)}>
                        ทำเครื่องหมายว่าอ่านแล้ว
                      </Button>
                    )}
                  </div>
                  <div>
                    <h4 className="font-medium">{notification.title}</h4>
                    <p className="text-sm text-muted-foreground mt-1">{notification.message}</p>
                  </div>
                  {notification.linkUrl && (
                    <div className="pt-1">
                      <Link to={notification.linkUrl}>
                        <Button variant="link" className="h-auto p-0 text-sm">
                          ดูรายละเอียด
                        </Button>
                      </Link>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </SheetContent>
    </Sheet>
  );
}