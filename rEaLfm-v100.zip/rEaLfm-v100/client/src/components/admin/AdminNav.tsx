import { Link } from "wouter";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Users,
  Music2,
  Album,
  BarChart3,
  Settings,
  Globe,
  LogOut,
} from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";

const mainNavItems = [
  {
    title: "ผู้ใช้",
    href: "/admin/users",
    icon: Users,
  },
  {
    title: "เพลง",
    href: "/admin/tracks",
    icon: Music2,
  },
  {
    title: "อัลบั้ม",
    href: "/admin/albums",
    icon: Album,
  },
  {
    title: "รายงาน",
    href: "/admin/reports",
    icon: BarChart3,
  },
  {
    title: "การตั้งค่า",
    href: "/admin/settings",
    icon: Settings,
  },
];

export function AdminNav() {
  const { logoutMutation } = useAuth();
  const { toast } = useToast();
  
  const handleLogout = () => {
    logoutMutation.mutate(undefined, {
      onSuccess: () => {
        toast({
          title: "ออกจากระบบสำเร็จ",
          description: "คุณได้ออกจากระบบเรียบร้อยแล้ว",
        });
      },
      onError: (error) => {
        toast({
          title: "ไม่สามารถออกจากระบบได้",
          description: error.message,
          variant: "destructive",
        });
      },
    });
  };

  return (
    <div
      className="relative flex w-72 flex-col gap-6 border-r bg-muted/40 px-3 py-4"
    >
      <Link href="/admin" className="flex items-center gap-2 px-2">
        <Globe className="h-6 w-6" />
        <span className="text-xl font-bold">แอดมิน rEaL.fm</span>
      </Link>
      <div className="flex flex-1 flex-col gap-2">
        <div className="flex flex-col gap-1">
          <p className="text-xs font-medium text-muted-foreground pl-4">
            เมนูหลัก
          </p>
          <nav className="grid gap-1">
            {mainNavItems.map((item, index) => {
              const Icon = item.icon;
              return (
                <Link key={index} href={item.href}>
                  {({ isActive }) => (
                    <span
                      className={cn(
                        "group flex items-center rounded-md px-3 py-2 text-sm font-medium hover:bg-accent hover:text-accent-foreground",
                        isActive ? "bg-accent" : "transparent",
                      )}
                    >
                      <Icon className="mr-2 h-4 w-4" />
                      <span>{item.title}</span>
                    </span>
                  )}
                </Link>
              );
            })}
          </nav>
        </div>
      </div>
      <div>
        <Button 
          variant="outline" 
          className="w-full justify-start"
          onClick={handleLogout}
        >
          <LogOut className="mr-2 h-4 w-4" />
          ออกจากระบบ
        </Button>
      </div>
    </div>
  );
}