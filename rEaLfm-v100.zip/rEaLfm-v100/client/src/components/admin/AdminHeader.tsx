import { ReactNode } from "react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useAuth } from "@/hooks/use-auth";

type AdminHeaderProps = {
  title: string;
  description?: string;
  children?: ReactNode;
};

export function AdminHeader({
  title,
  description,
  children,
}: AdminHeaderProps) {
  const { user } = useAuth();

  return (
    <header className="sticky top-0 z-10 flex h-16 items-center gap-4 border-b bg-background px-6">
      <div className="flex flex-1 items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold">{title}</h1>
          {description && (
            <p className="text-sm text-muted-foreground">{description}</p>
          )}
        </div>
        <div className="flex items-center gap-4">
          {children}
          <Avatar>
            <AvatarImage
              src={user?.profilePicture || ""}
              alt={user?.username || ""}
            />
            <AvatarFallback>
              {user?.username ? user.username.substring(0, 2).toUpperCase() : ""}
            </AvatarFallback>
          </Avatar>
        </div>
      </div>
    </header>
  );
}