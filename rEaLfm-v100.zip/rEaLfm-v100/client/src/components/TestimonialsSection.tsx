import { motion } from "framer-motion";

const testimonials = [
  {
    quote: "SoundWave เปลี่ยนวิธีที่ฉันเผยแพร่เพลงอย่างสิ้นเชิง การวิเคราะห์ช่วยให้ฉันเข้าใจผู้ฟัง และเครื่องมือการตลาดของพวกเขาช่วยให้ฉันเพิ่มฐานแฟนเพลงได้อย่างมีนัยสำคัญ",
    name: "เอเลน่า วินเทอร์ส",
    title: "โปรดิวเซอร์อิเล็กทรอนิกส์",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80"
  },
  {
    quote: "อัตราค่าลิขสิทธิ์ที่สูงขึ้นสร้างความแตกต่างจริงๆ ในความสามารถของฉันในการระดมทุนสำหรับโครงการใหม่ ทีมของพวกเขาใส่ใจกับความสำเร็จของศิลปินอย่างจริงใจและแสดงออกมาในทุกการปฏิสัมพันธ์",
    name: "มาร์คัส รีด",
    title: "ศิลปินฮิปฮอป",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80"
  },
  {
    quote: "ในฐานะวงอินดี้ เราต้องการพาร์ทเนอร์ด้านการจัดจำหน่ายที่จะทำงานตามวิสัยทัศน์ของเรา SoundWave ให้อิสระแก่เราในการสร้างสรรค์ในขณะที่จัดการด้านธุรกิจอย่างมืออาชีพ",
    name: "ซาร่าห์ เฉิน",
    title: "นักร้องนำวงอินดี้",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80"
  }
];

export function TestimonialsSection() {
  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <span className="text-primary font-semibold uppercase tracking-wider text-sm">เรื่องราวความสำเร็จ</span>
            <h2 className="text-3xl md:text-4xl font-bold my-4 text-gray-900">เสียงจากศิลปินของเรา</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">ผลลัพธ์จริงจากนักดนตรีที่ได้ควบคุมอาชีพของพวกเขากับ SoundWave</p>
          </motion.div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div 
              key={index}
              className="bg-white rounded-xl p-8 shadow-md hover:shadow-lg transition-shadow relative"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <div className="mb-6">
                <svg className="h-8 w-8 text-primary/30" fill="currentColor" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
                  <path d="M10.7 25.4V14.8H6.4c0-4.5 3.2-8.2 7.4-8.2v4.7c-1.2 0-2.3 1.5-2.3 3.5h5.5v10.6h-6.3zm12.5 0V14.8h-4.3c0-4.5 3.2-8.2 7.4-8.2v4.7c-1.2 0-2.3 1.5-2.3 3.5h5.5v10.6h-6.3z" />
                </svg>
              </div>
              
              <p className="text-gray-700 mb-6 leading-relaxed">"{testimonial.quote}"</p>
              
              <div className="flex items-center">
                <div className="w-12 h-12 rounded-full overflow-hidden mr-4 ring-2 ring-primary/20">
                  <img src={testimonial.avatar} alt={`${testimonial.name} portrait`} className="w-full h-full object-cover" />
                </div>
                <div>
                  <h4 className="font-bold text-gray-900">{testimonial.name}</h4>
                  <p className="text-sm text-gray-500">{testimonial.title}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
        
        <motion.div 
          className="text-center mt-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <a 
            href="#waitlist" 
            className="inline-flex items-center text-primary font-medium hover:underline"
            onClick={(e) => {
              e.preventDefault();
              const element = document.getElementById("waitlist");
              if (element) {
                element.scrollIntoView({ behavior: "smooth" });
              }
            }}
          >
            เข้าร่วมกับศิลปินนับพันที่ไว้วางใจ SoundWave
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-1" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M12.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-2.293-2.293a1 1 0 010-1.414z" clipRule="evenodd" />
            </svg>
          </a>
        </motion.div>
      </div>
    </section>
  );
}
