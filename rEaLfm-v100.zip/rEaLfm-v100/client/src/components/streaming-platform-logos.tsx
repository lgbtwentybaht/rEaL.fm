import React from "react";
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

// Import SVG logos
import SpotifyLogo from '../assets/spotify-logo.svg';
import AppleMusicLogo from '../assets/apple-music-logo.svg';
import YoutubeMusicLogo from '../assets/youtube-music-logo.svg';
import JooxLogo from '../assets/joox-logo.svg';
import TidalLogo from '../assets/tidal-logo.svg';
import AmazonMusicLogo from '../assets/amazon-music-logo.svg';
import DeezerLogo from '../assets/deezer-logo.svg';
import PandoraLogo from '../assets/pandora-logo.svg';
import SoundcloudLogo from '../assets/soundcloud-logo.svg';
import IHeartRadioLogo from '../assets/iheartradio-logo.svg';

// Define the type for streaming platforms
export type StreamingPlatform = 
  | "spotify" 
  | "appleMusic" 
  | "youtubeMusic" 
  | "joox" 
  | "tidal" 
  | "amazonMusic" 
  | "deezer" 
  | "pandora" 
  | "soundcloud"
  | "iheartradio";

// Logos component for a single platform
export const StreamingPlatformLogo: React.FC<{
  platform: StreamingPlatform;
  size?: number;
  className?: string;
  withTooltip?: boolean;
}> = ({ platform, size = 24, className = "", withTooltip = false }) => {
  const getPlatformInfo = () => {
    const imgStyle = { width: size, height: size, display: 'inline-block' };
    
    switch (platform) {
      case "spotify":
        return { 
          name: "Spotify", 
          color: "text-green-500", 
          icon: <img src={SpotifyLogo} alt="Spotify" className={className} style={imgStyle} />
        };
      case "appleMusic":
        return { 
          name: "Apple Music", 
          color: "text-pink-500", 
          icon: <img src={AppleMusicLogo} alt="Apple Music" className={className} style={imgStyle} /> 
        };
      case "youtubeMusic":
        return { 
          name: "YouTube Music", 
          color: "text-red-500", 
          icon: <img src={YoutubeMusicLogo} alt="YouTube Music" className={className} style={imgStyle} /> 
        };
      case "joox":
        return { 
          name: "JOOX", 
          color: "text-blue-500", 
          icon: <img src={JooxLogo} alt="JOOX" className={className} style={imgStyle} /> 
        };
      case "tidal":
        return { 
          name: "TIDAL", 
          color: "text-gray-700", 
          icon: <img src={TidalLogo} alt="TIDAL" className={className} style={imgStyle} /> 
        };
      case "amazonMusic":
        return { 
          name: "Amazon Music", 
          color: "text-orange-500", 
          icon: <img src={AmazonMusicLogo} alt="Amazon Music" className={className} style={imgStyle} /> 
        };
      case "deezer":
        return { 
          name: "Deezer", 
          color: "text-purple-500", 
          icon: <img src={DeezerLogo} alt="Deezer" className={className} style={imgStyle} /> 
        };
      case "pandora":
        return { 
          name: "Pandora", 
          color: "text-blue-400", 
          icon: <img src={PandoraLogo} alt="Pandora" className={className} style={imgStyle} /> 
        };
      case "soundcloud":
        return { 
          name: "SoundCloud", 
          color: "text-orange-600", 
          icon: <img src={SoundcloudLogo} alt="SoundCloud" className={className} style={imgStyle} /> 
        };
      case "iheartradio":
        return { 
          name: "iHeartRadio", 
          color: "text-red-600", 
          icon: <img src={IHeartRadioLogo} alt="iHeartRadio" className={className} style={imgStyle} /> 
        };
      default:
        return { 
          name: "Unknown", 
          color: "text-gray-500", 
          icon: <div className={`${className} rounded-full bg-gray-200`} style={{ width: size/4, height: size/4 }}></div> 
        };
    }
  };

  const platformInfo = getPlatformInfo();

  return withTooltip ? (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <span>{platformInfo.icon}</span>
        </TooltipTrigger>
        <TooltipContent>
          <p>{platformInfo.name}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  ) : (
    <span>{platformInfo.icon}</span>
  );
};

// Display multiple platforms in a row
export const MultiPlatformDisplay: React.FC<{
  platforms: StreamingPlatform[];
  maxDisplay?: number;
  size?: number;
  withTooltip?: boolean;
}> = ({ platforms, maxDisplay = 4, size = 20, withTooltip = true }) => {
  const displayPlatforms = platforms.slice(0, maxDisplay);
  const remaining = platforms.length - maxDisplay;

  return (
    <div className="flex items-center gap-1">
      {displayPlatforms.map((platform, i) => (
        <StreamingPlatformLogo
          key={i}
          platform={platform}
          size={size}
          withTooltip={withTooltip}
        />
      ))}
      
      {remaining > 0 && (
        <Badge 
          variant="outline" 
          className="ml-1 bg-gray-100 text-gray-600 text-xs h-5 px-1.5"
        >
          +{remaining}
        </Badge>
      )}
    </div>
  );
};

// Display all platforms with name labels
export const PlatformList: React.FC<{
  platforms: StreamingPlatform[];
  size?: number;
}> = ({ platforms, size = 24 }) => {
  return (
    <div className="flex flex-wrap gap-3">
      {platforms.map((platform, i) => {
        // Get the platform name
        let name = "";
        switch (platform) {
          case "spotify": name = "Spotify"; break;
          case "appleMusic": name = "Apple Music"; break;
          case "youtubeMusic": name = "YouTube Music"; break;
          case "joox": name = "JOOX"; break;
          case "tidal": name = "TIDAL"; break;
          case "amazonMusic": name = "Amazon Music"; break;
          case "deezer": name = "Deezer"; break;
          case "pandora": name = "Pandora"; break;
          case "soundcloud": name = "SoundCloud"; break;
          case "iheartradio": name = "iHeartRadio"; break;
        }
        
        return (
          <div key={i} className="flex items-center gap-1.5">
            <StreamingPlatformLogo platform={platform} size={size} />
            <span className="text-sm">{name}</span>
          </div>
        );
      })}
    </div>
  );
};