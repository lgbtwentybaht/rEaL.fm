import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Check } from "lucide-react";
import { motion } from "framer-motion";

// คอมโพเนนท์สำหรับแสดงคุณสมบัติของแพคเกจ
const PricingFeature = ({ text }: { text: string }) => (
  <div className="flex items-center gap-2">
    <Check className="h-4 w-4 text-primary flex-shrink-0" />
    <span className="text-sm">{text}</span>
  </div>
);

// แพคเกจสำหรับแสดงในหน้าราคา
const pricingPlans = [
  {
    name: "Free",
    price: "ฟรี",
    description: "เหมาะสำหรับศิลปินมือใหม่ที่ต้องการเริ่มต้น",
    features: [
      "เผยแพร่เพลงไปยัง 10 แพลตฟอร์มชั้นนำ",
      "จำนวนเพลงจำกัด 10 เพลง/ปี",
      "ได้รับเพลงในคลังเพลงคุณ",
      "รายงานสถิติเบื้องต้น",
      "ระยะเวลาอนุมัติ 15 วัน"
    ],
    isPopular: false,
    ctaText: "เริ่มต้นใช้งานฟรี"
  },
  {
    name: "Basic",
    price: "฿2,XXX",
    subtext: "ต่อปี",
    description: "สำหรับศิลปินที่ต้องการเติบโตและเข้าถึงแพลตฟอร์มมากขึ้น",
    features: [
      "เผยแพร่เพลงไปยัง 50+ แพลตฟอร์ม",
      "จำนวนเพลงไม่จำกัด",
      "เก็บรายได้ 85%",
      "รายงานสถิติแบบละเอียด",
      "ระยะเวลาอนุมัติ 7 วัน",
      "จัดการศิลปินได้ 3 ศิลปิน",
      "การสนับสนุนทางอีเมล"
    ],
    isPopular: true,
    ctaText: "เลือกแพคเกจนี้"
  },
  {
    name: "Pro",
    price: "฿4,XXX",
    subtext: "ต่อปี",
    description: "สำหรับศิลปินมืออาชีพที่ต้องการบริการระดับพรีเมียม",
    features: [
      "เผยแพร่เพลงไปยัง 100+ แพลตฟอร์ม",
      "จำนวนเพลงไม่จำกัด",
      "เก็บรายได้ 90%",
      "รายงานสถิติแบบละเอียดและการวิเคราะห์",
      "ระยะเวลาอนุมัติ 3 วัน",
      "จัดการศิลปินได้ไม่จำกัด",
      "การสนับสนุนผ่านทางโทรศัพท์",
      "ผู้จัดการบัญชีส่วนตัว",
      "โอกาสในการโปรโมทพิเศษ"
    ],
    isPopular: false,
    ctaText: "เลือกแพคเกจนี้"
  }
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.5
    }
  }
};

export function PricingSection() {
  return (
    <section className="py-16 bg-gray-50" id="pricing">
      <div className="container mx-auto px-4">
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-8"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          {pricingPlans.map((plan, index) => (
            <motion.div key={index} variants={itemVariants}>
              <Card className={`flex flex-col h-full relative overflow-hidden ${plan.isPopular ? 'border-primary shadow-lg' : 'border-gray-200'}`}>
                {plan.isPopular && (
                  <div className="absolute top-0 right-0 bg-primary text-white px-3 py-1 text-xs font-medium">
                    แนะนำ
                  </div>
                )}
                <CardHeader>
                  <CardTitle className="text-xl font-semibold">{plan.name}</CardTitle>
                  <div className="mt-2">
                    <span className="text-3xl font-bold">{plan.price}</span>
                    {plan.subtext && <span className="text-sm text-gray-500 ml-1">{plan.subtext}</span>}
                  </div>
                  <CardDescription className="mt-2">{plan.description}</CardDescription>
                </CardHeader>
                <CardContent className="flex-grow">
                  <div className="space-y-3">
                    {plan.features.map((feature, i) => (
                      <PricingFeature key={i} text={feature} />
                    ))}
                  </div>
                </CardContent>
                <CardFooter className="pt-4">
                  <Button 
                    className={`w-full ${plan.isPopular ? 'bg-primary hover:bg-primary/90' : 'bg-gray-800 hover:bg-gray-700'}`}
                    onClick={() => {
                      const waitlistSection = document.getElementById('waitlist');
                      if (waitlistSection) {
                        waitlistSection.scrollIntoView({ behavior: 'smooth' });
                      }
                    }}
                  >
                    {plan.ctaText}
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        {/* แพลตฟอร์มพาร์ทเนอร์ */}
        <div className="mt-20 text-center">
          <h3 className="text-2xl font-bold mb-4">แพลตฟอร์มพาร์ทเนอร์ของเรา</h3>
          <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
            เราร่วมมือกับแพลตฟอร์มสตรีมมิ่งชั้นนำทั่วโลกเพื่อช่วยให้ศิลปินไทยสามารถเข้าถึงผู้ฟังทั่วโลกได้
          </p>
          
          <div className="flex flex-wrap justify-center items-center gap-8 mb-12">
            <div className="flex flex-col items-center">
              <div className="w-20 h-20 bg-gray-200 rounded-full flex items-center justify-center mb-2">
                <span className="text-lg font-bold">Spotify</span>
              </div>
              <span className="text-sm">Spotify</span>
            </div>
            <div className="flex flex-col items-center">
              <div className="w-20 h-20 bg-gray-200 rounded-full flex items-center justify-center mb-2">
                <span className="text-lg font-bold">AM</span>
              </div>
              <span className="text-sm">Apple Music</span>
            </div>
            <div className="flex flex-col items-center">
              <div className="w-20 h-20 bg-gray-200 rounded-full flex items-center justify-center mb-2">
                <span className="text-lg font-bold">YT</span>
              </div>
              <span className="text-sm">YouTube Music</span>
            </div>
            <div className="flex flex-col items-center">
              <div className="w-20 h-20 bg-gray-200 rounded-full flex items-center justify-center mb-2">
                <span className="text-lg font-bold">JOOX</span>
              </div>
              <span className="text-sm">JOOX</span>
            </div>
            <div className="flex flex-col items-center">
              <div className="w-20 h-20 bg-gray-200 rounded-full flex items-center justify-center mb-2">
                <span className="text-lg font-bold">TikTok</span>
              </div>
              <span className="text-sm">TikTok</span>
            </div>
            <div className="flex flex-col items-center">
              <div className="w-20 h-20 bg-gray-200 rounded-full flex items-center justify-center mb-2">
                <span className="text-lg font-bold">+95</span>
              </div>
              <span className="text-sm">แพลตฟอร์มอื่นๆ</span>
            </div>
          </div>
        </div>

        <div className="mt-16 max-w-3xl mx-auto text-center">
          <h3 className="text-2xl font-bold mb-4">บริการพิเศษเพิ่มเติม</h3>
          <p className="text-gray-600 mb-8">
            นอกจากแพคเกจหลักแล้ว เรายังมีบริการเสริมเฉพาะสำหรับศิลปินที่ต้องการความช่วยเหลือเพิ่มเติม
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">การโปรโมทเพลง</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">
                  บริการโปรโมทเพลงของคุณบนแพลตฟอร์มชั้นนำ เพิ่มโอกาสในการถูกเลือกเข้าเพลย์ลิสต์หลักและเพิ่มยอดสตรีม
                </p>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full" onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}>
                  สอบถามเพิ่มเติม
                </Button>
              </CardFooter>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">บริการจัดจำหน่ายเพลงแบบครบวงจร</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">
                  ครอบคลุมการจัดการลิขสิทธิ์ การโปรโมท และการจัดจำหน่ายแบบเต็มรูปแบบ เหมาะสำหรับศิลปินที่ต้องการมุ่งเน้นการสร้างสรรค์ผลงาน
                </p>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full" onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}>
                  สอบถามเพิ่มเติม
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
        
        {/* ตารางเปรียบเทียบคุณสมบัติแบบละเอียด */}
        <div className="mt-24">
          <h3 className="text-2xl font-bold mb-6 text-center">เปรียบเทียบคุณสมบัติแบบละเอียด</h3>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-gray-100">
                  <th className="p-4 text-left font-medium border">คุณสมบัติ</th>
                  <th className="p-4 text-center font-medium border">Free</th>
                  <th className="p-4 text-center font-medium border">Basic</th>
                  <th className="p-4 text-center font-medium border">Pro</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="p-4 border font-medium bg-gray-50">การเผยแพร่</td>
                  <td className="p-4 text-center border"></td>
                  <td className="p-4 text-center border"></td>
                  <td className="p-4 text-center border"></td>
                </tr>
                <tr>
                  <td className="p-4 border">จำนวนแพลตฟอร์ม</td>
                  <td className="p-4 text-center border">10</td>
                  <td className="p-4 text-center border">50+</td>
                  <td className="p-4 text-center border">100+</td>
                </tr>
                <tr>
                  <td className="p-4 border">จำนวนเพลงที่อัปโหลดได้ต่อปี</td>
                  <td className="p-4 text-center border">10</td>
                  <td className="p-4 text-center border">ไม่จำกัด</td>
                  <td className="p-4 text-center border">ไม่จำกัด</td>
                </tr>
                <tr>
                  <td className="p-4 border">ระยะเวลาในการอนุมัติ</td>
                  <td className="p-4 text-center border">15 วัน</td>
                  <td className="p-4 text-center border">7 วัน</td>
                  <td className="p-4 text-center border">3 วัน</td>
                </tr>
                <tr>
                  <td className="p-4 border bg-gray-50 font-medium">รายได้</td>
                  <td className="p-4 text-center border"></td>
                  <td className="p-4 text-center border"></td>
                  <td className="p-4 text-center border"></td>
                </tr>
                <tr>
                  <td className="p-4 border">เปอร์เซ็นต์รายได้ที่ได้รับ</td>
                  <td className="p-4 text-center border">80%</td>
                  <td className="p-4 text-center border">85%</td>
                  <td className="p-4 text-center border">90%</td>
                </tr>
                <tr>
                  <td className="p-4 border">ความถี่ในการจ่ายเงิน</td>
                  <td className="p-4 text-center border">3 เดือน</td>
                  <td className="p-4 text-center border">2 เดือน</td>
                  <td className="p-4 text-center border">1 เดือน</td>
                </tr>
                <tr>
                  <td className="p-4 border bg-gray-50 font-medium">การรายงานและวิเคราะห์</td>
                  <td className="p-4 text-center border"></td>
                  <td className="p-4 text-center border"></td>
                  <td className="p-4 text-center border"></td>
                </tr>
                <tr>
                  <td className="p-4 border">แดชบอร์ดสถิติ</td>
                  <td className="p-4 text-center border">
                    <Check className="h-5 w-5 text-primary mx-auto" />
                  </td>
                  <td className="p-4 text-center border">
                    <Check className="h-5 w-5 text-primary mx-auto" />
                  </td>
                  <td className="p-4 text-center border">
                    <Check className="h-5 w-5 text-primary mx-auto" />
                  </td>
                </tr>
                <tr>
                  <td className="p-4 border">รายงานละเอียดรายแพลตฟอร์ม</td>
                  <td className="p-4 text-center border">
                    -
                  </td>
                  <td className="p-4 text-center border">
                    <Check className="h-5 w-5 text-primary mx-auto" />
                  </td>
                  <td className="p-4 text-center border">
                    <Check className="h-5 w-5 text-primary mx-auto" />
                  </td>
                </tr>
                <tr>
                  <td className="p-4 border">การวิเคราะห์แนวโน้มและข้อเสนอแนะ</td>
                  <td className="p-4 text-center border">
                    -
                  </td>
                  <td className="p-4 text-center border">
                    -
                  </td>
                  <td className="p-4 text-center border">
                    <Check className="h-5 w-5 text-primary mx-auto" />
                  </td>
                </tr>
                <tr>
                  <td className="p-4 border bg-gray-50 font-medium">การสนับสนุน</td>
                  <td className="p-4 text-center border"></td>
                  <td className="p-4 text-center border"></td>
                  <td className="p-4 text-center border"></td>
                </tr>
                <tr>
                  <td className="p-4 border">การสนับสนุนทางอีเมล</td>
                  <td className="p-4 text-center border">
                    <Check className="h-5 w-5 text-primary mx-auto" />
                  </td>
                  <td className="p-4 text-center border">
                    <Check className="h-5 w-5 text-primary mx-auto" />
                  </td>
                  <td className="p-4 text-center border">
                    <Check className="h-5 w-5 text-primary mx-auto" />
                  </td>
                </tr>
                <tr>
                  <td className="p-4 border">การสนับสนุนทางโทรศัพท์</td>
                  <td className="p-4 text-center border">
                    -
                  </td>
                  <td className="p-4 text-center border">
                    -
                  </td>
                  <td className="p-4 text-center border">
                    <Check className="h-5 w-5 text-primary mx-auto" />
                  </td>
                </tr>
                <tr>
                  <td className="p-4 border">ผู้จัดการบัญชีส่วนตัว</td>
                  <td className="p-4 text-center border">
                    -
                  </td>
                  <td className="p-4 text-center border">
                    -
                  </td>
                  <td className="p-4 text-center border">
                    <Check className="h-5 w-5 text-primary mx-auto" />
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  );
}