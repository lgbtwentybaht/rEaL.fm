import { motion } from "framer-motion";
import { Music, DollarSign, BarChart3, Share2, ShieldCheck, HelpCircle } from "lucide-react";

const features = [
  {
    icon: <Music className="h-6 w-6 text-primary" />,
    title: "การเผยแพร่ทั่วโลก",
    description: "เข้าถึงแพลตฟอร์มสตรีมมิ่งกว่า 150+ แห่งทั่วโลกด้วยการอัปโหลดเพียงครั้งเดียว เผยแพร่เพลงของคุณบน Spotify, Apple Music, Amazon และอื่นๆ",
  },
  {
    icon: <DollarSign className="h-6 w-6 text-primary" />,
    title: "ค่าลิขสิทธิ์ที่สูงขึ้น",
    description: "รับค่าลิขสิทธิ์จากการสตรีมมิ่งได้สูงสุด 100% ด้วยรูปแบบการจ่ายเงินที่เน้นศิลปินเป็นหลัก การแบ่งรายได้ที่โปร่งใสโดยไม่มีค่าธรรมเนียมซ่อนเร้น",
  },
  {
    icon: <BarChart3 className="h-6 w-6 text-primary" />,
    title: "การวิเคราะห์ขั้นสูง",
    description: "ติดตามผลงานเพลงของคุณด้วยข้อมูลเชิงลึกที่ละเอียด เข้าใจกลุ่มผู้ฟัง รูปแบบการสตรีม และรายได้แบบเรียลไทม์",
  },
  {
    icon: <Share2 className="h-6 w-6 text-primary" />,
    title: "เครื่องมือส่งเสริมการขาย",
    description: "เข้าถึงชุดเครื่องมือการตลาดเพื่อขยายการเข้าถึงของคุณ สร้างแคมเปญพรีเซฟ การรวมเข้าเรดาร์การเปิดตัว และการส่งเพลงลิสต์",
  },
  {
    icon: <ShieldCheck className="h-6 w-6 text-primary" />,
    title: "การคุ้มครองลิขสิทธิ์",
    description: "ปกป้องทรัพย์สินทางปัญญาของคุณด้วยระบบระบุเนื้อหาของเรา ตรวจจับและอ้างสิทธิ์เพลงของคุณโดยอัตโนมัติในแพลตฟอร์มต่างๆ",
  },
  {
    icon: <HelpCircle className="h-6 w-6 text-primary" />,
    title: "การสนับสนุนศิลปิน",
    description: "ผู้จัดการบัญชีที่ทุ่มเทสำหรับศิลปินทุกคน รับคำแนะนำและการสนับสนุนส่วนบุคคลตลอดอาชีพด้านดนตรีของคุณ",
  }
];

export function FeaturesSection() {
  return (
    <section id="features" className="py-20 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <span className="text-primary font-semibold uppercase tracking-wider text-sm">ทุกสิ่งที่คุณต้องการ</span>
            <h2 className="text-3xl md:text-4xl font-bold my-4 text-gray-900">การเผยแพร่เพลงที่ถูกคิดใหม่</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">เครื่องมือทั้งหมดที่คุณต้องการเพื่อประสบความสำเร็จในอุตสาหกรรมดนตรียุคปัจจุบัน สร้างขึ้นสำหรับศิลปินอิสระยุคใหม่</p>
          </motion.div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              className="bg-white rounded-xl p-6 transition-all hover:shadow-xl border border-gray-100 hover:border-primary/20 group"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                {feature.icon}
              </div>
              <h3 className="text-xl font-bold mb-2 text-gray-900">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </motion.div>
          ))}
        </div>
        
        <div className="mt-20 max-w-3xl mx-auto text-center">
          <div className="rounded-xl bg-gradient-to-r from-sky-100 to-indigo-100 p-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">พร้อมที่จะเริ่มต้นหรือยัง?</h3>
            <p className="text-gray-600 mb-6">เข้าร่วมกับศิลปินหลายพันคนที่กำลังควบคุมอาชีพด้านดนตรีของพวกเขา</p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              onClick={() => {
                const element = document.getElementById("waitlist");
                if (element) {
                  element.scrollIntoView({ behavior: "smooth" });
                }
              }}
              className="bg-primary text-white font-medium py-3 px-8 rounded-md hover:bg-primary/90 transition-colors"
            >
              ลงทะเบียนรอใช้งาน
            </motion.button>
          </div>
        </div>
      </div>
    </section>
  );
}
