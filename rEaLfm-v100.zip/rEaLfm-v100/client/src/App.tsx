import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/lib/protected-route";
import Home from "@/pages/Home";
import NotFound from "@/pages/not-found";
import Pricing from "@/pages/Pricing";
import AuthPage from "@/pages/auth-page";
import Dashboard from "@/pages/Dashboard";
import TracksPage from "@/pages/dashboard/tracks";
import UploadTrack from "@/pages/dashboard/UploadTrack";
import TrackDetails from "@/pages/dashboard/TrackDetails";
import AlbumsPage from "@/pages/dashboard/albums";
import CreateAlbumPage from "@/pages/dashboard/albums/new";
import AnalyticsPage from "@/pages/dashboard/analytics";
import SettingsPage from "@/pages/dashboard/settings";
import PaymentsPage from "@/pages/dashboard/payments";
import TeamPage from "@/pages/dashboard/team";
import ProfilePage from "@/pages/dashboard/profile";
import AdminDashboard from "@/pages/admin/dashboard";
import AdminUsers from "@/pages/admin/users";
import AdminTracks from "@/pages/admin/tracks";
import { useEffect } from "react";

// Scroll to top on route change
function ScrollToTop() {
  const [location] = useLocation();
  
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location]);
  
  return null;
}

function Router() {
  return (
    <>
      <ScrollToTop />
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/pricing" component={Pricing} />
        <Route path="/auth" component={AuthPage} />
        <ProtectedRoute path="/dashboard" component={Dashboard} />
        <ProtectedRoute path="/dashboard/tracks" component={TracksPage} />
        <ProtectedRoute path="/dashboard/tracks/:id" component={TrackDetails} />
        <ProtectedRoute path="/dashboard/upload" component={UploadTrack} />
        <ProtectedRoute path="/dashboard/albums" component={AlbumsPage} />
        <ProtectedRoute path="/dashboard/albums/new" component={CreateAlbumPage} />
        <ProtectedRoute path="/dashboard/analytics" component={AnalyticsPage} />
        <ProtectedRoute path="/dashboard/settings" component={SettingsPage} />
        <ProtectedRoute path="/dashboard/payments" component={PaymentsPage} />
        <ProtectedRoute path="/dashboard/team" component={TeamPage} />
        <ProtectedRoute path="/dashboard/profile" component={ProfilePage} />
        <ProtectedRoute path="/admin" component={AdminDashboard} role="admin" />
        <ProtectedRoute path="/admin/dashboard" component={AdminDashboard} role="admin" />
        <ProtectedRoute path="/admin/users" component={AdminUsers} role="admin" />
        <ProtectedRoute path="/admin/tracks" component={AdminTracks} role="admin" />
        <Route path="/:path*" component={NotFound} />
      </Switch>
    </>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
