import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Add custom CSS variables to match design reference like TuneCore
const customCSSVariables = `
  :root {
    --background: 0 0% 100%;
    --foreground: 224 71.4% 4.1%;
    
    --muted: 220 14.3% 95.9%;
    --muted-foreground: 220 8.9% 46.1%;
    
    --accent: 209 100% 55%;
    --accent-foreground: 0 0% 100%;
    
    --primary: 209 100% 55%;
    --primary-foreground: 0 0% 100%;
    
    --secondary: 220 14.3% 95.9%;
    --secondary-foreground: 220.9 39.3% 11%;
    
    --destructive: 0 84.2% 60.2%;
    --destructive-foreground: 210 20% 98%;
    
    --success: 142.1 76.2% 36.3%;
    
    --card: 0 0% 100%;
    --card-foreground: 224 71.4% 4.1%;
    
    --popover: 0 0% 100%;
    --popover-foreground: 224 71.4% 4.1%;
    
    --border: 220 13% 91%;
    --input: 220 13% 91%;
    --ring: 209 100% 55%;
    
    --radius: 0.5rem;
    
    --font-sans: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    --font-accent: 'Montserrat', 'Source Sans Pro', -apple-system, sans-serif;
  }
`;

// Add the custom CSS variables to the document
const style = document.createElement('style');
style.textContent = customCSSVariables;
document.head.appendChild(style);

createRoot(document.getElementById("root")!).render(<App />);
