import { createContext, ReactNode, useContext } from "react";
import {
  useQuery,
  useMutation,
  UseMutationResult,
} from "@tanstack/react-query";
import { insertUserSchema, User, LoginFormData, SignupFormData } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

type AuthContextType = {
  user: User | null;
  isLoading: boolean;
  error: Error | null;
  loginMutation: UseMutationResult<{ user: User, message: string }, Error, LoginFormData>;
  logoutMutation: UseMutationResult<void, Error, void>;
  registerMutation: UseMutationResult<{ user: User, message: string }, Error, SignupFormData>;
};

export const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const { toast } = useToast();
  
  // Fetch current user
  const {
    data: user,
    error,
    isLoading,
  } = useQuery({
    queryKey: ["/api/auth/me"],
    queryFn: async () => {
      try {
        return await apiRequest<User>({ 
          url: "/api/auth/me", 
          method: "GET" 
        });
      } catch (error) {
        // If 401, return null (not authenticated)
        if (error instanceof Error && error.message.includes("401")) {
          return null;
        }
        throw error;
      }
    }
  });

  // Login mutation
  const loginMutation = useMutation({
    mutationFn: async (credentials: LoginFormData) => {
      const res = await apiRequest<{ user: User, message: string }>({ 
        url: "/api/auth/login", 
        method: "POST", 
        body: credentials 
      });
      return res;
    },
    onSuccess: (data) => {
      queryClient.setQueryData(["/api/auth/me"], data.user);
      toast({
        title: "เข้าสู่ระบบสำเร็จ",
        description: data.message || "ยินดีต้อนรับกลับมา!",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "เข้าสู่ระบบล้มเหลว",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Registration mutation
  const registerMutation = useMutation({
    mutationFn: async (userData: SignupFormData) => {
      const res = await apiRequest<{ user: User, message: string }>({ 
        url: "/api/auth/signup", 
        method: "POST", 
        body: userData 
      });
      return res;
    },
    onSuccess: (data) => {
      queryClient.setQueryData(["/api/auth/me"], data.user);
      toast({
        title: "ลงทะเบียนสำเร็จ",
        description: data.message || "บัญชีของคุณได้รับการสร้างเรียบร้อยแล้ว",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "ลงทะเบียนล้มเหลว",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Logout mutation
  const logoutMutation = useMutation({
    mutationFn: async () => {
      await apiRequest({ 
        url: "/api/auth/logout", 
        method: "POST" 
      });
    },
    onSuccess: () => {
      queryClient.setQueryData(["/api/auth/me"], null);
      toast({
        title: "ออกจากระบบสำเร็จ",
        description: "คุณได้ออกจากระบบเรียบร้อยแล้ว",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "ออกจากระบบล้มเหลว",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  return (
    <AuthContext.Provider
      value={{
        user: user ?? null,
        isLoading,
        error,
        loginMutation,
        logoutMutation,
        registerMutation,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}